import React, {
  useState,
} from "react";

import {
  Routes,
  Route,
} from "react-router-dom";


/*
|--------------------------------------------------------------------------
| PAGES
|--------------------------------------------------------------------------
*/

import Home from "./pages/Home";
import Properties from "./pages/Properties";
import PropertyDetails from "./pages/PropertyDetails";
import Listings from "./pages/Listings";

import Blogs from "./pages/Blogs";
import BlogDetails from "./pages/BlogDetails";

import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";

import AgentProfile from "./pages/AgentProfile";

import WishlistPage from "./pages/WishlistPage";
import CustomerProfile from "./pages/CustomerProfile";

import FAQPage from "./pages/FAQPage";
import PrivacyPolicy from "./pages/PrivacyPolicy";


/*
|--------------------------------------------------------------------------
| COMPONENTS
|--------------------------------------------------------------------------
*/

import Navbar from "./components/Navbar";
import CustomerLogin from "./pages/CustomerLogin";

import {
  WishlistProvider,
} from "./components/WishlistContext";


/*
|--------------------------------------------------------------------------
| APP
|--------------------------------------------------------------------------
*/

function App() {

  /*
  |--------------------------------------------------------------------------
  | LOGIN MODAL
  |--------------------------------------------------------------------------
  */

  const [
    showLogin,
    setShowLogin,
  ] = useState(false);


  /*
  |--------------------------------------------------------------------------
  | CUSTOMER
  |--------------------------------------------------------------------------
  |
  | FIXED:
  | Previous code was reading localStorage but not returning it.
  |
  */

  const [
    customer,
    setCustomer,
  ] = useState(() => {

    try {

      const storedCustomer =
        localStorage.getItem(
          "customer"
        );

      if (!storedCustomer) {
        return null;
      }

      return JSON.parse(
        storedCustomer
      );

    } catch (error) {

      console.error(
        "Customer localStorage error:",
        error
      );

      localStorage.removeItem(
        "customer"
      );

      return null;

    }

  });


  /*
  |--------------------------------------------------------------------------
  | LOGOUT / CUSTOMER UPDATE HANDLER
  |--------------------------------------------------------------------------
  */

  const handleSetCustomer = (
    updatedCustomer
  ) => {

    setCustomer(
      updatedCustomer
    );


    /*
    |--------------------------------------------------------------------------
    | LOGIN
    |--------------------------------------------------------------------------
    */

    if (
      updatedCustomer
    ) {

      try {

        localStorage.setItem(
          "customer",
          JSON.stringify(
            updatedCustomer
          )
        );

      } catch (
        error
      ) {

        console.error(
          "Unable to save customer:",
          error
        );

      }

      return;
    }


    /*
    |--------------------------------------------------------------------------
    | LOGOUT
    |--------------------------------------------------------------------------
    */

    localStorage.removeItem(
      "customer"
    );

    localStorage.removeItem(
      "customer_token"
    );

    localStorage.removeItem(
      "customer_id"
    );

    localStorage.removeItem(
      "customer_name"
    );

    localStorage.removeItem(
      "customer_email"
    );

    localStorage.removeItem(
      "customer_phone"
    );

  };


  return (
    <WishlistProvider>

      <div
        className="
          min-h-screen
          bg-white
        "
      >

        {/* ==================================================
            LOGIN MODAL
        =================================================== */}

        <CustomerLogin
          open={
            showLogin
          }
          setOpen={
            setShowLogin
          }
          setCustomer={
            handleSetCustomer
          }
        />


        {/* ==================================================
            NAVBAR
        =================================================== */}

        <Navbar
          setShowLogin={
            setShowLogin
          }
          customer={
            customer
          }
          setCustomer={
            handleSetCustomer
          }
        />


        {/* ==================================================
            PAGE CONTENT
        =================================================== */}

        <div
          className="
            pb-12
            md:pb-0
          "
        >

          <Routes>

            {/* =================================================
                HOME
            ================================================== */}

            <Route
              path="/"
              element={
                <Home />
              }
            />


            {/* =================================================
                PROPERTIES
            ================================================== */}

            <Route
              path="/properties"
              element={
                <Properties
                  setShowLogin={
                    setShowLogin
                  }
                />
              }
            />


            <Route
              path="/property/:id"
              element={
                <PropertyDetails
                  setShowLogin={
                    setShowLogin
                  }
                />
              }
            />


            {/* =================================================
                LISTINGS
            ================================================== */}

            <Route
              path="/listings"
              element={
                <Listings />
              }
            />


            {/* =================================================
                BLOG
            ================================================== */}

            <Route
              path="/blogs"
              element={
                <Blogs />
              }
            />

            <Route
              path="/blog/:slug"
              element={
                <BlogDetails />
              }
            />


            {/* =================================================
                COMPANY
            ================================================== */}

            <Route
              path="/about"
              element={
                <About />
              }
            />

            <Route
              path="/services"
              element={
                <Services />
              }
            />

            <Route
              path="/contact"
              element={
                <Contact />
              }
            />


            {/* =================================================
                AGENT
            ================================================== */}

            <Route
              path="/agent/:id"
              element={
                <AgentProfile />
              }
            />


            {/* =================================================
                CUSTOMER
            ================================================== */}

            <Route
              path="/wishlist"
              element={
                <WishlistPage />
              }
            />

            <Route
              path="/profile"
              element={
                <CustomerProfile />
              }
            />


            {/* =================================================
                INFORMATION
            ================================================== */}

            <Route
              path="/faq"
              element={
                <FAQPage />
              }
            />

            <Route
              path="/privacy-policy"
              element={
                <PrivacyPolicy />
              }
            />


            {/* =================================================
                404
            ================================================== */}

            <Route
              path="*"
              element={
                <NotFound />
              }
            />

          </Routes>

        </div>

      </div>

    </WishlistProvider>
  );
}


/*
|--------------------------------------------------------------------------
| 404 PAGE
|--------------------------------------------------------------------------
*/

const NotFound = () => {

  return (
    <main
      className="
        flex
        min-h-[80vh]
        items-center
        justify-center
        bg-[#f7fbff]
        px-4
      "
    >

      <div
        className="
          w-full
          max-w-md
          rounded-[26px]
          border
          border-gray-100
          bg-white
          p-8
          text-center
          shadow-sm
        "
      >

        <div
          className="
            mx-auto
            flex
            h-16
            w-16
            items-center
            justify-center
            rounded-full
            bg-sky-50
            text-2xl
          "
        >
          🏠
        </div>


        <p
          className="
            mt-4
            text-4xl
            font-extrabold
            text-sky-500
          "
        >
          404
        </p>


        <h1
          className="
            mt-2
            text-xl
            font-bold
            text-gray-900
          "
        >
          Page Not Found
        </h1>


        <p
          className="
            mt-2
            text-sm
            leading-6
            text-gray-500
          "
        >
          The page you're looking for doesn't
          exist or may have been moved.
        </p>

      </div>

    </main>
  );
};


export default App;