import React, {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  useParams,
  useNavigate,
} from "react-router-dom";

import {
  FaPhone,
  FaEnvelope,
  FaMapMarkerAlt,
  FaWhatsapp,
  FaFacebook,
  FaInstagram,
  FaLinkedin,
  FaYoutube,
  FaBriefcase,
  FaBuilding,
  FaCheckCircle,
} from "react-icons/fa";

import Footer from "../components/Footer";


const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";

const FALLBACK_AGENT_IMAGE =
  "https://img.magnific.com/free-psd/contact-icon-illustration-isolated_23-2151903337.jpg";

const FALLBACK_PROPERTY_IMAGE =
  "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg";


const AgentProfile = () => {

  const {
    id,
  } = useParams();

  const navigate =
    useNavigate();


  /*
  |--------------------------------------------------------------------------
  | STATE
  |--------------------------------------------------------------------------
  */

  const [
    agent,
    setAgent,
  ] = useState(null);

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    error,
    setError,
  ] = useState(false);

  const [
    page,
    setPage,
  ] = useState(1);

  const limit = 12;


  /*
  |--------------------------------------------------------------------------
  | FETCH AGENT
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    if (!id) {
      return;
    }

    const fetchAgent =
      async () => {

        try {

          setLoading(true);
          setError(false);

          const response =
            await fetch(
              `${API_BASE}/api/agent/profile/${id}`
            );

          if (!response.ok) {
            throw new Error(
              "Failed to fetch agent"
            );
          }

          const data =
            await response.json();

          setAgent(
            data?.data || null
          );

        } catch (err) {

          console.error(
            "Agent Error:",
            err
          );

          setAgent(null);
          setError(true);

        } finally {

          setLoading(false);

        }
      };

    fetchAgent();

  }, [id]);


  /*
  |--------------------------------------------------------------------------
  | NORMAL DATA
  |--------------------------------------------------------------------------
  */

  const properties =
    Array.isArray(
      agent?.properties
    )
      ? agent.properties
      : [];

  const detail =
    agent?.agent_detail ||
    {};

  const teams =
    Array.isArray(
      agent?.teams
    )
      ? agent.teams
      : [];


  /*
  |--------------------------------------------------------------------------
  | PAGINATION
  |--------------------------------------------------------------------------
  */

  const totalPages =
    Math.max(
      1,
      Math.ceil(
        properties.length /
          limit
      )
    );

  const paginated =
    useMemo(() => {

      const start =
        (page - 1) *
        limit;

      return properties.slice(
        start,
        start + limit
      );

    }, [
      properties,
      page,
    ]);


  /*
  |--------------------------------------------------------------------------
  | STATS
  |--------------------------------------------------------------------------
  */

  const totalListings =
    properties.length;

  const soldCount =
    properties.filter(
      (item) =>
        item?.status ===
        "sold"
    ).length;

  const pendingCount =
    properties.filter(
      (item) =>
        item?.status ===
        "pending"
    ).length;

  const activeCount =
    properties.filter(
      (item) =>
        item?.status ===
        "active"
    ).length;


  /*
  |--------------------------------------------------------------------------
  | SAFE IMAGE
  |--------------------------------------------------------------------------
  */

  const getAgentImage =
    () => {

      if (!agent?.img) {
        return FALLBACK_AGENT_IMAGE;
      }

      return `${API_BASE}/public${agent.img}`;
    };


  /*
  |--------------------------------------------------------------------------
  | PROPERTY IMAGE
  |--------------------------------------------------------------------------
  */

  const getPropertyImage =
    (property) => {

      let images =
        property?.image;

      if (
        typeof images ===
        "string"
      ) {

        try {

          images =
            JSON.parse(
              images
            );

        } catch {

          images = [];

        }

      }

      if (
        !Array.isArray(
          images
        ) ||
        images.length ===
          0
      ) {

        return FALLBACK_PROPERTY_IMAGE;

      }

      const first =
        images[0];

      if (
        typeof first ===
          "object" &&
        first?.path
      ) {

        return `${API_BASE}/public/${first.path}`;

      }

      if (
        typeof first ===
        "string"
      ) {

        return `${API_BASE}/public/${first}`;

      }

      return FALLBACK_PROPERTY_IMAGE;
    };


  /*
  |--------------------------------------------------------------------------
  | PAGINATION
  |--------------------------------------------------------------------------
  */

  const renderPagination =
    () => {

      if (
        totalPages <= 1
      ) {
        return null;
      }

      return (
        <div
          className="
            mt-8
            flex
            flex-wrap
            justify-center
            gap-2
          "
        >

          <button
            type="button"
            onClick={() =>
              setPage(
                (prev) =>
                  Math.max(
                    1,
                    prev - 1
                  )
              )
            }
            disabled={
              page === 1
            }
            className="
              flex
              h-10
              w-10
              items-center
              justify-center
              rounded-xl
              border
              border-gray-200
              bg-white
              text-sm
              text-gray-600
              transition
              hover:border-sky-400
              hover:bg-sky-50
              disabled:cursor-not-allowed
              disabled:opacity-40
            "
          >
            ←
          </button>


          {Array.from(
            {
              length:
                totalPages,
            },
            (
              _,
              index
            ) => {

              const pageNumber =
                index + 1;

              return (
                <button
                  type="button"
                  key={
                    pageNumber
                  }
                  onClick={() =>
                    setPage(
                      pageNumber
                    )
                  }
                  className={`
                    flex
                    h-10
                    min-w-10
                    items-center
                    justify-center
                    rounded-xl
                    px-3
                    text-xs
                    font-semibold
                    transition

                    ${
                      page ===
                      pageNumber
                        ? "bg-sky-500 text-white shadow-sm"
                        : "border border-gray-200 bg-white text-gray-600 hover:border-sky-300 hover:bg-sky-50"
                    }
                  `}
                >
                  {pageNumber}
                </button>
              );
            }
          )}


          <button
            type="button"
            onClick={() =>
              setPage(
                (prev) =>
                  Math.min(
                    totalPages,
                    prev + 1
                  )
              )
            }
            disabled={
              page ===
              totalPages
            }
            className="
              flex
              h-10
              w-10
              items-center
              justify-center
              rounded-xl
              border
              border-gray-200
              bg-white
              text-sm
              text-gray-600
              transition
              hover:border-sky-400
              hover:bg-sky-50
              disabled:cursor-not-allowed
              disabled:opacity-40
            "
          >
            →
          </button>

        </div>
      );
    };


  /*
  |--------------------------------------------------------------------------
  | LOADING
  |--------------------------------------------------------------------------
  */

  if (loading) {

    return (
      <div
        className="
          flex
          min-h-[70vh]
          items-center
          justify-center
          bg-[#f6f9ff]
          px-4
        "
      >

        <div className="text-center">

          <div
            className="
              mx-auto
              h-9
              w-9
              animate-spin
              rounded-full
              border-[3px]
              border-gray-200
              border-t-sky-500
            "
          />

          <p
            className="
              mt-4
              text-sm
              text-gray-500
            "
          >
            Loading agent profile...
          </p>

        </div>

      </div>
    );

  }


  /*
  |--------------------------------------------------------------------------
  | ERROR
  |--------------------------------------------------------------------------
  */

  if (
    error ||
    !agent
  ) {

    return (
      <>
        <div
          className="
            flex
            min-h-[70vh]
            items-center
            justify-center
            bg-[#f6f9ff]
            px-4
          "
        >

          <div
            className="
              w-full
              max-w-md
              rounded-3xl
              border
              border-gray-100
              bg-white
              p-8
              text-center
              shadow-sm
            "
          >

            <div className="text-5xl">
              👤
            </div>

            <h2
              className="
                mt-4
                text-xl
                font-bold
                text-gray-900
              "
            >
              Agent Not Found
            </h2>

            <p
              className="
                mt-2
                text-sm
                leading-6
                text-gray-500
              "
            >
              We couldn't load this agent profile.
            </p>

            <button
              type="button"
              onClick={() =>
                navigate(-1)
              }
              className="
                mt-6
                rounded-xl
                bg-sky-500
                px-5
                py-3
                text-sm
                font-semibold
                text-white
                hover:bg-sky-600
              "
            >
              Go Back
            </button>

          </div>

        </div>

        <Footer />
      </>
    );

  }


  return (
    <>
      <main
        className="
          min-h-screen
          bg-[#f6f9ff]
          px-3
          py-5
          sm:px-5
          sm:py-7
          lg:px-8
          lg:py-10
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1380px]
          "
        >

          {/* ==================================================
              PROFILE + ABOUT
          =================================================== */}

          <div
            className="
              grid
              grid-cols-1
              gap-5
              lg:grid-cols-[330px_minmax(0,1fr)]
              lg:gap-6
            "
          >

            {/* =================================================
                PROFILE CARD
            ================================================== */}

            <aside
              className="
                min-w-0
                self-start
                rounded-[26px]
                border
                border-gray-100
                bg-white
                p-5
                text-center
                shadow-sm
                sm:p-7
                lg:sticky
                lg:top-6
              "
            >

              {/* IMAGE */}

              <div
                className="
                  mx-auto
                  w-fit
                "
              >

                <div
                  className="
                    relative
                  "
                >

                  <img
                    src={
                      getAgentImage()
                    }
                    alt={
                      agent.name ||
                      "Agent"
                    }
                    className="
                      h-28
                      w-28
                      rounded-full
                      border-4
                      border-sky-100
                      object-cover
                      shadow-lg
                      sm:h-32
                      sm:w-32
                    "
                  />

                  <div
                    className="
                      absolute
                      bottom-1
                      right-1
                      flex
                      h-7
                      w-7
                      items-center
                      justify-center
                      rounded-full
                      border-4
                      border-white
                      bg-green-500
                      text-white
                    "
                  >
                    <FaCheckCircle
                      size={10}
                    />
                  </div>

                </div>

              </div>


              {/* NAME */}

              <h1
                className="
                  mt-5
                  break-words
                  text-2xl
                  font-extrabold
                  text-gray-900
                  sm:text-3xl
                  lg:text-2xl
                "
              >
                {agent.name}
              </h1>


              {/* DESIGNATION */}

              <p
                className="
                  mt-1
                  text-sm
                  font-semibold
                  text-sky-500
                "
              >
                {detail.designation ||
                  "Real Estate Agent"}
              </p>


              {/* LOCATION */}

              <p
                className="
                  mt-3
                  flex
                  items-center
                  justify-center
                  gap-2
                  text-xs
                  text-gray-500
                "
              >
                <FaMapMarkerAlt className="text-sky-500" />

                {detail.city ||
                  "Location not available"}

                {detail.country &&
                  `, ${detail.country}`}
              </p>


              {/* CONTACT */}

              <div
                className="
                  mt-6
                  grid
                  grid-cols-2
                  gap-2
                "
              >

                <a
                  href={
                    agent.phone
                      ? `tel:${agent.phone}`
                      : "#"
                  }
                  className="
                    flex
                    min-h-[44px]
                    items-center
                    justify-center
                    gap-2
                    rounded-xl
                    bg-sky-500
                    px-3
                    text-xs
                    font-semibold
                    text-white
                    transition
                    hover:bg-sky-600
                  "
                >
                  <FaPhone />
                  Call
                </a>


                <a
                  href={
                    detail.whatsapp
                      ? `https://wa.me/${detail.whatsapp}`
                      : agent.phone
                      ? `https://wa.me/${agent.phone}`
                      : "#"
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="
                    flex
                    min-h-[44px]
                    items-center
                    justify-center
                    gap-2
                    rounded-xl
                    bg-green-500
                    px-3
                    text-xs
                    font-semibold
                    text-white
                    transition
                    hover:bg-green-600
                  "
                >
                  <FaWhatsapp />
                  WhatsApp
                </a>

              </div>


              {/* BASIC CONTACT */}

              <div
                className="
                  mt-6
                  space-y-3
                  border-t
                  border-gray-100
                  pt-5
                  text-left
                "
              >

                <ContactRow
                  icon={
                    <FaEnvelope />
                  }
                  label="Email"
                  value={
                    agent.email
                  }
                />

                <ContactRow
                  icon={
                    <FaPhone />
                  }
                  label="Phone"
                  value={
                    agent.phone
                  }
                />

                <ContactRow
                  icon={
                    <FaMapMarkerAlt />
                  }
                  label="State"
                  value={
                    detail.state
                  }
                />

                <ContactRow
                  icon={
                    <FaMapMarkerAlt />
                  }
                  label="Country"
                  value={
                    detail.country
                  }
                />

              </div>


              {/* SOCIAL */}

              <div
                className="
                  mt-5
                  flex
                  flex-wrap
                  justify-center
                  gap-2
                "
              >

                {detail.facebook && (
                  <SocialButton
                    href={
                      detail.facebook
                    }
                    icon={
                      <FaFacebook />
                    }
                  />
                )}

                {detail.instagram && (
                  <SocialButton
                    href={
                      detail.instagram
                    }
                    icon={
                      <FaInstagram />
                    }
                  />
                )}

                {detail.linkedin && (
                  <SocialButton
                    href={
                      detail.linkedin
                    }
                    icon={
                      <FaLinkedin />
                    }
                  />
                )}

                {detail.youtube && (
                  <SocialButton
                    href={
                      detail.youtube
                    }
                    icon={
                      <FaYoutube />
                    }
                  />
                )}

              </div>

            </aside>


            {/* =================================================
                RIGHT CONTENT
            ================================================== */}

            <div
              className="
                min-w-0
                space-y-5
                lg:space-y-6
              "
            >

              {/* ABOUT */}

              <section
                className="
                  rounded-[26px]
                  border
                  border-gray-100
                  bg-white
                  p-5
                  shadow-sm
                  sm:p-7
                "
              >

                <div
                  className="
                    flex
                    flex-col
                    gap-2
                  "
                >

                  <div>
                    <p
                      className="
                        text-[10px]
                        font-bold
                        uppercase
                        tracking-[0.16em]
                        text-sky-500
                        sm:text-xs
                      "
                    >
                      Professional Profile
                    </p>

                    <h2
                      className="
                        mt-1
                        text-2xl
                        font-bold
                        text-gray-900
                        sm:text-3xl
                      "
                    >
                      About {agent.name}
                    </h2>
                  </div>

                </div>


                <p
                  className="
                    mt-5
                    break-words
                    text-sm
                    leading-7
                    text-gray-600
                    sm:text-[15px]
                  "
                >
                  {detail.bio ||
                    "Experienced real estate professional helping clients find their dream properties."}
                </p>


                {/* DETAILS */}

                <div
                  className="
                    mt-6
                    grid
                    grid-cols-1
                    gap-3
                    sm:grid-cols-2
                  "
                >

                  {[
                    [
                      "Experience",
                      detail.experience,
                      <FaBriefcase />,
                    ],

                    [
                      "Specialization",
                      detail.specialization,
                      <FaBuilding />,
                    ],

                    [
                      "Agency",
                      detail.agency,
                      <FaBuilding />,
                    ],

                    [
                      "License",
                      detail.license,
                      <FaCheckCircle />,
                    ],

                    [
                      "Tax Number",
                      detail.tax_number,
                      <FaCheckCircle />,
                    ],

                    [
                      "Service Area",
                      detail.service_area,
                      <FaMapMarkerAlt />,
                    ],
                  ].map(
                    ([
                      label,
                      value,
                      icon,
                    ]) => (

                      <InfoCard
                        key={
                          label
                        }
                        icon={
                          icon
                        }
                        label={
                          label
                        }
                        value={
                          value
                        }
                      />

                    )
                  )}

                </div>

              </section>


              {/* STATS */}

              <section
                className="
                  grid
                  grid-cols-2
                  gap-3
                  sm:grid-cols-4
                "
              >

                <StatCard
                  label="Total Listings"
                  value={
                    totalListings
                  }
                />

                <StatCard
                  label="Properties Sold"
                  value={
                    soldCount
                  }
                />

                <StatCard
                  label="Pending"
                  value={
                    pendingCount
                  }
                />

                <StatCard
                  label="Active"
                  value={
                    activeCount
                  }
                />

              </section>


              {/* =================================================
                  TEAMS
              ================================================== */}

              {teams.length >
                0 && (

                <section>

                  <div
                    className="
                      mb-5
                      flex
                      items-end
                      justify-between
                      gap-3
                    "
                  >

                    <div>

                      <p
                        className="
                          text-[10px]
                          font-bold
                          uppercase
                          tracking-[0.16em]
                          text-sky-500
                          sm:text-xs
                        "
                      >
                        Collaboration
                      </p>

                      <h2
                        className="
                          mt-1
                          text-2xl
                          font-bold
                          text-gray-900
                          sm:text-3xl
                        "
                      >
                        Our Teams
                      </h2>

                    </div>

                  </div>


                  <div
                    className="
                      space-y-5
                    "
                  >

                    {teams.map(
                      (
                        team,
                        teamIndex
                      ) => (

                        <div
                          key={
                            team.id ||
                            teamIndex
                          }
                          className="
                            overflow-hidden
                            rounded-[26px]
                            border
                            border-gray-100
                            bg-white
                            shadow-sm
                          "
                        >

                          {/* TEAM COVER */}

                          <div
                            className="
                              relative
                              h-[220px]
                              sm:h-[280px]
                            "
                          >

                            <img
                              src={`${API_BASE}/public${team.photo}`}
                              alt={
                                team.name
                              }
                              className="
                                h-full
                                w-full
                                object-cover
                              "
                            />

                            <div
                              className="
                                absolute
                                inset-0
                                bg-gradient-to-t
                                from-black/80
                                via-black/30
                                to-transparent
                              "
                            />

                            <div
                              className="
                                absolute
                                bottom-5
                                left-5
                                right-5
                                text-white
                                sm:bottom-7
                                sm:left-7
                                sm:right-7
                              "
                            >

                              <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-white/70">
                                Real Estate Team
                              </p>

                              <h3
                                className="
                                  mt-1
                                  break-words
                                  text-2xl
                                  font-bold
                                  sm:text-3xl
                                "
                              >
                                {team.name}
                              </h3>

                              <div
                                className="
                                  mt-3
                                  inline-flex
                                  rounded-full
                                  bg-white/15
                                  px-3
                                  py-1.5
                                  text-[10px]
                                  font-semibold
                                  backdrop-blur
                                  sm:text-xs
                                "
                              >
                                {team.team_members
                                  ?.length ||
                                  0}{" "}
                                Members
                              </div>

                            </div>

                          </div>


                          {/* MEMBERS */}

                          <div
                            className="
                              p-4
                              sm:p-6
                            "
                          >

                            <h4
                              className="
                                text-lg
                                font-bold
                                text-gray-900
                              "
                            >
                              Team Members
                            </h4>


                            <div
                              className="
                                mt-4
                                grid
                                grid-cols-2
                                gap-3
                                sm:grid-cols-3
                                lg:grid-cols-4
                                xl:grid-cols-5
                              "
                            >

                              {team.team_members?.map(
                                (
                                  member
                                ) => (

                                  <div
                                    key={
                                      member.id
                                    }
                                    className="
                                      min-w-0
                                      rounded-2xl
                                      border
                                      border-gray-100
                                      bg-gray-50
                                      p-4
                                      text-center
                                      transition
                                      hover:-translate-y-1
                                      hover:bg-white
                                      hover:shadow-md
                                    "
                                  >

                                    <img
                                      src={
                                        member.photo
                                          ? `${API_BASE}/public${member.photo}`
                                          : FALLBACK_AGENT_IMAGE
                                      }
                                      alt={
                                        member.name
                                      }
                                      className="
                                        mx-auto
                                        h-16
                                        w-16
                                        rounded-full
                                        border-2
                                        border-sky-100
                                        object-cover
                                        sm:h-20
                                        sm:w-20
                                      "
                                    />

                                    <h5
                                      className="
                                        mt-3
                                        line-clamp-2
                                        break-words
                                        text-sm
                                        font-semibold
                                        text-gray-800
                                      "
                                    >
                                      {
                                        member.name
                                      }
                                    </h5>

                                    <span
                                      className="
                                        mt-2
                                        inline-block
                                        max-w-full
                                        truncate
                                        rounded-full
                                        bg-sky-100
                                        px-2.5
                                        py-1
                                        text-[9px]
                                        font-semibold
                                        text-sky-700
                                        sm:text-[10px]
                                      "
                                    >
                                      {
                                        member.profession
                                      }
                                    </span>

                                  </div>

                                )
                              )}

                            </div>

                          </div>

                        </div>

                      )
                    )}

                  </div>

                </section>

              )}


              {/* =================================================
                  ACTIVE LISTINGS
              ================================================== */}

              <section
                className="
                  rounded-[26px]
                  border
                  border-gray-100
                  bg-white
                  p-5
                  shadow-sm
                  sm:p-7
                "
              >

                {/* HEADER */}

                <div
                  className="
                    mb-6
                    flex
                    flex-col
                    gap-3
                    sm:flex-row
                    sm:items-end
                    sm:justify-between
                  "
                >

                  <div>

                    <p
                      className="
                        text-[10px]
                        font-bold
                        uppercase
                        tracking-[0.16em]
                        text-sky-500
                        sm:text-xs
                      "
                    >
                      Portfolio
                    </p>

                    <h2
                      className="
                        mt-1
                        text-2xl
                        font-bold
                        text-gray-900
                        sm:text-3xl
                      "
                    >
                      Active Listings
                    </h2>

                  </div>

                  <span
                    className="
                      w-fit
                      rounded-full
                      bg-sky-50
                      px-3
                      py-1.5
                      text-xs
                      font-semibold
                      text-sky-700
                    "
                  >
                    {properties.length}{" "}
                    Properties
                  </span>

                </div>


                {/* EMPTY */}

                {paginated.length ===
                0 ? (

                  <div
                    className="
                      rounded-2xl
                      bg-gray-50
                      px-5
                      py-10
                      text-center
                    "
                  >
                    <div className="text-4xl">
                      🏠
                    </div>

                    <p
                      className="
                        mt-3
                        text-sm
                        font-medium
                        text-gray-700
                      "
                    >
                      No properties found
                    </p>
                  </div>

                ) : (

                  <div
                    className="
                      grid
                      grid-cols-1
                      gap-4
                      sm:grid-cols-2
                      xl:grid-cols-3
                    "
                  >

                    {paginated.map(
                      (
                        item,
                        index
                      ) => {

                        const propertyId =
                          item?._id ||
                          item?.id ||
                          index;

                        const status =
                          item?.status ||
                          "unknown";

                        const statusClass =
                          status ===
                          "active"
                            ? "bg-green-500/90"
                            : status ===
                              "pending"
                            ? "bg-yellow-500/90"
                            : status ===
                              "sold"
                            ? "bg-red-500/90"
                            : status ===
                              "rented"
                            ? "bg-blue-500/90"
                            : "bg-gray-700/90";


                        const isLease =
                          item?.property_type
                            ?.name
                            ?.toLowerCase()
                            ?.includes(
                              "lease"
                            );


                        const amount =
                          isLease
                            ? item?.monthly_rent
                            : item?.sale_price;


                        return (
                          <article
                            key={
                              propertyId
                            }
                            className="
                              group
                              min-w-0
                              cursor-pointer
                              overflow-hidden
                              rounded-2xl
                              border
                              border-gray-100
                              bg-white
                              shadow-sm
                              transition-all
                              duration-300
                              hover:-translate-y-1
                              hover:shadow-xl
                            "
                            onClick={() =>
                              navigate(
                                `/property/${propertyId}`
                              )
                            }
                          >

                            {/* IMAGE */}

                            <div
                              className="
                                relative
                                aspect-[16/10]
                                overflow-hidden
                                bg-gray-100
                              "
                            >

                              <img
                                src={
                                  getPropertyImage(
                                    item
                                  )
                                }
                                alt={
                                  item?.title ||
                                  "Property"
                                }
                                loading="lazy"
                                className="
                                  h-full
                                  w-full
                                  object-cover
                                  transition
                                  duration-500
                                  group-hover:scale-105
                                "
                              />

                              <span
                                className={`
                                  absolute
                                  right-3
                                  top-3
                                  rounded-full
                                  px-3
                                  py-1.5
                                  text-[10px]
                                  font-semibold
                                  text-white
                                  backdrop-blur
                                  ${statusClass}
                                `}
                              >
                                {
                                  status
                                    .charAt(
                                      0
                                    )
                                    .toUpperCase() +
                                    status.slice(
                                      1
                                    )
                                }
                              </span>

                            </div>


                            {/* CONTENT */}

                            <div
                              className="
                                p-4
                              "
                            >

                              <h3
                                className="
                                  line-clamp-2
                                  text-sm
                                  font-bold
                                  leading-5
                                  text-gray-900
                                "
                              >
                                {
                                  item?.title ||
                                  "Property"
                                }
                              </h3>


                              <p
                                className="
                                  mt-2
                                  line-clamp-1
                                  text-xs
                                  text-gray-500
                                "
                              >
                                📍{" "}
                                {item?.location ||
                                  "Location unavailable"}
                              </p>


                              <div
                                className="
                                  mt-4
                                  flex
                                  items-center
                                  justify-between
                                  gap-3
                                  border-t
                                  border-gray-100
                                  pt-4
                                "
                              >

                                <div
                                  className="
                                    min-w-0
                                  "
                                >

                                  <p
                                    className="
                                      text-[10px]
                                      uppercase
                                      tracking-wide
                                      text-gray-400
                                    "
                                  >
                                    {isLease
                                      ? "Monthly Rent"
                                      : "Price"}
                                  </p>

                                  <p
                                    className="
                                      mt-0.5
                                      truncate
                                      text-sm
                                      font-bold
                                      text-sky-600
                                    "
                                  >
                                    {amount
                                      ? `₹ ${Number(
                                          amount
                                        ).toLocaleString(
                                          "en-IN"
                                        )}`
                                      : "On Request"}
                                  </p>

                                </div>


                                <button
                                  type="button"
                                  onClick={(
                                    event
                                  ) => {

                                    event.stopPropagation();

                                    navigate(
                                      `/property/${propertyId}`
                                    );

                                  }}
                                  className="
                                    shrink-0
                                    rounded-xl
                                    bg-sky-500
                                    px-4
                                    py-2.5
                                    text-xs
                                    font-semibold
                                    text-white
                                    transition
                                    hover:bg-sky-600
                                  "
                                >
                                  View
                                </button>

                              </div>

                            </div>

                          </article>
                        );

                      }
                    )}

                  </div>

                )}


                {/* PAGINATION */}

                {renderPagination()}

              </section>

            </div>

          </div>

        </div>

      </main>

      <Footer />
    </>
  );
};


/*
|--------------------------------------------------------------------------
| CONTACT ROW
|--------------------------------------------------------------------------
*/

const ContactRow = ({
  icon,
  label,
  value,
}) => {

  return (
    <div
      className="
        flex
        min-w-0
        items-start
        gap-3
      "
    >

      <div
        className="
          flex
          h-9
          w-9
          shrink-0
          items-center
          justify-center
          rounded-xl
          bg-sky-50
          text-sky-500
        "
      >
        {icon}
      </div>

      <div
        className="
          min-w-0
        "
      >

        <p
          className="
            text-[10px]
            uppercase
            tracking-wide
            text-gray-400
          "
        >
          {label}
        </p>

        <p
          className="
            mt-0.5
            break-words
            text-xs
            font-medium
            text-gray-700
          "
        >
          {value ||
            "N/A"}
        </p>

      </div>

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| SOCIAL BUTTON
|--------------------------------------------------------------------------
*/

const SocialButton = ({
  href,
  icon,
}) => {

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="
        flex
        h-10
        w-10
        items-center
        justify-center
        rounded-full
        bg-gray-100
        text-gray-600
        transition-all
        duration-300
        hover:bg-sky-500
        hover:text-white
      "
    >
      {icon}
    </a>
  );
};


/*
|--------------------------------------------------------------------------
| INFO CARD
|--------------------------------------------------------------------------
*/

const InfoCard = ({
  icon,
  label,
  value,
}) => {

  return (
    <div
      className="
        flex
        min-w-0
        items-start
        gap-3
        rounded-2xl
        border
        border-gray-100
        bg-gray-50
        p-4
      "
    >

      <div
        className="
          flex
          h-10
          w-10
          shrink-0
          items-center
          justify-center
          rounded-xl
          bg-sky-100
          text-sky-500
        "
      >
        {icon}
      </div>

      <div
        className="
          min-w-0
        "
      >

        <p
          className="
            text-[10px]
            uppercase
            tracking-wide
            text-gray-400
          "
        >
          {label}
        </p>

        <p
          className="
            mt-1
            break-words
            text-sm
            font-semibold
            text-gray-800
          "
        >
          {value ||
            "N/A"}
        </p>

      </div>

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| STAT CARD
|--------------------------------------------------------------------------
*/

const StatCard = ({
  label,
  value,
}) => {

  return (
    <div
      className="
        min-w-0
        rounded-2xl
        border
        border-sky-100
        bg-gradient-to-br
        from-sky-50
        to-white
        p-4
        text-center
        shadow-sm
        transition
        hover:-translate-y-0.5
        hover:shadow-md
        sm:p-5
      "
    >

      <p
        className="
          text-[10px]
          font-medium
          uppercase
          tracking-wide
          text-gray-500
          sm:text-xs
        "
      >
        {label}
      </p>

      <p
        className="
          mt-2
          text-2xl
          font-extrabold
          text-sky-600
          sm:text-3xl
        "
      >
        {value}
      </p>

    </div>
  );
};


export default AgentProfile;
