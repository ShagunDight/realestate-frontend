import React, {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  IoIosArrowBack,
  IoIosArrowForward,
} from "react-icons/io";

import {
  FaMapMarkerAlt,
  FaPhone,
  FaEnvelope,
  FaInstagram,
  FaFacebookF,
  FaLinkedinIn,
  FaArrowRight,
} from "react-icons/fa";

import Footer from "../components/Footer";


const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";

const FALLBACK_IMAGE =
  "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg";


const ContactUs = () => {

  /*
  |--------------------------------------------------------------------------
  | STATE
  |--------------------------------------------------------------------------
  */

  const [
    offices,
    setOffices,
  ] = useState([]);

  const [
    propertyTypes,
    setPropertyTypes,
  ] = useState([]);

  const [
    currentOfficeImage,
    setCurrentOfficeImage,
  ] = useState(0);

  const [
    loading,
    setLoading,
  ] = useState(false);

  const [
    officeLoading,
    setOfficeLoading,
  ] = useState(true);

  const [
    propertyTypeLoading,
    setPropertyTypeLoading,
  ] = useState(true);

  const [
    formData,
    setFormData,
  ] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    location: "",
    property_type_id: "",
    budget: "",
    inquiry_type: "",
    message: "",
    agree: false,
  });


  /*
  |--------------------------------------------------------------------------
  | FETCH DATA
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    fetchOffices();
    fetchPropertyTypes();

  }, []);


  /*
  |--------------------------------------------------------------------------
  | FETCH OFFICES
  |--------------------------------------------------------------------------
  */

  const fetchOffices =
    async () => {

      try {

        setOfficeLoading(
          true
        );

        const response =
          await fetch(
            `${API_BASE}/api/information`
          );

        if (!response.ok) {
          throw new Error(
            "Unable to fetch offices"
          );
        }

        const data =
          await response.json();

        setOffices(
          Array.isArray(data)
            ? data
            : Array.isArray(
                data?.data
              )
            ? data.data
            : []
        );

      } catch (error) {

        console.error(
          "Office fetch error:",
          error
        );

        setOffices([]);

      } finally {

        setOfficeLoading(
          false
        );

      }
    };


  /*
  |--------------------------------------------------------------------------
  | FETCH PROPERTY TYPES
  |--------------------------------------------------------------------------
  */

  const fetchPropertyTypes =
    async () => {

      try {

        setPropertyTypeLoading(
          true
        );

        const response =
          await fetch(
            `${API_BASE}/api/property-types`
          );

        if (!response.ok) {
          throw new Error(
            "Unable to fetch property types"
          );
        }

        const data =
          await response.json();

        setPropertyTypes(
          Array.isArray(
            data?.data
          )
            ? data.data
            : Array.isArray(
                data
              )
            ? data
            : []
        );

      } catch (error) {

        console.error(
          "Property type error:",
          error
        );

        setPropertyTypes([]);

      } finally {

        setPropertyTypeLoading(
          false
        );

      }
    };


  /*
  |--------------------------------------------------------------------------
  | OFFICE IMAGES
  |--------------------------------------------------------------------------
  */

  const officeImages =
    useMemo(() => {

      return offices
        .filter(
          (office) =>
            Array.isArray(
              office?.images
            ) &&
            office.images.length >
              0
        )
        .map(
          (office) =>
            office.images[0]
        )
        .filter(Boolean);

    }, [offices]);


  /*
  |--------------------------------------------------------------------------
  | OFFICE IMAGE NAVIGATION
  |--------------------------------------------------------------------------
  */

  const nextOfficeImage =
    () => {

      if (
        officeImages.length <=
        1
      ) {
        return;
      }

      setCurrentOfficeImage(
        (prev) =>
          prev >=
          officeImages.length -
            1
            ? 0
            : prev + 1
      );

    };


  const prevOfficeImage =
    () => {

      if (
        officeImages.length <=
        1
      ) {
        return;
      }

      setCurrentOfficeImage(
        (prev) =>
          prev <= 0
            ? officeImages.length -
              1
            : prev - 1
      );

    };


  /*
  |--------------------------------------------------------------------------
  | FORM CHANGE
  |--------------------------------------------------------------------------
  */

  const handleChange =
    (event) => {

      const {
        name,
        value,
        type,
        checked,
      } = event.target;

      setFormData(
        (prev) => ({
          ...prev,
          [name]:
            type ===
            "checkbox"
              ? checked
              : value,
        })
      );

    };


  /*
  |--------------------------------------------------------------------------
  | FORM SUBMIT
  |--------------------------------------------------------------------------
  */

  const handleSubmit =
    async (event) => {

      event.preventDefault();

      if (
        !formData.agree
      ) {

        alert(
          "Please accept Terms & Privacy Policy"
        );

        return;

      }

      try {

        setLoading(true);

        const response =
          await fetch(
            `${API_BASE}/api/contact-inquiry`,
            {
              method: "POST",

              headers: {
                "Content-Type":
                  "application/json",

                Accept:
                  "application/json",
              },

              body:
                JSON.stringify(
                  formData
                ),
            }
          );

        const data =
          await response.json();

        if (
          response.ok
        ) {

          alert(
            data?.message ||
              "Inquiry submitted successfully!"
          );

          setFormData({
            first_name: "",
            last_name: "",
            email: "",
            phone: "",
            location: "",
            property_type_id: "",
            budget: "",
            inquiry_type: "",
            message: "",
            agree: false,
          });

        } else {

          alert(
            data?.message ||
              "Something went wrong"
          );

        }

      } catch (error) {

        console.error(
          "Contact form error:",
          error
        );

        alert(
          "Server Error. Please try again later."
        );

      } finally {

        setLoading(false);

      }

    };


  return (
    <>
      <main
        className="
          min-h-screen
          bg-[#f6f9ff]
          pb-10
          lg:pb-14
        "
      >

        {/* =====================================================
            HERO
        ====================================================== */}

        <section
          className="
            bg-gradient-to-b
            from-sky-50
            to-white
            px-3
            py-8
            sm:px-5
            sm:py-10
            lg:px-8
            lg:py-14
          "
        >

          <div
            className="
              mx-auto
              w-full
              max-w-[1380px]
            "
          >

            <div
              className="
                max-w-3xl
              "
            >

              <div
                className="
                  flex
                  items-center
                  gap-1.5
                "
              >

                <span
                  className="
                    h-1.5
                    w-1.5
                    rounded-full
                    bg-sky-300
                  "
                />

                <span
                  className="
                    h-2.5
                    w-2.5
                    rounded-full
                    bg-sky-500
                  "
                />

                <span
                  className="
                    h-1.5
                    w-1.5
                    rounded-full
                    bg-sky-300
                  "
                />

              </div>


              <p
                className="
                  mt-3
                  text-[10px]
                  font-bold
                  uppercase
                  tracking-[0.18em]
                  text-sky-500
                  sm:text-xs
                "
              >
                Get In Touch
              </p>


              <h1
                className="
                  mt-2
                  break-words
                  text-3xl
                  font-extrabold
                  leading-tight
                  tracking-tight
                  text-gray-900
                  sm:text-4xl
                  md:text-5xl
                "
              >
                Get in Touch with Estatein
              </h1>


              <p
                className="
                  mt-4
                  max-w-3xl
                  text-sm
                  leading-7
                  text-gray-600
                  sm:text-base
                "
              >
                Welcome to Estatein's Contact Us page.
                We're here to assist you with inquiries,
                requests, feedback, property opportunities,
                investment questions, and more.
              </p>

            </div>

          </div>

        </section>


        {/* =====================================================
            OFFICE LOCATIONS
        ====================================================== */}

        <section
          className="
            px-3
            py-8
            sm:px-5
            sm:py-10
            lg:px-8
            lg:py-12
          "
        >

          <div
            className="
              mx-auto
              w-full
              max-w-[1380px]
            "
          >

            <SectionHeading
              eyebrow="Our Locations"
              title="Discover Our Office Locations"
              description="Explore our office locations and connect directly with our team."
            />


            {/* LOADING */}

            {officeLoading ? (

              <div
                className="
                  mt-7
                  grid
                  grid-cols-1
                  gap-4
                "
              >

                {Array.from(
                  {
                    length: 2,
                  },
                  (_, index) => (
                    <div
                      key={
                        index
                      }
                      className="
                        h-48
                        animate-pulse
                        rounded-2xl
                        bg-white
                        shadow-sm
                      "
                    />
                  )
                )}

              </div>

            ) : offices.length === 0 ? (

              <div
                className="
                  mt-7
                  rounded-2xl
                  border
                  border-dashed
                  border-sky-200
                  bg-white
                  px-5
                  py-12
                  text-center
                "
              >
                <div className="text-4xl">
                  📍
                </div>

                <p
                  className="
                    mt-3
                    text-sm
                    font-semibold
                    text-gray-700
                  "
                >
                  No office locations available.
                </p>
              </div>

            ) : (

              <div
                className="
                  mt-7
                  space-y-4
                  sm:space-y-5
                "
              >

                {offices.map(
                  (
                    item,
                    index
                  ) => {

                    const socialLinks =
                      Object.entries(
                        item?.social_links ||
                          {}
                      ).filter(
                        ([, url]) =>
                          url &&
                          url.trim()
                      );

                    const mapQuery =
                      encodeURIComponent(
                        item?.location ||
                          item?.address ||
                          ""
                      );

                    const mapUrl =
                      `https://www.google.com/maps/search/?api=1&query=${mapQuery}`;


                    return (
                      <article
                        key={
                          item?._id ||
                          item?.id ||
                          index
                        }
                        className="
                          min-w-0
                          overflow-hidden
                          rounded-[24px]
                          border
                          border-sky-100
                          bg-white
                          p-5
                          shadow-sm
                          transition
                          hover:-translate-y-0.5
                          hover:shadow-lg
                          sm:p-6
                          lg:p-7
                        "
                      >

                        {/* TOP */}

                        <div
                          className="
                            flex
                            flex-col
                            gap-4
                            sm:flex-row
                            sm:items-start
                            sm:justify-between
                          "
                        >

                          <div
                            className="
                              min-w-0
                            "
                          >

                            <span
                              className="
                                inline-flex
                                max-w-full
                                rounded-full
                                bg-sky-50
                                px-3
                                py-1.5
                                text-[10px]
                                font-semibold
                                text-sky-600
                                sm:text-xs
                              "
                            >
                              {item?.location_type ||
                                "Office"}
                            </span>


                            <h3
                              className="
                                mt-3
                                break-words
                                text-lg
                                font-bold
                                text-gray-900
                                sm:text-xl
                              "
                            >
                              {item?.address ||
                                item?.location ||
                                "Office Location"}
                            </h3>

                          </div>


                          {/* SOCIAL */}

                          {socialLinks.length >
                            0 && (

                            <div
                              className="
                                flex
                                shrink-0
                                gap-2
                              "
                            >

                              {socialLinks.map(
                                (
                                  [
                                    key,
                                    url,
                                  ],
                                  idx
                                ) => {

                                  let Icon =
                                    null;

                                  switch (
                                    key.toLowerCase()
                                  ) {

                                    case "instagram":
                                      Icon =
                                        FaInstagram;
                                      break;

                                    case "facebook":
                                      Icon =
                                        FaFacebookF;
                                      break;

                                    case "linkedin":
                                      Icon =
                                        FaLinkedinIn;
                                      break;

                                    default:
                                      return null;
                                  }


                                  return (
                                    <a
                                      key={
                                        idx
                                      }
                                      href={
                                        url.startsWith(
                                          "http"
                                        )
                                          ? url
                                          : `https://${url}`
                                      }
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="
                                        flex
                                        h-9
                                        w-9
                                        items-center
                                        justify-center
                                        rounded-full
                                        bg-sky-50
                                        text-sky-600
                                        transition
                                        hover:bg-sky-500
                                        hover:text-white
                                      "
                                    >
                                      <Icon
                                        size={
                                          14
                                        }
                                      />
                                    </a>
                                  );
                                }
                              )}

                            </div>

                          )}

                        </div>


                        {/* DESCRIPTION */}

                        <p
                          className="
                            mt-3
                            max-w-3xl
                            text-xs
                            leading-6
                            text-gray-500
                            sm:text-sm
                          "
                        >
                          {item?.short_description ||
                            "No description available."}
                        </p>


                        {/* CONTACT DETAILS */}

                        <div
                          className="
                            mt-6
                            grid
                            grid-cols-1
                            gap-3
                            sm:grid-cols-2
                            lg:grid-cols-3
                          "
                        >

                          <OfficeInfo
                            icon={
                              <FaEnvelope />
                            }
                            label="Email"
                            value={
                              item?.email
                            }
                          />

                          <OfficeInfo
                            icon={
                              <FaPhone />
                            }
                            label="Phone"
                            value={
                              item?.phone
                            }
                          />

                          <OfficeInfo
                            icon={
                              <FaMapMarkerAlt />
                            }
                            label="Location"
                            value={
                              item?.location ||
                              item?.address
                            }
                          />

                        </div>


                        {/* ACTION */}

                        <div
                          className="
                            mt-6
                            flex
                            flex-col
                            gap-3
                            border-t
                            border-gray-100
                            pt-5
                            sm:flex-row
                            sm:justify-end
                          "
                        >

                          <a
                            href={mapUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="
                              inline-flex
                              min-h-[44px]
                              items-center
                              justify-center
                              gap-2
                              rounded-xl
                              bg-sky-500
                              px-5
                              py-2.5
                              text-xs
                              font-semibold
                              text-white
                              shadow-sm
                              transition
                              hover:bg-sky-600
                              sm:w-fit
                            "
                          >
                            Get Direction

                            <FaArrowRight
                              size={
                                10
                              }
                            />
                          </a>

                        </div>

                      </article>
                    );

                  }
                )}

              </div>

            )}

          </div>

        </section>


        {/* =====================================================
            LET'S CONNECT
        ====================================================== */}

        <section
          className="
            px-3
            py-6
            sm:px-5
            lg:px-8
          "
        >

          <div
            className="
              mx-auto
              w-full
              max-w-[1250px]
            "
          >

            <div
              className="
                rounded-[26px]
                border
                border-sky-100
                bg-white
                p-5
                shadow-sm
                sm:p-7
                lg:p-10
              "
            >

              <SectionHeading
                eyebrow="Let's Connect"
                title="Tell Us What You're Looking For"
                description="We're excited to connect with you and learn more about your real estate goals."
              />


              {/* FORM */}

              <form
                onSubmit={
                  handleSubmit
                }
                className="
                  mt-8
                "
              >

                <div
                  className="
                    grid
                    grid-cols-1
                    gap-4
                    sm:grid-cols-2
                    lg:grid-cols-3
                  "
                >

                  {/* FIRST NAME */}

                  <FormInput
                    name="first_name"
                    value={
                      formData.first_name
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Enter First Name"
                    required
                  />


                  {/* LAST NAME */}

                  <FormInput
                    name="last_name"
                    value={
                      formData.last_name
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Enter Last Name"
                    required
                  />


                  {/* EMAIL */}

                  <FormInput
                    type="email"
                    name="email"
                    value={
                      formData.email
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Enter your Email"
                    required
                  />


                  {/* PHONE */}

                  <FormInput
                    type="tel"
                    name="phone"
                    value={
                      formData.phone
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Enter Phone Number"
                    required
                  />


                  {/* LOCATION */}

                  <FormInput
                    name="location"
                    value={
                      formData.location
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Enter Location"
                  />


                  {/* PROPERTY TYPE */}

                  <div
                    className="
                      min-w-0
                    "
                  >

                    <select
                      name="property_type_id"
                      value={
                        formData.property_type_id
                      }
                      onChange={
                        handleChange
                      }
                      required
                      className="
                        h-12
                        w-full
                        min-w-0
                        rounded-xl
                        border
                        border-sky-100
                        bg-gray-50
                        px-4
                        text-sm
                        text-gray-700
                        outline-none
                        transition
                        focus:border-sky-400
                        focus:bg-white
                        focus:ring-2
                        focus:ring-sky-100
                      "
                    >

                      <option value="">
                        {propertyTypeLoading
                          ? "Loading Property Types..."
                          : "Select Property Type"}
                      </option>

                      {propertyTypes.map(
                        (
                          type
                        ) => (
                          <option
                            key={
                              type?._id ||
                              type?.id
                            }
                            value={
                              type?._id ||
                              type?.id
                            }
                          >
                            {
                              type?.name
                            }
                          </option>
                        )
                      )}

                    </select>

                  </div>


                  {/* BUDGET */}

                  <div
                    className="
                      min-w-0
                    "
                  >

                    <select
                      name="budget"
                      value={
                        formData.budget
                      }
                      onChange={
                        handleChange
                      }
                      required
                      className="
                        h-12
                        w-full
                        min-w-0
                        rounded-xl
                        border
                        border-sky-100
                        bg-gray-50
                        px-4
                        text-sm
                        text-gray-700
                        outline-none
                        transition
                        focus:border-sky-400
                        focus:bg-white
                        focus:ring-2
                        focus:ring-sky-100
                      "
                    >

                      <option value="">
                        Select Budget
                      </option>

                      <option value="0-500000">
                        Below ₹5 Lac
                      </option>

                      <option value="500000-1000000">
                        ₹5 Lac - ₹10 Lac
                      </option>

                      <option value="1000000-5000000">
                        ₹10 Lac - ₹50 Lac
                      </option>

                      <option value="5000000-10000000">
                        ₹50 Lac - ₹1 Cr
                      </option>

                      <option value="10000000+">
                        Above ₹1 Cr
                      </option>

                    </select>

                  </div>


                  {/* INQUIRY TYPE */}

                  <div
                    className="
                      min-w-0
                    "
                  >

                    <select
                      name="inquiry_type"
                      value={
                        formData.inquiry_type
                      }
                      onChange={
                        handleChange
                      }
                      required
                      className="
                        h-12
                        w-full
                        min-w-0
                        rounded-xl
                        border
                        border-sky-100
                        bg-gray-50
                        px-4
                        text-sm
                        text-gray-700
                        outline-none
                        transition
                        focus:border-sky-400
                        focus:bg-white
                        focus:ring-2
                        focus:ring-sky-100
                      "
                    >

                      <option value="">
                        Select Inquiry Type
                      </option>

                      <option value="buy">
                        Buy Property
                      </option>

                      <option value="rent">
                        Rent Property
                      </option>

                      <option value="investment">
                        Investment
                      </option>

                      <option value="commercial">
                        Commercial Inquiry
                      </option>

                    </select>

                  </div>

                </div>


                {/* MESSAGE */}

                <textarea
                  name="message"
                  value={
                    formData.message
                  }
                  onChange={
                    handleChange
                  }
                  placeholder="Enter your Message here..."
                  rows={5}
                  required
                  className="
                    mt-4
                    min-h-[130px]
                    w-full
                    resize-none
                    rounded-xl
                    border
                    border-sky-100
                    bg-gray-50
                    px-4
                    py-3
                    text-sm
                    text-gray-700
                    outline-none
                    transition
                    focus:border-sky-400
                    focus:bg-white
                    focus:ring-2
                    focus:ring-sky-100
                  "
                />


                {/* FORM FOOTER */}

                <div
                  className="
                    mt-5
                    flex
                    flex-col
                    gap-4
                    sm:flex-row
                    sm:items-center
                    sm:justify-between
                  "
                >

                  <label
                    className="
                      flex
                      items-start
                      gap-2
                      text-xs
                      leading-5
                      text-gray-500
                    "
                  >

                    <input
                      type="checkbox"
                      name="agree"
                      checked={
                        formData.agree
                      }
                      onChange={
                        handleChange
                      }
                      className="
                        mt-0.5
                        h-4
                        w-4
                        shrink-0
                        accent-sky-500
                      "
                    />

                    <span>
                      I agree with Terms of Use and
                      Privacy Policy
                    </span>

                  </label>


                  <button
                    type="submit"
                    disabled={
                      loading
                    }
                    className="
                      inline-flex
                      min-h-[48px]
                      w-full
                      items-center
                      justify-center
                      rounded-xl
                      bg-sky-500
                      px-6
                      py-3
                      text-sm
                      font-semibold
                      text-white
                      shadow-md
                      transition
                      hover:bg-sky-600
                      active:scale-[0.98]
                      disabled:cursor-not-allowed
                      disabled:opacity-50
                      sm:w-fit
                    "
                  >
                    {loading
                      ? "Sending..."
                      : "Send Your Message"}

                    {!loading && (
                      <FaArrowRight
                        className="
                          ml-2
                          text-[10px]
                        "
                      />
                    )}

                  </button>

                </div>

              </form>

            </div>

          </div>

        </section>


        {/* =====================================================
            ESTATEIN WORLD
        ====================================================== */}

        <section
          className="
            px-3
            py-8
            sm:px-5
            sm:py-12
            lg:px-8
            lg:py-14
          "
        >

          <div
            className="
              mx-auto
              w-full
              max-w-[1380px]
              rounded-[26px]
              border
              border-sky-100
              bg-white
              p-5
              shadow-sm
              sm:p-7
              lg:p-10
            "
          >

            <SectionHeading
              eyebrow="Our World"
              title="Explore Estatein's World"
              description="Step inside the world of Estatein, where professionalism meets warmth and expertise meets passion."
            />


            <div
              className="
                mt-8
                grid
                grid-cols-1
                gap-5
                lg:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]
              "
            >

              {/* GALLERY */}

              <div
                className="
                  relative
                  min-w-0
                  overflow-hidden
                  rounded-[24px]
                  bg-gray-100
                  shadow-xl
                "
              >

                <div
                  className="
                    aspect-[4/3]
                    w-full
                    sm:aspect-[16/9]
                  "
                >

                  <img
                    src={
                      officeImages.length
                        ? officeImages[
                            currentOfficeImage
                          ]
                        : FALLBACK_IMAGE
                    }
                    alt="Estatein Office"
                    className="
                      block
                      h-full
                      w-full
                      object-cover
                      transition
                      duration-700
                    "
                  />

                </div>


                {/* GRADIENT */}

                <div
                  className="
                    pointer-events-none
                    absolute
                    inset-x-0
                    bottom-0
                    h-1/2
                    bg-gradient-to-t
                    from-black/65
                    via-black/10
                    to-transparent
                  "
                />


                {/* LABEL */}

                <div
                  className="
                    absolute
                    left-3
                    top-3
                    rounded-full
                    bg-white/90
                    px-3
                    py-1.5
                    text-[10px]
                    font-semibold
                    text-gray-700
                    backdrop-blur
                    sm:left-4
                    sm:top-4
                  "
                >
                  Office Gallery
                </div>


                {/* COUNTER */}

                {officeImages.length >
                  1 && (
                  <div
                    className="
                      absolute
                      right-3
                      top-3
                      rounded-full
                      bg-black/40
                      px-3
                      py-1.5
                      text-[10px]
                      font-semibold
                      text-white
                      backdrop-blur
                      sm:right-4
                      sm:top-4
                    "
                  >
                    {currentOfficeImage +
                      1}{" "}
                    /{" "}
                    {officeImages.length}
                  </div>
                )}


                {/* NAVIGATION */}

                {officeImages.length >
                  1 && (
                  <>

                    <button
                      type="button"
                      onClick={
                        prevOfficeImage
                      }
                      className="
                        absolute
                        left-3
                        top-1/2
                        flex
                        h-10
                        w-10
                        -translate-y-1/2
                        items-center
                        justify-center
                        rounded-full
                        bg-white/90
                        text-gray-700
                        shadow
                        transition
                        hover:bg-white
                        sm:left-4
                        sm:h-11
                        sm:w-11
                      "
                    >
                      <IoIosArrowBack />
                    </button>


                    <button
                      type="button"
                      onClick={
                        nextOfficeImage
                      }
                      className="
                        absolute
                        right-3
                        top-1/2
                        flex
                        h-10
                        w-10
                        -translate-y-1/2
                        items-center
                        justify-center
                        rounded-full
                        bg-white/90
                        text-gray-700
                        shadow
                        transition
                        hover:bg-white
                        sm:right-4
                        sm:h-11
                        sm:w-11
                      "
                    >
                      <IoIosArrowForward />
                    </button>

                  </>
                )}


                {/* THUMBNAILS */}

                {officeImages.length >
                  1 && (
                  <div
                    className="
                      absolute
                      bottom-3
                      left-1/2
                      flex
                      max-w-[85%]
                      -translate-x-1/2
                      gap-1.5
                      overflow-x-auto
                      rounded-xl
                      bg-black/30
                      p-1.5
                      backdrop-blur
                      scrollbar-hide
                      sm:bottom-4
                      sm:gap-2
                    "
                  >

                    {officeImages.map(
                      (
                        image,
                        index
                      ) => (
                        <button
                          type="button"
                          key={
                            index
                          }
                          onClick={() =>
                            setCurrentOfficeImage(
                              index
                            )
                          }
                          className={`
                            h-9
                            w-11
                            shrink-0
                            overflow-hidden
                            rounded-md
                            border-2
                            transition
                            sm:h-10
                            sm:w-12

                            ${
                              index ===
                              currentOfficeImage
                                ? "border-white"
                                : "border-transparent opacity-70 hover:opacity-100"
                            }
                          `}
                        >

                          <img
                            src={
                              image
                            }
                            alt=""
                            className="
                              h-full
                              w-full
                              object-cover
                            "
                          />

                        </button>
                      )
                    )}

                  </div>
                )}

              </div>


              {/* RIGHT INFO */}

              <div
                className="
                  flex
                  min-w-0
                  flex-col
                  justify-center
                  rounded-[22px]
                  bg-sky-50
                  p-5
                  sm:p-7
                "
              >

                <p
                  className="
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.16em]
                    text-sky-600
                    sm:text-xs
                  "
                >
                  Our Workspace
                </p>


                <h3
                  className="
                    mt-2
                    break-words
                    text-xl
                    font-bold
                    text-gray-900
                    sm:text-2xl
                  "
                >
                  Our Workspace & Team
                </h3>


                <p
                  className="
                    mt-3
                    text-sm
                    leading-7
                    text-gray-600
                  "
                >
                  Explore our professional environment
                  where creativity and expertise come
                  together to deliver the best real estate
                  experience.
                </p>


                <div
                  className="
                    mt-6
                    space-y-3
                  "
                >

                  <FeatureLine>
                    Modern Office Setup
                  </FeatureLine>

                  <FeatureLine>
                    Professional Team
                  </FeatureLine>

                  <FeatureLine>
                    Client-Friendly Environment
                  </FeatureLine>

                </div>

              </div>

            </div>

          </div>

        </section>

      </main>

      <Footer />
    </>
  );
};


/*
|--------------------------------------------------------------------------
| SECTION HEADING
|--------------------------------------------------------------------------
*/

const SectionHeading = ({
  eyebrow,
  title,
  description,
}) => {

  return (
    <div
      className="
        max-w-3xl
      "
    >

      <div
        className="
          flex
          items-center
          gap-1.5
        "
      >

        <span
          className="
            h-1.5
            w-1.5
            rounded-full
            bg-sky-300
          "
        />

        <span
          className="
            h-2.5
            w-2.5
            rounded-full
            bg-sky-500
          "
        />

        <span
          className="
            h-1.5
            w-1.5
            rounded-full
            bg-sky-300
          "
        />

      </div>


      <p
        className="
          mt-3
          text-[10px]
          font-bold
          uppercase
          tracking-[0.18em]
          text-sky-500
          sm:text-xs
        "
      >
        {eyebrow}
      </p>


      <h2
        className="
          mt-1
          break-words
          text-2xl
          font-bold
          text-gray-900
          sm:text-3xl
        "
      >
        {title}
      </h2>


      {description && (
        <p
          className="
            mt-2
            max-w-2xl
            text-xs
            leading-6
            text-gray-500
            sm:text-sm
          "
        >
          {description}
        </p>
      )}

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| OFFICE INFO
|--------------------------------------------------------------------------
*/

const OfficeInfo = ({
  icon,
  label,
  value,
}) => {

  return (
    <div
      className="
        flex
        min-w-0
        items-start
        gap-3
        rounded-xl
        bg-gray-50
        p-3
      "
    >

      <div
        className="
          flex
          h-9
          w-9
          shrink-0
          items-center
          justify-center
          rounded-xl
          bg-sky-100
          text-sky-500
        "
      >
        {icon}
      </div>

      <div
        className="
          min-w-0
        "
      >

        <p
          className="
            text-[10px]
            uppercase
            tracking-wide
            text-gray-400
          "
        >
          {label}
        </p>

        <p
          className="
            mt-0.5
            break-words
            text-xs
            font-medium
            text-gray-700
          "
        >
          {value ||
            "N/A"}
        </p>

      </div>

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| FORM INPUT
|--------------------------------------------------------------------------
*/

const FormInput = ({
  type = "text",
  name,
  value,
  onChange,
  placeholder,
  required = false,
}) => {

  return (
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      required={required}
      className="
        h-12
        w-full
        min-w-0
        rounded-xl
        border
        border-sky-100
        bg-gray-50
        px-4
        text-sm
        text-gray-700
        outline-none
        transition
        placeholder:text-gray-400
        focus:border-sky-400
        focus:bg-white
        focus:ring-2
        focus:ring-sky-100
      "
    />
  );
};


/*
|--------------------------------------------------------------------------
| FEATURE LINE
|--------------------------------------------------------------------------
*/

const FeatureLine = ({
  children,
}) => {

  return (
    <div
      className="
        flex
        items-center
        gap-3
        rounded-xl
        bg-white/70
        px-3
        py-3
        text-xs
        font-medium
        text-gray-700
      "
    >

      <span
        className="
          flex
          h-6
          w-6
          shrink-0
          items-center
          justify-center
          rounded-full
          bg-sky-500
          text-xs
          text-white
        "
      >
        ✓
      </span>

      <span>
        {children}
      </span>

    </div>
  );
};


export default ContactUs;