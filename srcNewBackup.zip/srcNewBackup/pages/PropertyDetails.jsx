import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  useParams,
  useNavigate,
  Link,
} from "react-router-dom";

import {
  IoIosArrowBack,
  IoIosArrowForward,
} from "react-icons/io";

import {
  FaHeart,
  FaRegHeart,
  FaMapMarkerAlt,
  FaPhone,
  FaPhoneAlt,
  FaWhatsapp,
  FaBuilding,
  FaRulerCombined,
  FaParking,
  FaCalendarAlt,
  FaBolt,
  FaExpand,
  FaCheck,
} from "react-icons/fa";

import { useWishlist } from "../components/WishlistContext";


/*
|--------------------------------------------------------------------------
| API
|--------------------------------------------------------------------------
*/

const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";

const FALLBACK_IMAGE =
  "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg";

const FALLBACK_AGENT_IMAGE =
  "https://img.freepik.com/premium-vector/secret-agent-icon-logo-design-illustration_586739-409.jpg";


const PropertyDetails = ({
  setShowLogin,
}) => {

  const {
    id,
  } = useParams();

  const navigate =
    useNavigate();

  const {
    toggleWishlist,
    isWished,
  } = useWishlist();


  /*
  |--------------------------------------------------------------------------
  | PROPERTY
  |--------------------------------------------------------------------------
  */

  const [
    property,
    setProperty,
  ] = useState(null);

  const [
    loadingProperty,
    setLoadingProperty,
  ] = useState(true);


  /*
  |--------------------------------------------------------------------------
  | GALLERY
  |--------------------------------------------------------------------------
  */

  const [
    currentImage,
    setCurrentImage,
  ] = useState(0);

  const [
    showGallery,
    setShowGallery,
  ] = useState(false);

  const [
    galleryIndex,
    setGalleryIndex,
  ] = useState(0);

  const thumbnailRef =
    useRef(null);


  /*
  |--------------------------------------------------------------------------
  | INQUIRY
  |--------------------------------------------------------------------------
  */

  const [
    inquiryType,
    setInquiryType,
  ] = useState("");

  const [
    selectedDate,
    setSelectedDate,
  ] = useState(null);

  const [
    name,
    setName,
  ] = useState("");

  const [
    email,
    setEmail,
  ] = useState("");

  const [
    phone,
    setPhone,
  ] = useState("");

  const [
    message,
    setMessage,
  ] = useState("");

  const [
    isMilitary,
    setIsMilitary,
  ] = useState(false);

  const [
    submitting,
    setSubmitting,
  ] = useState(false);


  /*
  |--------------------------------------------------------------------------
  | SOLD PROPERTIES
  |--------------------------------------------------------------------------
  */

  const [
    soldProperties,
    setSoldProperties,
  ] = useState([]);

  const [
    soldPage,
    setSoldPage,
  ] = useState(1);

  const soldPerPage = 4;


  /*
  |--------------------------------------------------------------------------
  | GALLERY ZOOM
  |--------------------------------------------------------------------------
  */

  const [
    zoom,
    setZoom,
  ] = useState(1);

  const [
    position,
    setPosition,
  ] = useState({
    x: 0,
    y: 0,
  });

  const [
    dragging,
    setDragging,
  ] = useState(false);

  const dragStart =
    useRef({
      x: 0,
      y: 0,
    });


  /*
  |--------------------------------------------------------------------------
  | FETCH PROPERTY
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    if (!id) {
      return;
    }

    const fetchProperty =
      async () => {
        try {

          setLoadingProperty(true);

          const response =
            await fetch(
              `${API_BASE}/api/properties/${id}`
            );

          if (!response.ok) {
            throw new Error(
              "Property fetch failed"
            );
          }

          const data =
            await response.json();

          setProperty(
            data?.data ||
            data
          );

        } catch (error) {

          console.error(
            "Property Details Error:",
            error
          );

          setProperty(null);

        } finally {

          setLoadingProperty(false);

        }
      };

    fetchProperty();

  }, [id]);


  /*
  |--------------------------------------------------------------------------
  | TRACK VIEW
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    if (!id) {
      return;
    }

    const trackView =
      async () => {
        try {

          await fetch(
            `${API_BASE}/api/property-view`,
            {
              method: "POST",
              headers: {
                "Content-Type":
                  "application/json",
              },
              body:
                JSON.stringify({
                  property_id: id,

                  customer_id:
                    localStorage.getItem(
                      "customer_id"
                    ) || null,

                  name:
                    localStorage.getItem(
                      "customer_name"
                    ) || null,

                  email:
                    localStorage.getItem(
                      "customer_email"
                    ) || null,

                  phone:
                    localStorage.getItem(
                      "customer_phone"
                    ) || null,
                }),
            }
          );

        } catch (error) {

          console.log(
            "Tracking failed:",
            error
          );

        }
      };

    trackView();

  }, [id]);


  /*
  |--------------------------------------------------------------------------
  | FETCH SOLD PROPERTIES
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    const fetchSoldProperties =
      async () => {

        try {

          const response =
            await fetch(
              `${API_BASE}/api/sold-properties`
            );

          if (!response.ok) {
            throw new Error(
              "Sold properties fetch failed"
            );
          }

          const data =
            await response.json();

          const result =
            Array.isArray(data)
              ? data
              : Array.isArray(
                  data?.data
                )
              ? data.data
              : [];

          setSoldProperties(
            result
          );

        } catch (error) {

          console.error(
            "Sold properties error:",
            error
          );

        }

      };

    fetchSoldProperties();

  }, []);


  /*
  |--------------------------------------------------------------------------
  | NORMALIZE IMAGES
  |--------------------------------------------------------------------------
  */

  const images = useMemo(() => {

    let result =
      property?.image;

    if (
      typeof result ===
      "string"
    ) {

      try {

        result =
          JSON.parse(result);

      } catch {

        result = [];

      }

    }

    return Array.isArray(result)
      ? result
      : [];

  }, [property]);


  /*
  |--------------------------------------------------------------------------
  | IMAGE URL
  |--------------------------------------------------------------------------
  */

  const getImageUrl =
    (image) => {

      if (!image) {
        return FALLBACK_IMAGE;
      }

      if (
        typeof image ===
          "object" &&
        image?.path
      ) {

        return `${API_BASE}/public/${image.path}`;

      }

      if (
        typeof image ===
        "string"
      ) {

        return `${API_BASE}/public/${image}`;

      }

      return FALLBACK_IMAGE;
    };


  /*
  |--------------------------------------------------------------------------
  | PROPERTY DATA
  |--------------------------------------------------------------------------
  */

  const propertyId =
    property?._id ||
    property?.id ||
    id;

  const propertyType =
    property?.property_type
      ?.name ||
    "Property";

  const typeName =
    propertyType.toLowerCase();

  const isLease =
    typeName.includes(
      "lease"
    ) ||
    typeName.includes(
      "rent"
    );

  const price =
    isLease
      ? property?.monthly_rent
      : property?.sale_price;

  const formattedPrice =
    price !== null &&
    price !== undefined &&
    price !== ""
      ? `₹ ${Number(
          price
        ).toLocaleString(
          "en-IN"
        )}`
      : "Price on Request";


  /*
  |--------------------------------------------------------------------------
  | STATUS
  |--------------------------------------------------------------------------
  */

  const statusStyles = {
    active:
      "bg-green-50 text-green-700 border-green-200",

    pending:
      "bg-yellow-50 text-yellow-700 border-yellow-200",

    sold:
      "bg-red-50 text-red-700 border-red-200",

    rented:
      "bg-purple-50 text-purple-700 border-purple-200",
  };

  const propertyStatus =
    property?.status ||
    "available";

  const statusClass =
    statusStyles[
      propertyStatus
    ] ||
    "bg-gray-50 text-gray-700 border-gray-200";


  /*
  |--------------------------------------------------------------------------
  | DATES
  |--------------------------------------------------------------------------
  */

  const nextDates =
    useMemo(() => {

      const today =
        new Date();

      return Array.from(
        {
          length: 15,
        },
        (_, index) => {

          const date =
            new Date();

          date.setDate(
            today.getDate() +
              index
          );

          return {

            day:
              date.toLocaleDateString(
                "en-US",
                {
                  weekday:
                    "short",
                }
              ),

            date:
              date.toLocaleDateString(
                "en-US",
                {
                  month:
                    "short",
                  day: "numeric",
                }
              ),

            fullDate:
              date
                .toISOString()
                .split("T")[0],
          };
        }
      );

    }, []);


  /*
  |--------------------------------------------------------------------------
  | SOLD PAGINATION
  |--------------------------------------------------------------------------
  */

  const soldTotalPages =
    Math.max(
      1,
      Math.ceil(
        soldProperties.length /
          soldPerPage
      )
    );

  const paginatedSold =
    soldProperties.slice(
      (soldPage - 1) *
        soldPerPage,

      soldPage *
        soldPerPage
    );


  /*
  |--------------------------------------------------------------------------
  | THUMBNAIL SCROLL
  |--------------------------------------------------------------------------
  */

  const scrollThumbs =
    (direction) => {

      thumbnailRef.current?.scrollBy(
        {
          left:
            direction ===
            "next"
              ? 240
              : -240,

          behavior:
            "smooth",
        }
      );

    };


  /*
  |--------------------------------------------------------------------------
  | IMAGE NAVIGATION
  |--------------------------------------------------------------------------
  */

  const nextImage =
    () => {

      if (
        !images.length
      ) {
        return;
      }

      setCurrentImage(
        (prev) =>
          prev >=
          images.length - 1
            ? 0
            : prev + 1
      );

    };


  const prevImage =
    () => {

      if (
        !images.length
      ) {
        return;
      }

      setCurrentImage(
        (prev) =>
          prev <= 0
            ? images.length - 1
            : prev - 1
      );

    };


  /*
  |--------------------------------------------------------------------------
  | OPEN FULL GALLERY
  |--------------------------------------------------------------------------
  */

  const openGallery =
    (index) => {

      setGalleryIndex(
        index
      );

      setZoom(1);

      setPosition({
        x: 0,
        y: 0,
      });

      setShowGallery(
        true
      );

    };


  /*
  |--------------------------------------------------------------------------
  | GALLERY NAVIGATION
  |--------------------------------------------------------------------------
  */

  const nextGallery =
    () => {

      if (
        !images.length
      ) {
        return;
      }

      setGalleryIndex(
        (prev) =>
          prev >=
          images.length - 1
            ? 0
            : prev + 1
      );

    };


  const prevGallery =
    () => {

      if (
        !images.length
      ) {
        return;
      }

      setGalleryIndex(
        (prev) =>
          prev <= 0
            ? images.length - 1
            : prev - 1
      );

    };


  /*
  |--------------------------------------------------------------------------
  | ZOOM
  |--------------------------------------------------------------------------
  */

  const resetZoom =
    () => {

      setZoom(1);

      setPosition({
        x: 0,
        y: 0,
      });

    };


  const handleWheel =
    (event) => {

      event.preventDefault();

      setZoom((prev) => {

        const next =
          prev +
          (
            event.deltaY <
            0
              ? 0.2
              : -0.2
          );

        return Math.min(
          Math.max(
            next,
            1
          ),
          3
        );

      });

    };


  const handleDoubleClick =
    () => {

      setZoom(
        (prev) =>
          prev === 1
            ? 2
            : 1
      );

      setPosition({
        x: 0,
        y: 0,
      });

    };


  const handleMouseDown =
    (event) => {

      if (
        zoom === 1
      ) {
        return;
      }

      setDragging(true);

      dragStart.current = {
        x:
          event.clientX -
          position.x,

        y:
          event.clientY -
          position.y,
      };

    };


  const handleMouseMove =
    (event) => {

      if (
        !dragging ||
        zoom === 1
      ) {
        return;
      }

      setPosition({
        x:
          event.clientX -
          dragStart.current
            .x,

        y:
          event.clientY -
          dragStart.current
            .y,
      });

    };


  const handleMouseUp =
    () => {

      setDragging(
        false
      );

    };


  /*
  |--------------------------------------------------------------------------
  | WISHLIST
  |--------------------------------------------------------------------------
  */

  const handleWishlist =
    () => {

      const loggedIn =
        !!localStorage.getItem(
          "customer_token"
        );

      if (
        !loggedIn
      ) {

        setShowLogin?.(
          true
        );

        return;

      }

      toggleWishlist(
        property
      );

    };


  /*
  |--------------------------------------------------------------------------
  | INQUIRY
  |--------------------------------------------------------------------------
  */

  const submitInquiry =
    async () => {

      if (
        !inquiryType ||
        !name ||
        !email ||
        !phone
      ) {

        alert(
          "Please fill all required fields"
        );

        return;

      }

      if (
        inquiryType ===
          "request_tour" &&
        !selectedDate
      ) {

        alert(
          "Please select a visit date"
        );

        return;

      }

      setSubmitting(
        true
      );

      try {

        const response =
          await fetch(
            `${API_BASE}/api/visit-request`,
            {
              method: "POST",

              headers: {
                "Content-Type":
                  "application/json",
              },

              body:
                JSON.stringify({
                  property_id:
                    id,

                  inquiry_type:
                    inquiryType,

                  date:
                    inquiryType ===
                    "request_tour"
                      ? selectedDate
                      : null,

                  name,
                  email,
                  phone,
                  message,

                  is_military:
                    isMilitary,
                }),
            }
          );

        const data =
          await response.json();

        if (
          data?.success
        ) {

          alert(
            data?.message ||
              "Inquiry submitted successfully!"
          );

          setInquiryType("");
          setSelectedDate(
            null
          );
          setName("");
          setEmail("");
          setPhone("");
          setMessage("");
          setIsMilitary(
            false
          );

        } else {

          alert(
            data?.message ||
              "Something went wrong!"
          );

        }

      } catch (
        error
      ) {

        console.error(
          error
        );

        alert(
          "Server error. Please try again later."
        );

      } finally {

        setSubmitting(
          false
        );

      }

    };


  /*
  |--------------------------------------------------------------------------
  | STRIP HTML
  |--------------------------------------------------------------------------
  */

  const stripHtml =
    (html) => {

      const doc =
        new DOMParser().parseFromString(
          html || "",
          "text/html"
        );

      return (
        doc.body
          .textContent || ""
      );

    };


  /*
  |--------------------------------------------------------------------------
  | SOLD IMAGE
  |--------------------------------------------------------------------------
  */

  const getSoldImage =
    (item) => {

      let source =
        item?.image;

      if (
        typeof source ===
        "string"
      ) {

        try {

          source =
            JSON.parse(
              source
            );

        } catch {

          source = [];

        }

      }

      if (
        !Array.isArray(
          source
        ) ||
        !source.length
      ) {

        return FALLBACK_IMAGE;

      }

      return getImageUrl(
        source[0]
      );

    };


  /*
  |--------------------------------------------------------------------------
  | LOADING
  |--------------------------------------------------------------------------
  */

  if (
    loadingProperty
  ) {

    return (
      <div
        className="
          flex
          min-h-screen
          items-center
          justify-center
          bg-[#f6f9ff]
          px-4
        "
      >

        <div className="text-center">

          <div
            className="
              mx-auto
              h-10
              w-10
              animate-spin
              rounded-full
              border-[3px]
              border-gray-200
              border-t-sky-500
            "
          />

          <p
            className="
              mt-4
              text-sm
              text-gray-500
            "
          >
            Loading property...
          </p>

        </div>

      </div>
    );

  }


  /*
  |--------------------------------------------------------------------------
  | NOT FOUND
  |--------------------------------------------------------------------------
  */

  if (!property) {

    return (
      <div
        className="
          flex
          min-h-[70vh]
          items-center
          justify-center
          bg-[#f6f9ff]
          px-4
        "
      >

        <div
          className="
            w-full
            max-w-md
            rounded-3xl
            border
            border-gray-100
            bg-white
            p-8
            text-center
            shadow-sm
          "
        >

          <div className="text-5xl">
            🏠
          </div>

          <h2
            className="
              mt-4
              text-xl
              font-bold
              text-gray-900
            "
          >
            Property Not Found
          </h2>

          <p
            className="
              mt-2
              text-sm
              leading-6
              text-gray-500
            "
          >
            This property may no longer be available.
          </p>

          <button
            type="button"
            onClick={() =>
              navigate(
                "/properties"
              )
            }
            className="
              mt-6
              rounded-xl
              bg-sky-500
              px-5
              py-3
              text-sm
              font-semibold
              text-white
              hover:bg-sky-600
            "
          >
            Browse Properties
          </button>

        </div>

      </div>
    );

  }


  const wished =
    isWished(
      propertyId
    );


  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <>
      <main
        className="
          min-h-screen
          bg-[#f6f9ff]
          pb-24
          lg:pb-12
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1380px]
            min-w-0
            px-3
            py-4
            sm:px-5
            sm:py-6
            lg:px-8
            lg:py-8
          "
        >

          {/* ==================================================
              PROPERTY HERO / GALLERY
          =================================================== */}

          <section
            className="
              w-full
              min-w-0
              overflow-hidden
              rounded-[24px]
              border
              border-gray-100
              bg-white
              shadow-sm
              sm:rounded-[30px]
            "
          >

            <div
              className="
                grid
                min-w-0
                lg:grid-cols-[minmax(0,1fr)_360px]
              "
            >

              {/* =================================================
                  GALLERY
                  ORIGINAL LARGE-SCREEN STYLE PRESERVED
              ================================================== */}

              <div
                className="
                  min-w-0
                  p-2
                  sm:p-3
                "
              >

                {/* ===== IMAGE SECTION ===== */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-3 md:gap-4 mb-6 lg:mb-10">

                  {/* ===== MAIN IMAGE ===== */}
                  <div
                    className="
                      md:col-span-4
                      relative
                      h-[320px]
                      sm:h-[400px]
                      md:h-[460px]
                      lg:h-[520px]
                      rounded-3xl
                      overflow-hidden
                      shadow-xl
                      group
                      bg-gray-100
                    "
                  >

                    <img
                      className="
                        w-full
                        h-full
                        object-cover
                        transition-transform
                        duration-700
                        group-hover:scale-105
                        cursor-pointer
                      "
                      alt={property?.title || "Property"}
                      src={
                        images.length
                          ? `https://lightblue-moose-690494.hostingersite.com/public/${images[currentImage]?.path}`
                          : "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg"
                      }
                      onClick={() => {
                        setGalleryIndex(currentImage);
                        setShowGallery(true);
                      }}
                    />

                    {/* DARK GRADIENT */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/10 to-transparent pointer-events-none" />

                    {/* IMAGE COUNTER */}
                    {images.length > 0 && (
                      <div className="
                        absolute
                        bottom-4
                        left-4
                        bg-black/50
                        backdrop-blur-sm
                        text-white
                        text-xs
                        font-medium
                        px-3
                        py-1.5
                        rounded-full
                      ">
                        {currentImage + 1} / {images.length}
                      </div>
                    )}

                    {/* LEFT BUTTON */}
                    {images.length > 1 && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();

                          setCurrentImage(
                            currentImage === 0
                              ? images.length - 1
                              : currentImage - 1
                          );
                        }}
                        className="
                          absolute
                          left-4
                          top-1/2
                          -translate-y-1/2
                          bg-white/90
                          hover:bg-white
                          shadow-md
                          p-3
                          rounded-full
                          transition
                          z-10
                          hover:scale-105
                        "
                        aria-label="Previous image"
                      >
                        <IoIosArrowBack size={20} />
                      </button>
                    )}

                    {/* RIGHT BUTTON */}
                    {images.length > 1 && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();

                          setCurrentImage(
                            currentImage === images.length - 1
                              ? 0
                              : currentImage + 1
                          );
                        }}
                        className="
                          absolute
                          right-4
                          top-1/2
                          -translate-y-1/2
                          bg-white/90
                          hover:bg-white
                          shadow-md
                          p-3
                          rounded-full
                          transition
                          z-10
                          hover:scale-105
                        "
                        aria-label="Next image"
                      >
                        <IoIosArrowForward size={20} />
                      </button>
                    )}

                  </div>


                  {/* ===== THUMBNAILS ===== */}
                  <div
                    className="
                      md:col-span-1
                      flex
                      md:flex-col
                      gap-2
                      md:gap-3
                      overflow-x-auto
                      md:overflow-visible
                      scrollbar-hide
                      min-w-0
                    "
                  >

                    {images.slice(0, 3).map((img, i) => {

                      const remaining =
                        images.length - 2;

                      return (
                        <div
                          key={i}
                          onClick={() => {
                            if (i === 2 && remaining > 0) {
                              setGalleryIndex(2);
                              setShowGallery(true);
                              return;
                            }

                            setCurrentImage(i);
                          }}
                          className={`
                            relative
                            flex-shrink-0
                            rounded-xl
                            overflow-hidden
                            cursor-pointer
                            border-2
                            transition-all
                            duration-200

                            w-28
                            h-20

                            md:w-full
                            md:h-auto
                            md:aspect-[4/3]

                            ${
                              i === currentImage
                                ? "border-sky-500 shadow-md scale-[1.02]"
                                : "border-gray-200 hover:border-sky-400"
                            }
                          `}
                        >

                          <img
                            src={
                              img?.path
                                ? `https://lightblue-moose-690494.hostingersite.com/public/${img.path}`
                                : "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg"
                            }
                            className="
                              w-full
                              h-full
                              object-cover
                            "
                            alt=""
                          />

                          {/* EXTRA IMAGE OVERLAY */}
                          {i === 2 && remaining > 0 && (
                            <div className="
                              absolute
                              inset-0
                              bg-black/60
                              flex
                              items-center
                              justify-center
                              text-white
                              font-bold
                              text-xl
                            ">
                              +{remaining}
                            </div>
                          )}

                        </div>
                      );
                    })}

                  </div>

                </div>

              </div>


              {/* =================================================
                  PROPERTY SUMMARY
                  SAME LARGE SCREEN STRUCTURE
              ================================================== */}

              <div
                className="
                  flex
                  min-w-0
                  flex-col
                  justify-between
                  border-t
                  border-gray-100
                  p-5
                  sm:p-6
                  lg:border-l
                  lg:border-t-0
                  lg:p-7
                  xl:p-8
                "
              >

                <div>

                  {/* TYPE / STATUS */}

                  <div
                    className="
                      flex
                      min-w-0
                      items-center
                      justify-between
                      gap-2
                    "
                  >

                    <span
                      className="
                        min-w-0
                        max-w-[60%]
                        truncate
                        rounded-full
                        bg-sky-50
                        px-3
                        py-1.5
                        text-[10px]
                        font-semibold
                        text-sky-600
                        sm:text-xs
                      "
                    >
                      {propertyType}
                    </span>

                    <span
                      className={`
                        shrink-0
                        rounded-full
                        border
                        px-3
                        py-1.5
                        text-[10px]
                        font-semibold
                        capitalize
                        sm:text-xs
                        ${statusClass}
                      `}
                    >
                      {propertyStatus}
                    </span>

                  </div>


                  {/* TITLE */}

                  <h1
                    className="
                      mt-5
                      break-words
                      text-2xl
                      font-extrabold
                      leading-tight
                      tracking-tight
                      text-gray-900
                      sm:text-3xl
                      lg:text-[34px]
                    "
                  >
                    {property.title}
                  </h1>


                  {/* LOCATION */}

                  <p
                    className="
                      mt-3
                      flex
                      items-start
                      gap-2
                      text-xs
                      leading-5
                      text-gray-500
                      sm:text-sm
                    "
                  >

                    <FaMapMarkerAlt
                      className="
                        mt-0.5
                        shrink-0
                        text-sky-500
                      "
                    />

                    <span className="break-words">
                      {property.location ||
                        property.city ||
                        "Location not available"}
                    </span>

                  </p>


                  {/* PRICE */}

                  <div
                    className="
                      mt-7
                      rounded-2xl
                      bg-gradient-to-r
                      from-sky-500
                      to-indigo-500
                      p-5
                      text-white
                    "
                  >

                    <p className="text-xs text-sky-100">
                      {isLease
                        ? "Monthly Rent"
                        : "Property Price"}
                    </p>

                    <p
                      className="
                        mt-1
                        break-words
                        text-2xl
                        font-extrabold
                        sm:text-3xl
                      "
                    >
                      {formattedPrice}
                    </p>

                    {isLease && (
                      <p className="mt-1 text-[10px] text-sky-100 sm:text-xs">
                        Per month
                      </p>
                    )}

                  </div>

                </div>


                {/* QUICK FACTS */}
                <div className="mt-6">

                  <div className="mb-3 flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-gray-900">
                      Quick Facts
                    </h3>

                    <span className="text-[10px] text-gray-400">
                      Property details
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">

                    <div className="rounded-2xl border border-gray-100 bg-gray-50 p-3.5">
                      <div className="flex items-center gap-2">
                        <FaCalendarAlt className="text-sky-500 text-sm" />

                        <span className="text-[10px] font-medium uppercase tracking-wide text-gray-400">
                          Year Built
                        </span>
                      </div>

                      <p className="mt-2 text-sm font-bold text-gray-900 break-words">
                        {property?.year_built || "-"}
                      </p>
                    </div>


                    <div className="rounded-2xl border border-gray-100 bg-gray-50 p-3.5">
                      <div className="flex items-center gap-2">
                        <FaRulerCombined className="text-sky-500 text-sm" />

                        <span className="text-[10px] font-medium uppercase tracking-wide text-gray-400">
                          Total Space
                        </span>
                      </div>

                      <p className="mt-2 text-sm font-bold text-gray-900 break-words">
                        {property?.total_space_available
                          ? `${property.total_space_available} ${
                              property?.total_size_unit || ""
                            }`
                          : "-"}
                      </p>
                    </div>


                    <div className="rounded-2xl border border-gray-100 bg-gray-50 p-3.5">
                      <div className="flex items-center gap-2">
                        <FaRulerCombined className="text-sky-500 text-sm" />

                        <span className="text-[10px] font-medium uppercase tracking-wide text-gray-400">
                          Building Size
                        </span>
                      </div>

                      <p className="mt-2 text-sm font-bold text-gray-900 break-words">
                        {property?.building_size
                          ? `${property.building_size} ${
                              property?.building_size_unit || ""
                            }`
                          : "-"}
                      </p>
                    </div>

                    <div className="rounded-2xl border border-gray-100 bg-gray-50 p-3.5">
                      <div className="flex items-center gap-2">
                        <FaParking className="text-sky-500 text-sm" />

                        <span className="text-[10px] font-medium uppercase tracking-wide text-gray-400">
                          Parking
                        </span>
                      </div>

                      <p className="mt-2 text-sm font-bold text-gray-900 break-words">
                        {property?.parking_ratio
                          ? `${property.parking_ratio} Sqft`
                          : "-"}
                      </p>
                    </div>

                  </div>

                </div>


                {/* DESKTOP CTA */}

                <button
                  type="button"
                  onClick={() =>
                    document
                      .getElementById(
                        "contact-inquiry"
                      )
                      ?.scrollIntoView({
                        behavior:
                          "smooth",
                      })
                  }
                  className="
                    mt-6
                    hidden
                    min-h-[50px]
                    w-full
                    items-center
                    justify-center
                    rounded-xl
                    bg-sky-500
                    px-5
                    py-3
                    text-sm
                    font-semibold
                    text-white
                    shadow-md
                    transition
                    hover:bg-sky-600
                    active:scale-[0.98]
                    lg:flex
                  "
                >

                  Contact Agent

                  <span className="ml-2">
                    →
                  </span>

                </button>

              </div>

            </div>

          </section>


          {/* ==================================================
              CONTENT
          =================================================== */}

          <div
            className="
              mt-6
              grid
              min-w-0
              grid-cols-1
              gap-6
              lg:grid-cols-[minmax(0,1fr)_360px]
            "
          >

            {/* =================================================
                LEFT CONTENT
            ================================================== */}

            <div
              className="
                min-w-0
                space-y-6
              "
            >

              {/* HIGHLIGHTS */}

              {property.highlights && (
                <ContentSection
                  eyebrow="Highlights"
                  title="Why this property stands out"
                >

                  <div
                    className="
                      break-words
                      text-sm
                      leading-7
                      text-gray-600
                      [&_li]:mb-2
                      [&_p]:mb-4
                      [&_ul]:list-disc
                      [&_ul]:pl-5
                      [&_li]:marker:text-sky-500
                    "
                    dangerouslySetInnerHTML={{
                      __html:
                        property.highlights,
                    }}
                  />

                </ContentSection>
              )}


              {/* SUMMARY */}

              {property.description && (
                <ContentSection
                  eyebrow="Overview"
                  title="Property Summary"
                >

                  <div
                    className="
                      break-words
                      text-sm
                      leading-7
                      text-gray-600
                      [&_li]:mb-2
                      [&_p]:mb-4
                      [&_ul]:list-disc
                      [&_ul]:pl-5
                    "
                    dangerouslySetInnerHTML={{
                      __html:
                        property.description,
                    }}
                  />

                </ContentSection>
              )}


              {/* PROPERTY FACTS */}

              <section
                className="
                  min-w-0
                  rounded-[24px]
                  border
                  border-gray-100
                  bg-white
                  p-5
                  shadow-sm
                  sm:p-7
                "
              >

                <p
                  className="
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.16em]
                    text-sky-500
                    sm:text-xs
                  "
                >
                  Specifications
                </p>


                <h2
                  className="
                    mt-1
                    text-xl
                    font-bold
                    text-gray-900
                    sm:text-2xl
                  "
                >
                  Property Facts
                </h2>


                <div
                  className="
                    mt-6
                    grid
                    grid-cols-1
                    gap-3
                    sm:grid-cols-2
                  "
                >

                  <FactCard
                    icon={
                      <FaBuilding />
                    }
                    label="Property Type"
                    value={
                      propertyType
                    }
                  />

                  <FactCard
                    icon={
                      <FaRulerCombined />
                    }
                    label="Total Space"
                    value={
                      property.total_space_available
                        ? `${property.total_space_available} ${property.total_size_unit || ""}`
                        : "-"
                    }
                  />

                  <FactCard
                    icon={
                      <FaRulerCombined />
                    }
                    label="Land Size"
                    value={
                      property.land_size
                        ? `${property.land_size} ${property.land_size_unit || ""}`
                        : "-"
                    }
                  />

                  <FactCard
                    icon={
                      <FaRulerCombined />
                    }
                    label="Building Size"
                    value={
                      property.building_size
                        ? `${property.building_size} ${property.building_size_unit || ""}`
                        : "-"
                    }
                  />

                  <FactCard
                    icon={
                      <FaCalendarAlt />
                    }
                    label="Year Built"
                    value={
                      property.year_built ||
                      "-"
                    }
                  />

                  <FactCard
                    icon={
                      <FaParking />
                    }
                    label="Parking"
                    value={
                      property.parking_ratio
                        ? `${property.parking_ratio} Sqft`
                        : "-"
                    }
                  />

                </div>


                {/* FEATURES */}

                <div
                  className="
                    mt-6
                    border-t
                    border-gray-100
                    pt-6
                  "
                >

                  <div
                    className="
                      flex
                      items-center
                      gap-2
                    "
                  >

                    <FaBolt
                      className="text-sky-500"
                    />

                    <h3
                      className="
                        text-sm
                        font-bold
                        text-gray-900
                      "
                    >
                      Building Features
                    </h3>

                  </div>


                  <div
                    className="
                      mt-3
                      flex
                      flex-wrap
                      gap-2
                    "
                  >

                    {property.building_features
                      ? property.building_features
                          .split(",")
                          .map(
                            (
                              feature,
                              index
                            ) => (
                              <span
                                key={
                                  index
                                }
                                className="
                                  inline-flex
                                  max-w-full
                                  items-center
                                  gap-1.5
                                  rounded-full
                                  border
                                  border-sky-100
                                  bg-sky-50
                                  px-3
                                  py-1.5
                                  text-[10px]
                                  font-semibold
                                  text-sky-600
                                  sm:text-xs
                                "
                              >

                                <FaCheck
                                  className="
                                    shrink-0
                                    text-[8px]
                                  "
                                />

                                <span className="break-words">
                                  {feature.trim()}
                                </span>

                              </span>
                            )
                          )
                      : (
                        <span
                          className="
                            text-xs
                            text-gray-400
                          "
                        >
                          No features listed
                        </span>
                      )}

                  </div>

                </div>

              </section>

              
              {/* Nearby */}
              {Array.isArray(property.nearby) &&
                property.nearby.length > 0 && (

                  <section
                    className="
                      min-w-0
                      rounded-[24px]
                      border
                      border-gray-100
                      bg-white
                      p-5
                      shadow-sm
                      sm:p-7
                    "
                  >

                    <p
                      className="
                        text-[10px]
                        font-bold
                        uppercase
                        tracking-[0.16em]
                        text-sky-500
                        sm:text-xs
                      "
                    >
                      Nearby
                    </p>

                    <h2
                      className="
                        mt-1
                        text-xl
                        font-bold
                        text-gray-900
                        sm:text-2xl
                      "
                    >
                      Places Around Property
                    </h2>

                    <div
                      className="
                        mt-5
                        grid
                        grid-cols-1
                        gap-3
                        sm:grid-cols-2
                      "
                    >

                      {property.nearby.map(
                        (place, index) => (

                          <div
                            key={index}
                            className="
                              flex
                              min-w-0
                              items-center
                              justify-between
                              gap-3
                              rounded-2xl
                              border
                              border-gray-100
                              bg-gray-50
                              px-4
                              py-4
                              transition
                              hover:bg-sky-50
                            "
                          >

                            <div
                              className="
                                flex
                                min-w-0
                                items-center
                                gap-3
                              "
                            >

                              <div
                                className="
                                  flex
                                  h-9
                                  w-9
                                  shrink-0
                                  items-center
                                  justify-center
                                  rounded-xl
                                  bg-sky-100
                                  text-sky-500
                                "
                              >
                                <FaMapMarkerAlt size={12} />
                              </div>

                              <span
                                className="
                                  min-w-0
                                  truncate
                                  text-sm
                                  font-semibold
                                  text-gray-800
                                "
                              >
                                {place.name}
                              </span>

                            </div>

                            <span
                              className="
                                shrink-0
                                text-xs
                                font-bold
                                text-sky-600
                              "
                            >
                              {place.distance} km
                            </span>

                          </div>

                        )
                      )}

                    </div>

                  </section>
              )}
              
              {/* LOCATION MAP */}
              <section
                className="
                  min-w-0
                  overflow-hidden
                  rounded-[24px]
                  border
                  border-gray-100
                  bg-white
                  shadow-sm
                "
              >

                <div
                  className="
                    p-5
                    sm:p-7
                  "
                >

                  <p
                    className="
                      text-[10px]
                      font-bold
                      uppercase
                      tracking-[0.16em]
                      text-sky-500
                      sm:text-xs
                    "
                  >
                    Location
                  </p>

                  <h2
                    className="
                      mt-1
                      text-xl
                      font-bold
                      text-gray-900
                      sm:text-2xl
                    "
                  >
                    Property Location
                  </h2>

                  <p
                    className="
                      mt-2
                      break-words
                      text-xs
                      leading-5
                      text-gray-500
                      sm:text-sm
                    "
                  >
                    {property.location ||
                      property.city ||
                      "Location not available"}
                  </p>

                </div>

                <div
                  className="
                    relative
                    h-[260px]
                    w-full
                    overflow-hidden
                    bg-gray-100
                    sm:h-[340px]
                  "
                >

                  <iframe
                    title="Property location"
                    src={`https://maps.google.com/maps?q=${property.latitude},${property.longitude}&z=15&output=embed`}
                    width="100%"
                    height="100%"
                    loading="lazy"
                    className="
                      block
                      h-full
                      w-full
                      border-0
                    "
                  />

                </div>

              </section>


              {/* PROPERTY OVERVIEW */}

              {property.property_overview && (
                <ContentSection
                  eyebrow="Details"
                  title="Property Overview"
                >

                  <div
                    className="
                      break-words
                      text-sm
                      leading-7
                      text-gray-600
                      [&_li]:mb-2
                      [&_p]:mb-4
                      [&_ul]:list-disc
                      [&_ul]:pl-5
                    "
                    dangerouslySetInnerHTML={{
                      __html:
                        property.property_overview,
                    }}
                  />

                </ContentSection>
              )}


              {/* OWNER */}

              {property.about_owner && (
                <ContentSection
                  eyebrow="Background"
                  title="About the Owner"
                >

                  <div
                    className="
                      break-words
                      text-sm
                      leading-7
                      text-gray-600
                      [&_li]:mb-2
                      [&_p]:mb-4
                      [&_ul]:list-disc
                      [&_ul]:pl-5
                    "
                    dangerouslySetInnerHTML={{
                      __html:
                        property.about_owner,
                    }}
                  />

                </ContentSection>
              )}

            </div>


            {/* =================================================
                SIDEBAR
            ================================================== */}

            <aside
              className="
                min-w-0
                space-y-6
                lg:sticky
                lg:top-24
                lg:self-start
              "
            >

              {/* INQUIRY */}

              <section
                id="contact-inquiry"
                className="
                  min-w-0
                  rounded-[24px]
                  border
                  border-gray-100
                  bg-white
                  p-5
                  shadow-sm
                  sm:p-6
                "
              >

                <p
                  className="
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.16em]
                    text-sky-500
                    sm:text-xs
                  "
                >
                  Get in Touch
                </p>


                <h2
                  className="
                    mt-1
                    text-xl
                    font-bold
                    text-gray-900
                    sm:text-2xl
                  "
                >
                  Contact & Inquiry
                </h2>


                <p
                  className="
                    mt-2
                    text-xs
                    leading-5
                    text-gray-500
                  "
                >
                  Tell us what you're looking for and we'll get back to you shortly.
                </p>


                {/* TYPE */}

                <div className="mt-5">

                  <label
                    className="
                      mb-2
                      block
                      text-xs
                      font-semibold
                      text-gray-700
                    "
                  >
                    What can we help you with?
                  </label>


                  <select
                    value={
                      inquiryType
                    }
                    onChange={(
                      event
                    ) =>
                      setInquiryType(
                        event
                          .target
                          .value
                      )
                    }
                    className="
                      h-12
                      w-full
                      min-w-0
                      rounded-xl
                      border
                      border-gray-200
                      bg-gray-50
                      px-4
                      text-sm
                      text-gray-700
                      outline-none
                      focus:border-sky-400
                      focus:bg-white
                      focus:ring-2
                      focus:ring-sky-100
                    "
                  >

                    <option value="">
                      Select purpose
                    </option>

                    <option value="financials">
                      Financial Information
                    </option>

                    <option value="pricing">
                      Pricing Details
                    </option>

                    <option value="request_tour">
                      Schedule a Property Tour
                    </option>

                    <option value="others">
                      General Inquiry
                    </option>

                  </select>

                </div>


                {/* DATES */}

                {inquiryType ===
                  "request_tour" && (

                  <div
                    className="
                      mt-5
                      min-w-0
                    "
                  >

                    <label
                      className="
                        mb-2
                        block
                        text-xs
                        font-semibold
                        text-gray-700
                      "
                    >
                      Preferred visit date
                    </label>


                    <div
                      className="
                        flex
                        min-w-0
                        gap-2
                        overflow-x-auto
                        pb-1
                        scrollbar-hide
                      "
                    >

                      {nextDates.map(
                        (
                          dateItem
                        ) => (

                          <button
                            type="button"
                            key={
                              dateItem.fullDate
                            }
                            onClick={() =>
                              setSelectedDate(
                                dateItem.fullDate
                              )
                            }
                            className={`
                              min-w-[80px]
                              rounded-xl
                              border
                              px-3
                              py-3
                              text-center
                              transition

                              ${
                                selectedDate ===
                                dateItem.fullDate
                                  ? "border-sky-500 bg-sky-50 text-sky-600"
                                  : "border-gray-200 bg-white text-gray-600"
                              }
                            `}
                          >

                            <p
                              className="
                                text-[10px]
                              "
                            >
                              {
                                dateItem.day
                              }
                            </p>

                            <p
                              className="
                                mt-1
                                text-xs
                                font-bold
                              "
                            >
                              {
                                dateItem.date
                              }
                            </p>

                          </button>

                        )
                      )}

                    </div>

                  </div>

                )}


                {/* FORM */}

                <div
                  className="
                    mt-5
                    min-w-0
                    space-y-3
                  "
                >

                  <input
                    type="text"
                    value={name}
                    onChange={(
                      event
                    ) =>
                      setName(
                        event
                          .target
                          .value
                      )
                    }
                    placeholder="Your full name"
                    className="
                      h-12
                      w-full
                      min-w-0
                      rounded-xl
                      border
                      border-gray-200
                      px-4
                      text-sm
                      outline-none
                      focus:border-sky-400
                      focus:ring-2
                      focus:ring-sky-100
                    "
                  />

                  <input
                    type="email"
                    value={email}
                    onChange={(
                      event
                    ) =>
                      setEmail(
                        event
                          .target
                          .value
                      )
                    }
                    placeholder="Email address"
                    className="
                      h-12
                      w-full
                      min-w-0
                      rounded-xl
                      border
                      border-gray-200
                      px-4
                      text-sm
                      outline-none
                      focus:border-sky-400
                      focus:ring-2
                      focus:ring-sky-100
                    "
                  />

                  <input
                    type="tel"
                    value={phone}
                    onChange={(
                      event
                    ) =>
                      setPhone(
                        event
                          .target
                          .value
                      )
                    }
                    placeholder="Phone number"
                    className="
                      h-12
                      w-full
                      min-w-0
                      rounded-xl
                      border
                      border-gray-200
                      px-4
                      text-sm
                      outline-none
                      focus:border-sky-400
                      focus:ring-2
                      focus:ring-sky-100
                    "
                  />

                  <textarea
                    rows={
                      4
                    }
                    value={
                      message
                    }
                    onChange={(
                      event
                    ) =>
                      setMessage(
                        event
                          .target
                          .value
                      )
                    }
                    placeholder="Tell us more about your requirement..."
                    className="
                      min-h-[110px]
                      w-full
                      min-w-0
                      resize-none
                      rounded-xl
                      border
                      border-gray-200
                      px-4
                      py-3
                      text-sm
                      outline-none
                      focus:border-sky-400
                      focus:ring-2
                      focus:ring-sky-100
                    "
                  />

                </div>


                {/* MILITARY */}

                <label
                  className="
                    mt-4
                    flex
                    cursor-pointer
                    items-start
                    gap-2
                    text-xs
                    leading-5
                    text-gray-500
                  "
                >

                  <input
                    type="checkbox"
                    checked={
                      isMilitary
                    }
                    onChange={(
                      event
                    ) =>
                      setIsMilitary(
                        event
                          .target
                          .checked
                      )
                    }
                    className="
                      mt-0.5
                      h-4
                      w-4
                      shrink-0
                      accent-sky-500
                    "
                  />

                  <span>
                    Military member / veteran
                  </span>

                </label>


                {/* SUBMIT */}

                <button
                  type="button"
                  onClick={
                    submitInquiry
                  }
                  disabled={
                    submitting
                  }
                  className="
                    mt-5
                    flex
                    min-h-[50px]
                    w-full
                    items-center
                    justify-center
                    rounded-xl
                    bg-sky-500
                    px-5
                    py-3
                    text-sm
                    font-semibold
                    text-white
                    shadow-md
                    transition
                    hover:bg-sky-600
                    active:scale-[0.98]
                    disabled:cursor-not-allowed
                    disabled:opacity-50
                  "
                >

                  {submitting
                    ? "Sending..."
                    : "Submit Inquiry"}

                </button>


                <p
                  className="
                    mt-3
                    text-center
                    text-[10px]
                    text-gray-400
                  "
                >
                  We usually respond within a few hours.
                </p>

              </section>


              {/* AGENT */}

              <section
                className="
                  min-w-0
                  rounded-[24px]
                  border
                  border-gray-100
                  bg-white
                  p-5
                  text-center
                  shadow-sm
                  sm:p-6
                "
              >

                <p
                  className="
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.16em]
                    text-sky-500
                  "
                >
                  Your Contact
                </p>


                <h3
                  className="
                    mt-1
                    text-xl
                    font-bold
                    text-gray-900
                  "
                >
                  Property Agent
                </h3>


                <Link
                  to={`/agent/${
                    property.agent
                      ?.id ||
                    property.agent
                      ?._id ||
                    ""
                  }`}
                  className="
                    mt-5
                    block
                  "
                >

                  <img
                    src={
                      property.agent
                        ?.img
                        ? `${API_BASE}/public${property.agent.img}`
                        : FALLBACK_AGENT_IMAGE
                    }
                    alt={
                      property.agent
                        ?.name ||
                      "Agent"
                    }
                    className="
                      mx-auto
                      h-20
                      w-20
                      rounded-full
                      border-4
                      border-sky-100
                      object-cover
                    "
                  />


                  <h4
                    className="
                      mt-3
                      break-words
                      text-lg
                      font-bold
                      text-gray-900
                    "
                  >
                    {property.agent
                      ?.name ||
                      "Property Agent"}
                  </h4>

                </Link>


                <p
                  className="
                    mt-2
                    break-all
                    text-xs
                    text-gray-500
                  "
                >
                  {property.agent
                    ?.phone ||
                    "Phone unavailable"}
                </p>


                <div
                  className="
                    mt-5
                    grid
                    grid-cols-2
                    gap-2
                  "
                >

                  <a
                    href={
                      property.agent
                        ?.phone
                        ? `https://wa.me/${property.agent.phone}`
                        : "#"
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className="
                      flex
                      min-h-[46px]
                      items-center
                      justify-center
                      gap-2
                      rounded-xl
                      bg-green-500
                      px-2
                      text-xs
                      font-semibold
                      text-white
                      hover:bg-green-600
                    "
                  >
                    <FaWhatsapp />
                    WhatsApp
                  </a>


                  <a
                    href={
                      property.agent
                        ?.phone
                        ? `tel:${property.agent.phone}`
                        : "#"
                    }
                    className="
                      flex
                      min-h-[46px]
                      items-center
                      justify-center
                      gap-2
                      rounded-xl
                      border
                      border-sky-500
                      px-2
                      text-xs
                      font-semibold
                      text-sky-500
                      hover:bg-sky-50
                    "
                  >
                    <FaPhoneAlt />
                    Call
                  </a>

                </div>

              </section>

            </aside>

          </div>

        </div>

      </main>


      {/* ==========================================================
          SOLD PROPERTIES
      =========================================================== */}

      {soldProperties.length >
        0 && (

        <section
          className="
            w-full
            bg-white
            px-3
            py-10
            sm:px-5
            sm:py-12
            lg:px-8
            lg:py-14
          "
        >

          <div
            className="
              mx-auto
              w-full
              max-w-[1380px]
            "
          >

            <div
              className="
                mb-7
                flex
                flex-col
                gap-3
                sm:flex-row
                sm:items-end
                sm:justify-between
              "
            >

              <div>

                <p
                  className="
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.16em]
                    text-sky-500
                    sm:text-xs
                  "
                >
                  Recently Closed
                </p>

                <h2
                  className="
                    mt-1
                    text-2xl
                    font-bold
                    text-gray-900
                    sm:text-3xl
                  "
                >
                  Sold Properties
                </h2>

              </div>


              <span
                className="
                  w-fit
                  rounded-full
                  border
                  border-red-100
                  bg-red-50
                  px-3
                  py-1.5
                  text-xs
                  font-semibold
                  text-red-600
                "
              >
                {soldProperties.length} Sold
              </span>

            </div>


            <div
              className="
                grid
                grid-cols-1
                gap-4
                sm:grid-cols-2
                sm:gap-6
                lg:grid-cols-3
                xl:grid-cols-4
              "
            >

              {paginatedSold.map(
                (
                  item,
                  index
                ) => {

                  const soldId =
                    item?._id ||
                    item?.id ||
                    index;

                  const description =
                    stripHtml(
                      item?.description ||
                        ""
                    );

                  return (
                    <article
                      key={
                        soldId
                      }
                      className="
                        min-w-0
                        overflow-hidden
                        rounded-2xl
                        border
                        border-gray-100
                        bg-white
                        shadow-sm
                        transition
                        hover:-translate-y-1
                        hover:shadow-xl
                      "
                    >

                      <div
                        className="
                          relative
                          aspect-[16/10]
                          overflow-hidden
                          bg-gray-100
                        "
                      >

                        <img
                          src={
                            getSoldImage(
                              item
                            )
                          }
                          alt={
                            item?.title ||
                            "Sold property"
                          }
                          className="
                            block
                            h-full
                            w-full
                            object-cover
                            transition
                            duration-500
                            hover:scale-105
                          "
                          loading="lazy"
                        />

                        <span
                          className="
                            absolute
                            left-3
                            top-3
                            rounded-full
                            bg-red-500
                            px-3
                            py-1.5
                            text-[10px]
                            font-bold
                            text-white
                          "
                        >
                          SOLD
                        </span>

                      </div>


                      <div
                        className="
                          min-w-0
                          p-4
                          sm:p-5
                        "
                      >

                        <h3
                          className="
                            line-clamp-2
                            break-words
                            text-sm
                            font-bold
                            text-gray-900
                          "
                        >
                          {item?.title ||
                            "Sold Property"}
                        </h3>


                        <p
                          className="
                            mt-2
                            truncate
                            text-xs
                            text-gray-500
                          "
                        >
                          📍{" "}
                          {item?.location ||
                            "Location unavailable"}
                        </p>


                        <p
                          className="
                            mt-3
                            text-xs
                            leading-5
                            text-gray-500
                          "
                        >
                          {description.slice(
                            0,
                            90
                          )}

                          {description.length >
                            90 &&
                            "..."}
                        </p>


                        <div
                          className="
                            mt-4
                            flex
                            min-w-0
                            items-center
                            justify-between
                            gap-3
                            border-t
                            border-gray-100
                            pt-4
                          "
                        >

                          <p
                            className="
                              min-w-0
                              truncate
                              text-sm
                              font-bold
                              text-sky-600
                            "
                          >
                            {item?.sale_price ||
                            item?.monthly_rent
                              ? `₹ ${Number(
                                  item?.sale_price ||
                                    item?.monthly_rent
                                ).toLocaleString(
                                  "en-IN"
                                )}`
                              : "On Request"}
                          </p>


                          <button
                            type="button"
                            onClick={() =>
                              navigate(
                                `/property/${soldId}`
                              )
                            }
                            className="
                              shrink-0
                              rounded-xl
                              bg-sky-500
                              px-4
                              py-2.5
                              text-xs
                              font-semibold
                              text-white
                              transition
                              hover:bg-sky-600
                            "
                          >
                            View
                          </button>

                        </div>

                      </div>

                    </article>
                  );

                }
              )}

            </div>


            {/* SOLD PAGINATION */}

            {soldTotalPages >
              1 && (

              <div
                className="
                  mt-8
                  flex
                  flex-wrap
                  justify-center
                  gap-2
                "
              >

                {Array.from(
                  {
                    length:
                      soldTotalPages,
                  },
                  (
                    _,
                    index
                  ) => (

                    <button
                      type="button"
                      key={
                        index
                      }
                      onClick={() =>
                        setSoldPage(
                          index + 1
                        )
                      }
                      className={`
                        flex
                        h-10
                        min-w-10
                        items-center
                        justify-center
                        rounded-xl
                        px-3
                        text-xs
                        font-semibold
                        transition

                        ${
                          soldPage ===
                          index + 1
                            ? "bg-sky-500 text-white"
                            : "border border-gray-200 bg-white text-gray-600 hover:bg-sky-50"
                        }
                      `}
                    >
                      {index + 1}
                    </button>

                  )
                )}

              </div>

            )}

          </div>

        </section>

      )}


      {/* ==========================================================
          MOBILE ACTION BAR
      =========================================================== */}

      <div
        className="
          fixed
          bottom-0
          left-0
          right-0
          z-[70]
          border-t
          border-gray-200
          bg-white/95
          p-3
          shadow-[0_-8px_30px_rgba(0,0,0,0.08)]
          backdrop-blur-xl
          lg:hidden
        "
      >

        <div
          className="
            mx-auto
            flex
            w-full
            max-w-lg
            gap-2
          "
        >

          <button
            type="button"
            onClick={
              handleWishlist
            }
            className="
              flex
              h-12
              w-12
              shrink-0
              items-center
              justify-center
              rounded-xl
              border
              border-gray-200
              bg-white
            "
            aria-label="Wishlist"
          >

            {wished ? (
              <FaHeart className="text-red-500" />
            ) : (
              <FaRegHeart className="text-gray-500" />
            )}

          </button>


          <button
            type="button"
            onClick={() =>
              document
                .getElementById(
                  "contact-inquiry"
                )
                ?.scrollIntoView({
                  behavior:
                    "smooth",
                })
            }
            className="
              flex
              h-12
              min-w-0
              flex-1
              items-center
              justify-center
              rounded-xl
              bg-sky-500
              px-4
              text-sm
              font-semibold
              text-white
              shadow-sm
              hover:bg-sky-600
            "
          >
            Contact Agent
          </button>

        </div>

      </div>


      {/* ==========================================================
          FULLSCREEN GALLERY
      =========================================================== */}

      {showGallery &&
        images.length >
          0 && (

        <div
          className="
            fixed
            inset-0
            z-[99999]
            flex
            min-h-0
            flex-col
            bg-black/95
          "
        >

          {/* TOP BAR */}

          <div
            className="
              flex
              shrink-0
              items-center
              justify-between
              px-4
              py-4
            "
          >

            <span
              className="
                rounded-full
                bg-white/10
                px-3
                py-1.5
                text-xs
                font-semibold
                text-white
                backdrop-blur
              "
            >
              {galleryIndex +
                1}{" "}
              /{" "}
              {images.length}
            </span>


            <button
              type="button"
              onClick={() =>
                setShowGallery(
                  false
                )
              }
              className="
                flex
                h-10
                w-10
                items-center
                justify-center
                rounded-full
                bg-white/10
                text-2xl
                text-white
              "
              aria-label="Close gallery"
            >
              ×
            </button>

          </div>


          {/* VIEWER */}

          <div
            className="
              relative
              flex
              min-h-0
              flex-1
              items-center
              justify-center
              overflow-hidden
              px-3
            "
          >

            {/* PREVIOUS */}

            <button
              type="button"
              onClick={
                prevGallery
              }
              className="
                absolute
                left-2
                top-1/2
                z-20
                flex
                h-10
                w-10
                -translate-y-1/2
                items-center
                justify-center
                rounded-full
                bg-white/90
                text-gray-800
                shadow
                sm:left-5
              "
            >
              <IoIosArrowBack />
            </button>


            {/* IMAGE */}

            <div
              className="
                flex
                h-full
                min-h-0
                w-full
                items-center
                justify-center
                overflow-hidden
              "
            >

              <img
                src={getImageUrl(
                  images[
                    galleryIndex
                  ]
                )}
                alt=""
                draggable={
                  false
                }
                onWheel={
                  handleWheel
                }
                onDoubleClick={
                  handleDoubleClick
                }
                onMouseDown={
                  handleMouseDown
                }
                onMouseMove={
                  handleMouseMove
                }
                onMouseUp={
                  handleMouseUp
                }
                onMouseLeave={
                  handleMouseUp
                }
                className="
                  block
                  max-h-[78vh]
                  max-w-[92vw]
                  select-none
                  object-contain
                  sm:max-h-[84vh]
                "
                style={{
                  transform:
                    `translate(${position.x}px, ${position.y}px) scale(${zoom})`,

                  cursor:
                    zoom > 1
                      ? dragging
                        ? "grabbing"
                        : "grab"
                      : "zoom-in",
                }}
              />

            </div>


            {/* NEXT */}

            <button
              type="button"
              onClick={
                nextGallery
              }
              className="
                absolute
                right-2
                top-1/2
                z-20
                flex
                h-10
                w-10
                -translate-y-1/2
                items-center
                justify-center
                rounded-full
                bg-white/90
                text-gray-800
                shadow
                sm:right-5
              "
            >
              <IoIosArrowForward />
            </button>


            {/* ZOOM */}

            <div
              className="
                absolute
                right-3
                top-3
                z-20
                flex
                flex-col
                gap-2
                sm:right-5
                sm:top-5
              "
            >

              <button
                type="button"
                onClick={() =>
                  setZoom(
                    (value) =>
                      Math.min(
                        value +
                          0.2,
                        3
                      )
                  )
                }
                className="
                  flex
                  h-9
                  w-9
                  items-center
                  justify-center
                  rounded-lg
                  bg-white
                  text-lg
                  font-bold
                  text-gray-800
                  shadow
                "
              >
                +
              </button>

              <button
                type="button"
                onClick={() =>
                  setZoom(
                    (value) =>
                      Math.max(
                        value -
                          0.2,
                        1
                      )
                  )
                }
                className="
                  flex
                  h-9
                  w-9
                  items-center
                  justify-center
                  rounded-lg
                  bg-white
                  text-lg
                  font-bold
                  text-gray-800
                  shadow
                "
              >
                −
              </button>

              <button
                type="button"
                onClick={
                  resetZoom
                }
                className="
                  rounded-lg
                  bg-white
                  px-2
                  py-2
                  text-[10px]
                  font-semibold
                  text-gray-800
                  shadow
                "
              >
                Reset
              </button>

            </div>

          </div>

        </div>
      )}
  
    </>
  );
};


/*
|--------------------------------------------------------------------------
| MINI FACT
|--------------------------------------------------------------------------
*/

const MiniFact = ({
  label,
  value,
}) => {

  return (
    <div
      className="
        min-w-0
        rounded-xl
        border
        border-white/20
        bg-white/10
        px-3
        py-3
      "
    >

      <p
        className="
          truncate
          text-[9px]
          font-medium
          uppercase
          tracking-wide
          text-sky-100
        "
      >
        {label}
      </p>

      <p
        className="
          mt-1
          break-words
          text-xs
          font-bold
          text-white
        "
      >
        {value}
      </p>

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| CONTENT SECTION
|--------------------------------------------------------------------------
*/

const ContentSection = ({
  eyebrow,
  title,
  children,
}) => {

  return (
    <section
      className="
        min-w-0
        rounded-[24px]
        border
        border-gray-100
        bg-white
        p-5
        shadow-sm
        sm:p-7
      "
    >

      <p
        className="
          text-[10px]
          font-bold
          uppercase
          tracking-[0.16em]
          text-sky-500
          sm:text-xs
        "
      >
        {eyebrow}
      </p>

      <h2
        className="
          mt-1
          break-words
          text-xl
          font-bold
          text-gray-900
          sm:text-2xl
        "
      >
        {title}
      </h2>

      <div className="mt-5 min-w-0">
        {children}
      </div>

    </section>
  );
};


/*
|--------------------------------------------------------------------------
| FACT CARD
|--------------------------------------------------------------------------
*/

const FactCard = ({
  icon,
  label,
  value,
}) => {

  return (
    <div
      className="
        flex
        min-w-0
        items-center
        gap-3
        rounded-2xl
        border
        border-gray-100
        bg-gray-50
        p-4
      "
    >

      <div
        className="
          flex
          h-10
          w-10
          shrink-0
          items-center
          justify-center
          rounded-xl
          bg-sky-100
          text-sky-500
        "
      >
        {icon}
      </div>


      <div
        className="
          min-w-0
        "
      >

        <p
          className="
            truncate
            text-[10px]
            uppercase
            tracking-wide
            text-gray-400
          "
        >
          {label}
        </p>

        <p
          className="
            mt-0.5
            break-words
            text-sm
            font-bold
            text-gray-800
          "
        >
          {value}
        </p>

      </div>

    </div>
  );
};


export default PropertyDetails;
