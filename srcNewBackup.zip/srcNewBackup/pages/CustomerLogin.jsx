import React, {
  useEffect,
  useRef,
  useState,
} from "react";

import {
  useNavigate,
} from "react-router-dom";

import {
  FaArrowRight,
  FaBolt,
  FaEnvelope,
  FaKey,
  FaLock,
  FaTimes,
  FaUserCheck,
} from "react-icons/fa";

import {
  sendOtp,
  verifyOtp,
  loginWithPassword,
} from "../api/customerAuth";


const CustomerLogin = ({
  open,
  setOpen,
  setCustomer,
}) => {

  const navigate =
    useNavigate();

  const otpRefs =
    useRef([]);


  /*
  |--------------------------------------------------------------------------
  | STATE
  |--------------------------------------------------------------------------
  */

  const [
    tab,
    setTab,
  ] = useState("otp");

  const [
    step,
    setStep,
  ] = useState(1);

  const [
    userState,
    setUserState,
  ] = useState({
    exists: false,
    hasPassword: false,
    checked: false,
  });

  const [
    email,
    setEmail,
  ] = useState("");

  const [
    otp,
    setOtp,
  ] = useState([
    "",
    "",
    "",
    "",
    "",
    "",
  ]);

  const [
    password,
    setPassword,
  ] = useState("");

  const [
    loading,
    setLoading,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState("");


  /*
  |--------------------------------------------------------------------------
  | RESET MODAL
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    if (!open) {
      return;
    }

    setStep(1);

    setEmail("");

    setOtp([
      "",
      "",
      "",
      "",
      "",
      "",
    ]);

    setPassword("");

    setError("");

    setTab(
      "otp"
    );

    setUserState({
      exists: false,
      hasPassword: false,
      checked: false,
    });

  }, [
    open,
  ]);


  /*
  |--------------------------------------------------------------------------
  | ESCAPE TO CLOSE
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    if (!open) {
      return;
    }

    const handleEscape =
      (event) => {

        if (
          event.key ===
          "Escape"
        ) {
          setOpen(false);
        }

      };

    document.addEventListener(
      "keydown",
      handleEscape
    );

    return () => {
      document.removeEventListener(
        "keydown",
        handleEscape
      );
    };

  }, [
    open,
    setOpen,
  ]);


  if (!open) {
    return null;
  }


  /*
  |--------------------------------------------------------------------------
  | OTP VALUE
  |--------------------------------------------------------------------------
  */

  const otpValue =
    otp.join("");


  /*
  |--------------------------------------------------------------------------
  | CHECK USER
  |--------------------------------------------------------------------------
  */

  const checkUser =
    async (
      emailValue
    ) => {

      if (!emailValue) {
        return null;
      }

      try {

        setError("");

        const response =
          await fetch(
            "https://lightblue-moose-690494.hostingersite.com/api/customer/check-user",
            {
              method: "POST",

              headers: {
                "Content-Type":
                  "application/json",
              },

              body:
                JSON.stringify({
                  email:
                    emailValue,
                }),
            }
          );

        const data =
          await response.json();

        setUserState({
          exists:
            !!data.exists,

          hasPassword:
            !!data.has_password,

          checked: true,
        });

        return data;

      } catch (
        err
      ) {

        console.error(
          "Check user error:",
          err
        );

        setError(
          "Something went wrong. Please try again."
        );

        return null;
      }
    };


  /*
  |--------------------------------------------------------------------------
  | OTP CHANGE
  |--------------------------------------------------------------------------
  */

  const handleOtpChange =
    (
      event,
      index
    ) => {

      const value =
        event.target.value
          .replace(
            /\D/g,
            ""
          );

      const newOtp =
        [...otp];


      if (
        value === ""
      ) {

        newOtp[index] = "";

        setOtp(
          newOtp
        );

        return;
      }


      newOtp[index] =
        value[0];

      setOtp(
        newOtp
      );


      if (
        index <
        otp.length - 1
      ) {

        otpRefs.current[
          index + 1
        ]?.focus();

      }

    };


  /*
  |--------------------------------------------------------------------------
  | OTP KEYDOWN
  |--------------------------------------------------------------------------
  */

  const handleOtpKeyDown =
    (
      event,
      index
    ) => {

      if (
        event.key !==
        "Backspace"
      ) {
        return;
      }


      if (
        otp[index]
      ) {

        const newOtp =
          [...otp];

        newOtp[index] =
          "";

        setOtp(
          newOtp
        );

        return;
      }


      if (
        index > 0
      ) {

        otpRefs.current[
          index - 1
        ]?.focus();

        const newOtp =
          [...otp];

        newOtp[
          index - 1
        ] = "";

        setOtp(
          newOtp
        );

      }

    };


  /*
  |--------------------------------------------------------------------------
  | OTP PASTE
  |--------------------------------------------------------------------------
  */

  const handleOtpPaste =
    (
      event
    ) => {

      event.preventDefault();

      const pasted =
        event.clipboardData
          .getData(
            "text"
          )
          .replace(
            /\D/g,
            ""
          )
          .slice(
            0,
            6
          );


      const newOtp =
        [
          "",
          "",
          "",
          "",
          "",
          "",
        ];


      pasted
        .split("")
        .forEach(
          (
            digit,
            index
          ) => {

            newOtp[index] =
              digit;

          }
        );


      setOtp(
        newOtp
      );

      const nextIndex =
        Math.min(
          pasted.length,
          5
        );

      otpRefs.current[
        nextIndex
      ]?.focus();

    };


  /*
  |--------------------------------------------------------------------------
  | SEND OTP
  |--------------------------------------------------------------------------
  */

  const handleSendOtp =
    async (
      event
    ) => {

      event.preventDefault();

      if (
        !email.trim()
      ) {

        setError(
          "Please enter your email address."
        );

        return;
      }


      try {

        setLoading(
          true
        );

        setError("");

        await sendOtp(
          email.trim()
        );

        setStep(2);

      } catch (
        err
      ) {

        setError(
          err.message ||
            "Unable to send OTP."
        );

      } finally {

        setLoading(
          false
        );

      }

    };


  /*
  |--------------------------------------------------------------------------
  | VERIFY OTP
  |--------------------------------------------------------------------------
  */

  const handleVerifyOtp = async (event) => {
    event.preventDefault();

    if (otpValue.length !== 6) {
      setError("Please enter the 6-digit OTP.");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const response = await verifyOtp(
        email.trim(),
        otpValue
      );

      console.log("VERIFY OTP RESPONSE:", response);

      const loggedInCustomer =
        response?.customer || {
          email: email.trim(),
        };

      const customerData = {
        ...loggedInCustomer,
        token: response?.token,
      };

      /*
      |--------------------------------------------------------------------------
      | SAVE CUSTOMER
      |--------------------------------------------------------------------------
      */

      setCustomer(customerData);

      localStorage.setItem(
        "customer_token",
        response.token
      );

      localStorage.setItem(
        "customer",
        JSON.stringify(customerData)
      );

      /*
      |--------------------------------------------------------------------------
      | SAVE COMMON CUSTOMER VALUES
      |--------------------------------------------------------------------------
      */

      localStorage.setItem(
        "customer_id",
        customerData?._id ||
          customerData?.id ||
          ""
      );

      localStorage.setItem(
        "customer_name",
        customerData?.name ||
          ""
      );

      localStorage.setItem(
        "customer_email",
        customerData?.email ||
          email.trim()
      );

      localStorage.setItem(
        "customer_phone",
        customerData?.phone ||
          ""
      );

      setOpen(false);

      navigate("/");

    } catch (err) {
      console.error("OTP Login Error:", err);

      setError(
        err.message ||
          "Invalid OTP."
      );

    } finally {
      setLoading(false);
    }
  };


  /*
  |--------------------------------------------------------------------------
  | PASSWORD LOGIN
  |--------------------------------------------------------------------------
  */

  const handlePasswordLogin =
    async (
      event
    ) => {

      event.preventDefault();


      if (
        !email.trim()
      ) {

        setError(
          "Please enter your email address."
        );

        return;
      }


      if (
        !password
      ) {

        setError(
          "Please enter your password."
        );

        return;
      }


      try {

        setLoading(
          true
        );

        setError("");


        const response =
          await loginWithPassword(
            email.trim(),
            password
          );


        setCustomer(
          response.customer
        );


        localStorage.setItem(
          "customer_token",
          response.token
        );


        if (
          response.customer
        ) {

          localStorage.setItem(
            "customer",
            JSON.stringify(
              response.customer
            )
          );

        }


        setOpen(
          false
        );

        navigate(
          "/"
        );

      } catch (
        err
      ) {

        setError(
          err.message ||
            "Unable to login."
        );

      } finally {

        setLoading(
          false
        );

      }

    };


  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <div
      className="
        fixed
        inset-0
        z-[9999]
        flex
        items-end
        justify-center
        bg-black/50
        px-0
        backdrop-blur-sm
        sm:items-center
        sm:px-4
      "
      onMouseDown={(event) => {

        if (
          event.target ===
          event.currentTarget
        ) {
          setOpen(false);
        }

      }}
    >

      <div
        className="
          relative
          w-full
          max-w-md
          overflow-hidden
          rounded-t-[28px]
          border
          border-sky-100
          bg-white
          shadow-2xl
          sm:rounded-[28px]
        "
        onMouseDown={(event) =>
          event.stopPropagation()
        }
      >

        {/* ==================================================
            DECORATIVE BACKGROUND
        =================================================== */}

        <div
          className="
            pointer-events-none
            absolute
            -right-20
            -top-20
            h-48
            w-48
            rounded-full
            bg-sky-100/60
            blur-3xl
          "
        />

        <div
          className="
            pointer-events-none
            absolute
            -bottom-24
            -left-24
            h-52
            w-52
            rounded-full
            bg-cyan-100/40
            blur-3xl
          "
        />


        <div
          className="
            relative
            max-h-[92vh]
            overflow-y-auto
            px-5
            pb-6
            pt-5
            sm:px-7
            sm:pb-7
            sm:pt-6
          "
        >

          {/* ==================================================
              CLOSE
          =================================================== */}

          <button
            type="button"
            onClick={() =>
              setOpen(false)
            }
            aria-label="Close"
            className="
              absolute
              right-4
              top-4
              flex
              h-9
              w-9
              items-center
              justify-center
              rounded-full
              bg-gray-50
              text-gray-400
              transition
              hover:bg-sky-50
              hover:text-sky-500
            "
          >
            <FaTimes
              size={13}
            />
          </button>


          {/* ==================================================
              HEADER
          =================================================== */}

          <div
            className="
              pr-10
            "
          >

            <div
              className="
                flex
                items-center
                gap-2
              "
            >

              <div
                className="
                  flex
                  h-10
                  w-10
                  items-center
                  justify-center
                  rounded-xl
                  bg-sky-50
                  text-sky-500
                "
              >
                <FaUserCheck
                  size={15}
                />
              </div>

              <div>

                <p
                  className="
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.16em]
                    text-sky-500
                  "
                >
                  Welcome Back
                </p>

                <h2
                  className="
                    mt-0.5
                    text-xl
                    font-extrabold
                    text-gray-900
                    sm:text-2xl
                  "
                >
                  Log In / Sign Up
                </h2>

              </div>

            </div>


            <p
              className="
                mt-4
                text-xs
                leading-6
                text-gray-500
                sm:text-sm
              "
            >
              Access your saved properties,
              premium listings and account.
            </p>

          </div>


          {/* ==================================================
              TABS
          =================================================== */}

          <div
            className="
              mt-6
              grid
              grid-cols-2
              rounded-xl
              bg-gray-100
              p-1
            "
          >

            <button
              type="button"
              onClick={() => {

                setTab(
                  "otp"
                );

                setError("");

              }}
              className={`
                flex
                min-h-[42px]
                items-center
                justify-center
                gap-2
                rounded-lg
                px-3
                py-2
                text-xs
                font-semibold
                transition
                sm:text-sm

                ${
                  tab ===
                  "otp"
                    ? "bg-white text-sky-600 shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }
              `}
            >

              <FaBolt
                className="
                  text-[10px]
                "
              />

              OTP Login

            </button>


            <button
              type="button"
              onClick={async () => {

                setTab(
                  "password"
                );

                setError("");

                if (
                  email.trim()
                ) {

                  await checkUser(
                    email.trim()
                  );

                }

              }}
              className={`
                flex
                min-h-[42px]
                items-center
                justify-center
                gap-2
                rounded-lg
                px-3
                py-2
                text-xs
                font-semibold
                transition
                sm:text-sm

                ${
                  tab ===
                  "password"
                    ? "bg-white text-sky-600 shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }
              `}
            >

              <FaKey
                className="
                  text-[10px]
                "
              />

              Password

            </button>

          </div>


          {/* ==================================================
              ERROR
          =================================================== */}

          {error && (
            <div
              className="
                mt-4
                rounded-xl
                border
                border-red-100
                bg-red-50
                px-4
                py-3
                text-xs
                leading-5
                text-red-600
              "
            >
              {error}
            </div>
          )}


          {/* ==================================================
              OTP LOGIN
          =================================================== */}

          {tab === "otp" && (
            <div className="mt-6">

              {step === 1 && (
                <form
                  onSubmit={
                    handleSendOtp
                  }
                  className="
                    space-y-4
                  "
                >

                  <div>

                    <label
                      className="
                        mb-2
                        block
                        text-xs
                        font-semibold
                        text-gray-700
                      "
                    >
                      Email Address
                    </label>

                    <div
                      className="
                        relative
                      "
                    >

                      <FaEnvelope
                        className="
                          absolute
                          left-4
                          top-1/2
                          -translate-y-1/2
                          text-xs
                          text-gray-400
                        "
                      />

                      <input
                        type="email"
                        value={
                          email
                        }
                        onChange={(
                          event
                        ) =>
                          setEmail(
                            event.target.value
                          )
                        }
                        placeholder="Enter your email address"
                        autoComplete="email"
                        className="
                          h-12
                          w-full
                          rounded-xl
                          border
                          border-gray-200
                          bg-gray-50
                          pl-11
                          pr-4
                          text-sm
                          text-gray-700
                          outline-none
                          transition
                          placeholder:text-gray-400
                          focus:border-sky-400
                          focus:bg-white
                          focus:ring-2
                          focus:ring-sky-100
                        "
                      />

                    </div>

                  </div>


                  <button
                    type="submit"
                    disabled={
                      loading
                    }
                    className="
                      flex
                      min-h-[48px]
                      w-full
                      items-center
                      justify-center
                      gap-2
                      rounded-xl
                      bg-sky-500
                      px-5
                      py-3
                      text-sm
                      font-semibold
                      text-white
                      shadow-md
                      shadow-sky-500/20
                      transition
                      hover:bg-sky-600
                      active:scale-[0.98]
                      disabled:cursor-not-allowed
                      disabled:opacity-50
                    "
                  >

                    <FaBolt
                      className="
                        text-xs
                      "
                    />

                    {loading
                      ? "Sending..."
                      : "Send OTP"}

                    {!loading && (
                      <FaArrowRight
                        className="
                          text-[9px]
                        "
                      />
                    )}

                  </button>


                  <p
                    className="
                      text-center
                      text-[10px]
                      leading-5
                      text-gray-400
                    "
                  >
                    We'll send a 6-digit verification
                    code to your email.
                  </p>

                </form>
              )}


              {step === 2 && (
                <form
                  onSubmit={
                    handleVerifyOtp
                  }
                  className="
                    space-y-5
                  "
                >

                  <div
                    className="
                      rounded-xl
                      bg-sky-50
                      px-4
                      py-3
                      text-center
                    "
                  >

                    <p
                      className="
                        text-xs
                        text-gray-600
                      "
                    >
                      OTP sent to
                    </p>

                    <p
                      className="
                        mt-0.5
                        break-all
                        text-xs
                        font-semibold
                        text-sky-600
                      "
                    >
                      {email}
                    </p>

                  </div>


                  {/* OTP INPUTS */}

                  <div>
                    <p
                      className="
                        mb-3
                        text-center
                        text-xs
                        font-semibold
                        text-gray-700
                      "
                    >
                      Enter 6-digit OTP
                    </p>

                    <div
                      className="
                        flex
                        justify-center
                        gap-1.5
                        sm:gap-2
                      "
                    >

                      {otp.map(
                        (
                          value,
                          index
                        ) => (
                          <input
                            key={
                              index
                            }
                            ref={(
                              element
                            ) =>
                              (otpRefs.current[
                                index
                              ] =
                                element)
                            }
                            type="text"
                            inputMode="numeric"
                            autoComplete={
                              index ===
                              0
                                ? "one-time-code"
                                : "off"
                            }
                            maxLength={1}
                            value={
                              value
                            }
                            onChange={(
                              event
                            ) =>
                              handleOtpChange(
                                event,
                                index
                              )
                            }
                            onKeyDown={(
                              event
                            ) =>
                              handleOtpKeyDown(
                                event,
                                index
                              )
                            }
                            onPaste={
                              handleOtpPaste
                            }
                            className="
                              h-11
                              min-w-0
                              flex-1
                              rounded-xl
                              border
                              border-gray-200
                              bg-gray-50
                              text-center
                              text-base
                              font-bold
                              text-gray-900
                              outline-none
                              transition
                              focus:border-sky-400
                              focus:bg-white
                              focus:ring-2
                              focus:ring-sky-100
                              sm:h-12
                              sm:max-w-[48px]
                            "
                          />
                        )
                      )}

                    </div>

                  </div>


                  <button
                    type="submit"
                    disabled={
                      loading
                    }
                    className="
                      flex
                      min-h-[48px]
                      w-full
                      items-center
                      justify-center
                      gap-2
                      rounded-xl
                      bg-sky-500
                      px-5
                      py-3
                      text-sm
                      font-semibold
                      text-white
                      shadow-md
                      shadow-sky-500/20
                      transition
                      hover:bg-sky-600
                      active:scale-[0.98]
                      disabled:cursor-not-allowed
                      disabled:opacity-50
                    "
                  >

                    <FaUserCheck
                      className="
                        text-xs
                      "
                    />

                    {loading
                      ? "Verifying..."
                      : "Verify & Continue"}

                  </button>


                  <div
                    className="
                      flex
                      items-center
                      justify-between
                      gap-3
                    "
                  >

                    <button
                      type="button"
                      onClick={() => {

                        setStep(
                          1
                        );

                        setOtp([
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                        ]);

                        setError("");

                      }}
                      className="
                        text-xs
                        font-medium
                        text-gray-500
                        hover:text-gray-700
                      "
                    >
                      Change Email
                    </button>


                    <button
                      type="button"
                      onClick={
                        handleSendOtp
                      }
                      disabled={
                        loading
                      }
                      className="
                        text-xs
                        font-semibold
                        text-sky-500
                        hover:underline
                        disabled:opacity-50
                      "
                    >
                      Resend OTP
                    </button>

                  </div>

                </form>
              )}

            </div>
          )}


          {/* ==================================================
              PASSWORD LOGIN
          =================================================== */}

          {tab === "password" && (
            <div className="mt-6">

              {userState.checked &&
                !userState.exists && (
                  <div
                    className="
                      mb-4
                      rounded-xl
                      border
                      border-amber-100
                      bg-amber-50
                      px-4
                      py-3
                      text-xs
                      leading-5
                      text-amber-700
                    "
                  >
                    No account found with this email.
                    Please use OTP login to continue.
                  </div>
                )}


              {userState.checked &&
                userState.exists &&
                !userState.hasPassword && (
                  <div
                    className="
                      mb-4
                      rounded-xl
                      border
                      border-sky-100
                      bg-sky-50
                      px-4
                      py-3
                      text-xs
                      leading-5
                      text-sky-700
                    "
                  >
                    This account doesn't have a password
                    yet. Please use OTP login first.
                  </div>
                )}


              <form
                onSubmit={
                  handlePasswordLogin
                }
                className="
                  space-y-4
                "
              >

                {/* EMAIL */}

                <div>

                  <label
                    className="
                      mb-2
                      block
                      text-xs
                      font-semibold
                      text-gray-700
                    "
                  >
                    Email Address
                  </label>

                  <div
                    className="
                      relative
                    "
                  >

                    <FaEnvelope
                      className="
                        absolute
                        left-4
                        top-1/2
                        -translate-y-1/2
                        text-xs
                        text-gray-400
                      "
                    />

                    <input
                      type="email"
                      value={
                        email
                      }
                      onChange={(
                        event
                      ) =>
                        setEmail(
                          event.target.value
                        )
                      }
                      onBlur={() => {

                        if (
                          email.trim()
                        ) {
                          checkUser(
                            email.trim()
                          );
                        }

                      }}
                      placeholder="Enter your email address"
                      autoComplete="email"
                      className="
                        h-12
                        w-full
                        rounded-xl
                        border
                        border-gray-200
                        bg-gray-50
                        pl-11
                        pr-4
                        text-sm
                        text-gray-700
                        outline-none
                        transition
                        placeholder:text-gray-400
                        focus:border-sky-400
                        focus:bg-white
                        focus:ring-2
                        focus:ring-sky-100
                      "
                    />

                  </div>

                </div>


                {/* PASSWORD */}

                <div>

                  <label
                    className="
                      mb-2
                      block
                      text-xs
                      font-semibold
                      text-gray-700
                    "
                  >
                    Password
                  </label>

                  <div
                    className="
                      relative
                    "
                  >

                    <FaLock
                      className="
                        absolute
                        left-4
                        top-1/2
                        -translate-y-1/2
                        text-xs
                        text-gray-400
                      "
                    />

                    <input
                      type="password"
                      value={
                        password
                      }
                      onChange={(
                        event
                      ) =>
                        setPassword(
                          event.target.value
                        )
                      }
                      placeholder={
                        userState.hasPassword
                          ? "Enter your password"
                          : "Password"
                      }
                      autoComplete="current-password"
                      className="
                        h-12
                        w-full
                        rounded-xl
                        border
                        border-gray-200
                        bg-gray-50
                        pl-11
                        pr-4
                        text-sm
                        text-gray-700
                        outline-none
                        transition
                        placeholder:text-gray-400
                        focus:border-sky-400
                        focus:bg-white
                        focus:ring-2
                        focus:ring-sky-100
                      "
                    />

                  </div>

                </div>


                <button
                  type="submit"
                  disabled={
                    loading
                  }
                  className="
                    flex
                    min-h-[48px]
                    w-full
                    items-center
                    justify-center
                    gap-2
                    rounded-xl
                    bg-sky-500
                    px-5
                    py-3
                    text-sm
                    font-semibold
                    text-white
                    shadow-md
                    shadow-sky-500/20
                    transition
                    hover:bg-sky-600
                    active:scale-[0.98]
                    disabled:cursor-not-allowed
                    disabled:opacity-50
                  "
                >

                  <FaKey
                    className="
                      text-xs
                    "
                  />

                  {loading
                    ? "Processing..."
                    : "Continue"}

                  {!loading && (
                    <FaArrowRight
                      className="
                        text-[9px]
                      "
                    />
                  )}

                </button>


                <button
                  type="button"
                  onClick={() => {

                    setTab(
                      "otp"
                    );

                    setStep(
                      1
                    );

                    setError("");

                  }}
                  className="
                    block
                    w-full
                    text-center
                    text-xs
                    font-medium
                    text-gray-500
                    transition
                    hover:text-sky-500
                  "
                >
                  Prefer OTP login?
                  <span className="ml-1 font-semibold text-sky-500">
                    Use OTP
                  </span>
                </button>

              </form>

            </div>
          )}


          {/* ==================================================
              FOOT NOTE
          =================================================== */}

          <div
            className="
              mt-6
              border-t
              border-gray-100
              pt-4
              text-center
            "
          >

            <p
              className="
                text-[10px]
                leading-5
                text-gray-400
              "
            >
              By continuing, you agree to use Estatein's
              account and property services.
            </p>

          </div>

        </div>

      </div>

    </div>
  );
};

export default CustomerLogin;