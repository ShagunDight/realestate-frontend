import React, {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  Link,
  useParams,
} from "react-router-dom";

import {
  FaArrowLeft,
  FaArrowRight,
  FaClock,
} from "react-icons/fa";

import Footer from "../components/Footer";


const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";

const FALLBACK_IMAGE =
  "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg";


const BlogDetails = () => {

  const {
    slug,
  } = useParams();


  const [
    blog,
    setBlog,
  ] = useState(null);

  const [
    allBlogs,
    setAllBlogs,
  ] = useState([]);

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    notFound,
    setNotFound,
  ] = useState(false);


  /*
  |--------------------------------------------------------------------------
  | FETCH CURRENT BLOG
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    const fetchBlog =
      async () => {

        try {

          setLoading(true);
          setNotFound(false);

          const response =
            await fetch(
              `${API_BASE}/api/blogs/${slug}`
            );

          if (!response.ok) {
            throw new Error(
              "Blog not found"
            );
          }

          const data =
            await response.json();

          if (
            data?.data
          ) {

            setBlog(
              data.data
            );

          } else {

            setBlog(null);
            setNotFound(true);

          }

        } catch (
          error
        ) {

          console.error(
            "Blog details error:",
            error
          );

          setBlog(null);
          setNotFound(true);

        } finally {

          setLoading(false);

        }

      };

    if (slug) {
      fetchBlog();
    }

  }, [slug]);


  /*
  |--------------------------------------------------------------------------
  | FETCH ALL BLOGS
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    const fetchBlogs =
      async () => {

        try {

          const response =
            await fetch(
              `${API_BASE}/api/blogs`
            );

          if (!response.ok) {
            throw new Error(
              "Blogs fetch failed"
            );
          }

          const data =
            await response.json();

          const result =
            Array.isArray(
              data?.data
            )
              ? data.data
              : [];

          setAllBlogs(
            result
          );

        } catch (
          error
        ) {

          console.error(
            "All blogs error:",
            error
          );

          setAllBlogs([]);

        }

      };

    fetchBlogs();

  }, []);


  /*
  |--------------------------------------------------------------------------
  | RELATED DATA
  |--------------------------------------------------------------------------
  */

  const filteredBlogs =
    useMemo(() => {

      return allBlogs.filter(
        (item) =>
          item?.slug !==
            slug &&
          item?.type ===
            "market_news"
      );

    }, [
      allBlogs,
      slug,
    ]);


  const relatedBlogs =
    useMemo(() => {

      return allBlogs.filter(
        (item) =>
          item?.slug !==
            slug &&
          item?.type ===
            "blog"
      );

    }, [
      allBlogs,
      slug,
    ]);


  /*
  |--------------------------------------------------------------------------
  | IMAGE
  |--------------------------------------------------------------------------
  */

  const getImage =
    (image) => {

      if (!image) {
        return FALLBACK_IMAGE;
      }

      return `${API_BASE}/public${image}`;
    };


  /*
  |--------------------------------------------------------------------------
  | TITLE
  |--------------------------------------------------------------------------
  */

  const title =
    blog?.title
      ?.replace(
        /[\r\n]+/g,
        " "
      )
      .replace(
        /\s+/g,
        " "
      )
      .trim() ||
    "Property Insights";


  /*
  |--------------------------------------------------------------------------
  | LOADING
  |--------------------------------------------------------------------------
  */

  if (
    loading
  ) {

    return (
      <main
        className="
          min-h-screen
          bg-[#f6f9ff]
          px-3
          py-6
          sm:px-5
          sm:py-8
          lg:px-8
          lg:py-12
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1380px]
          "
        >

          <div
            className="
              h-[280px]
              animate-pulse
              rounded-[24px]
              bg-gray-200
              sm:h-[360px]
              lg:h-[460px]
            "
          />

          <div
            className="
              mt-6
              grid
              grid-cols-1
              gap-6
              lg:grid-cols-[minmax(0,1fr)_340px]
            "
          >

            <div
              className="
                rounded-[24px]
                bg-white
                p-6
                shadow-sm
              "
            >

              <div
                className="
                  h-4
                  w-24
                  animate-pulse
                  rounded
                  bg-gray-100
                "
              />

              <div
                className="
                  mt-4
                  h-4
                  w-full
                  animate-pulse
                  rounded
                  bg-gray-100
                "
              />

              <div
                className="
                  mt-3
                  h-4
                  w-11/12
                  animate-pulse
                  rounded
                  bg-gray-100
                "
              />

              <div
                className="
                  mt-3
                  h-4
                  w-10/12
                  animate-pulse
                  rounded
                  bg-gray-100
                "
              />

            </div>

            <div
              className="
                hidden
                h-72
                animate-pulse
                rounded-[24px]
                bg-white
                shadow-sm
                lg:block
              "
            />

          </div>

        </div>

      </main>
    );

  }


  /*
  |--------------------------------------------------------------------------
  | NOT FOUND
  |--------------------------------------------------------------------------
  */

  if (
    notFound ||
    !blog
  ) {

    return (
      <>
        <main
          className="
            flex
            min-h-[70vh]
            items-center
            justify-center
            bg-[#f6f9ff]
            px-4
          "
        >

          <div
            className="
              w-full
              max-w-md
              rounded-[24px]
              border
              border-gray-100
              bg-white
              p-8
              text-center
              shadow-sm
            "
          >

            <div className="text-5xl">
              📰
            </div>

            <h1
              className="
                mt-4
                text-xl
                font-bold
                text-gray-900
              "
            >
              Blog Not Found
            </h1>

            <p
              className="
                mt-2
                text-sm
                leading-6
                text-gray-500
              "
            >
              The article you're looking for could not
              be found or may have been removed.
            </p>

            <Link
              to="/blog"
              className="
                mt-6
                inline-flex
                items-center
                justify-center
                gap-2
                rounded-xl
                bg-sky-500
                px-5
                py-3
                text-sm
                font-semibold
                text-white
                transition
                hover:bg-sky-600
              "
            >
              <FaArrowLeft
                className="text-xs"
              />
              Back to Blogs
            </Link>

          </div>

        </main>

        <Footer />
      </>
    );

  }


  return (
    <>
      <main
        className="
          min-h-screen
          bg-[#f6f9ff]
          pb-10
          lg:pb-14
        "
      >

        {/* ==================================================
            HERO
        =================================================== */}

        <section
          className="
            relative
            overflow-hidden
            bg-gray-900
          "
        >

          <div
            className="
              relative
              aspect-[16/10]
              w-full
              sm:aspect-[16/8]
              lg:aspect-[16/6]
            "
          >

            <img
              src={getImage(
                blog.image
              )}
              alt={title}
              className="
                h-full
                w-full
                object-cover
              "
            />

            {/* DARK OVERLAY */}

            <div
              className="
                absolute
                inset-0
                bg-gradient-to-t
                from-black/85
                via-black/45
                to-black/10
              "
            />

          </div>


          {/* HERO CONTENT */}

          <div
            className="
              absolute
              inset-x-0
              bottom-0
            "
          >

            <div
              className="
                mx-auto
                w-full
                max-w-[1380px]
                px-4
                pb-7
                sm:px-6
                sm:pb-9
                lg:px-8
                lg:pb-12
              "
            >

              <div
                className="
                  max-w-4xl
                "
              >

                <span
                  className="
                    inline-flex
                    rounded-full
                    bg-sky-500/90
                    px-3
                    py-1.5
                    text-[10px]
                    font-semibold
                    text-white
                    backdrop-blur
                    sm:text-xs
                  "
                >
                  Blog Article
                </span>


                <h1
                  className="
                    mt-3
                    break-words
                    text-2xl
                    font-extrabold
                    leading-tight
                    text-white
                    sm:text-3xl
                    md:text-4xl
                    lg:text-5xl
                  "
                >
                  {title}
                </h1>


                <div
                  className="
                    mt-4
                    flex
                    flex-wrap
                    items-center
                    gap-3
                    text-xs
                    text-white/80
                  "
                >

                  <span
                    className="
                      inline-flex
                      items-center
                      gap-1.5
                    "
                  >
                    <FaClock
                      className="text-sky-300"
                    />

                    Real Estate Insights
                  </span>

                </div>

              </div>

            </div>

          </div>

        </section>


        {/* ==================================================
            MAIN CONTENT
        =================================================== */}

        <div
          className="
            mx-auto
            w-full
            max-w-[1380px]
            px-3
            py-6
            sm:px-5
            sm:py-8
            lg:px-8
            lg:py-10
          "
        >

          <div
            className="
              grid
              min-w-0
              grid-cols-1
              gap-6
              lg:grid-cols-[minmax(0,1fr)_340px]
            "
          >

            {/* =================================================
                LEFT CONTENT
            ================================================== */}

            <div
              className="
                min-w-0
              "
            >

              {/* BACK LINK */}

              <Link
                to="/blogs"
                className="
                  mb-4
                  inline-flex
                  items-center
                  gap-2
                  text-xs
                  font-semibold
                  text-sky-500
                  transition
                  hover:text-sky-600
                  sm:text-sm
                "
              >
                <FaArrowLeft
                  className="text-[9px]"
                />

                Back to Blogs
              </Link>


              {/* ARTICLE */}

              <article
                className="
                  overflow-hidden
                  rounded-[24px]
                  border
                  border-gray-100
                  bg-white
                  shadow-sm
                "
              >

                <div
                  className="
                    p-5
                    sm:p-7
                    lg:p-9
                  "
                >

                  <div
                    className="
                      prose
                      max-w-none

                      prose-headings:break-words
                      prose-headings:font-bold
                      prose-headings:text-gray-900

                      prose-h1:text-2xl
                      prose-h2:text-xl
                      prose-h3:text-lg

                      sm:prose-h1:text-3xl
                      sm:prose-h2:text-2xl
                      sm:prose-h3:text-xl

                      prose-p:break-words
                      prose-p:text-sm
                      prose-p:leading-7
                      prose-p:text-gray-600
                      sm:prose-p:text-base
                      sm:prose-p:leading-8

                      prose-a:text-sky-500
                      prose-a:no-underline
                      hover:prose-a:underline

                      prose-strong:text-gray-900

                      prose-img:w-full
                      prose-img:rounded-2xl
                    "
                    dangerouslySetInnerHTML={{
                      __html:
                        blog.content ||
                        "<p>No content available.</p>",
                    }}
                  />

                </div>

              </article>


              {/* =================================================
                  RELATED BLOGS
              ================================================== */}

              {relatedBlogs.length >
                0 && (

                <section
                  className="
                    mt-7
                    sm:mt-8
                  "
                >

                  <div
                    className="
                      mb-4
                      flex
                      items-end
                      justify-between
                      gap-3
                    "
                  >

                    <div>

                      <p
                        className="
                          text-[10px]
                          font-bold
                          uppercase
                          tracking-[0.16em]
                          text-sky-500
                        "
                      >
                        Continue Reading
                      </p>

                      <h2
                        className="
                          mt-1
                          text-xl
                          font-bold
                          text-gray-900
                          sm:text-2xl
                        "
                      >
                        Related Blogs
                      </h2>

                    </div>

                    <Link
                      to="/blog"
                      className="
                        hidden
                        items-center
                        gap-1.5
                        text-xs
                        font-semibold
                        text-sky-500
                        sm:flex
                      "
                    >
                      View All
                      <FaArrowRight
                        className="text-[9px]"
                      />
                    </Link>

                  </div>


                  <div
                    className="
                      grid
                      grid-cols-1
                      gap-3
                      sm:grid-cols-2
                    "
                  >

                    {relatedBlogs
                      .slice(0, 4)
                      .map(
                        (
                          item,
                          index
                        ) => (

                          <Link
                            key={
                              item?._id ||
                              item?.id ||
                              index
                            }
                            to={`/blog/${item.slug}`}
                            className="
                              group
                              min-w-0
                              overflow-hidden
                              rounded-2xl
                              border
                              border-gray-100
                              bg-white
                              shadow-sm
                              transition
                              hover:-translate-y-0.5
                              hover:shadow-lg
                            "
                          >

                            <div
                              className="
                                aspect-[16/10]
                                overflow-hidden
                                bg-gray-100
                              "
                            >

                              <img
                                src={getImage(
                                  item.image
                                )}
                                alt={
                                  item.title
                                }
                                className="
                                  h-full
                                  w-full
                                  object-cover
                                  transition
                                  duration-500
                                  group-hover:scale-105
                                "
                              />

                            </div>


                            <div
                              className="
                                p-4
                              "
                            >

                              <p
                                className="
                                  line-clamp-2
                                  text-sm
                                  font-semibold
                                  leading-5
                                  text-gray-800
                                  transition
                                  group-hover:text-sky-600
                                "
                              >
                                {
                                  item.title
                                }
                              </p>

                              <span
                                className="
                                  mt-3
                                  inline-flex
                                  items-center
                                  gap-1.5
                                  text-[10px]
                                  font-semibold
                                  text-sky-500
                                  sm:text-xs
                                "
                              >
                                Read Article
                                <FaArrowRight
                                  className="text-[8px]"
                                />
                              </span>

                            </div>

                          </Link>

                        )
                      )}

                  </div>

                </section>

              )}

            </div>


            {/* =================================================
                SIDEBAR
            ================================================== */}

            <aside
              className="
                min-w-0
                space-y-5
                lg:sticky
                lg:top-24
                lg:self-start
              "
            >

              {/* =================================================
                  RECENT NEWS
              ================================================== */}

              <section
                className="
                  rounded-[24px]
                  border
                  border-gray-100
                  bg-white
                  p-5
                  shadow-sm
                  sm:p-6
                "
              >

                <p
                  className="
                    text-[10px]
                    font-bold
                    uppercase
                    tracking-[0.16em]
                    text-sky-500
                  "
                >
                  Market Updates
                </p>

                <h3
                  className="
                    mt-1
                    text-xl
                    font-bold
                    text-gray-900
                  "
                >
                  Recent News
                </h3>


                <div
                  className="
                    mt-5
                    space-y-2
                  "
                >

                  {filteredBlogs
                    .slice(0, 5)
                    .map(
                      (
                        item,
                        index
                      ) => (

                        <Link
                          key={
                            item?._id ||
                            item?.id ||
                            index
                          }
                          to={`/blog/${item.slug}`}
                          className="
                            group
                            flex
                            min-w-0
                            gap-3
                            rounded-xl
                            p-2
                            transition
                            hover:bg-sky-50
                          "
                        >

                          <div
                            className="
                              h-16
                              w-16
                              shrink-0
                              overflow-hidden
                              rounded-xl
                              bg-gray-100
                            "
                          >

                            <img
                              src={getImage(
                                item.image
                              )}
                              alt={
                                item.title
                              }
                              className="
                                h-full
                                w-full
                                object-cover
                                transition
                                duration-300
                                group-hover:scale-105
                              "
                            />

                          </div>


                          <div
                            className="
                              min-w-0
                              flex-1
                            "
                          >

                            <p
                              className="
                                line-clamp-2
                                text-xs
                                font-semibold
                                leading-5
                                text-gray-800
                                transition
                                group-hover:text-sky-600
                              "
                            >
                              {
                                item.title
                              }
                            </p>

                            <span
                              className="
                                mt-1
                                block
                                text-[10px]
                                text-gray-400
                              "
                            >
                              Market News
                            </span>

                          </div>

                        </Link>

                      )
                    )}

                </div>


                {filteredBlogs.length ===
                  0 && (
                  <p
                    className="
                      mt-5
                      text-xs
                      text-gray-400
                    "
                  >
                    No recent news available.
                  </p>
                )}

              </section>


              {/* =================================================
                  INFO BOX
              ================================================== */}

              <section
                className="
                  rounded-[24px]
                  border
                  border-sky-100
                  bg-sky-50
                  p-5
                  sm:p-6
                "
              >

                <div
                  className="
                    flex
                    h-10
                    w-10
                    items-center
                    justify-center
                    rounded-xl
                    bg-white
                    text-sky-500
                    shadow-sm
                  "
                >
                  ✦
                </div>

                <h4
                  className="
                    mt-4
                    text-lg
                    font-bold
                    text-sky-700
                  "
                >
                  Real Estate Insights
                </h4>

                <p
                  className="
                    mt-2
                    text-xs
                    leading-6
                    text-gray-600
                    sm:text-sm
                  "
                >
                  Get the latest updates about
                  commercial property, valuation
                  methods, market trends, and investment
                  strategies.
                </p>

              </section>

            </aside>

          </div>

        </div>

      </main>


      <Footer />
    </>
  );
};

export default BlogDetails;