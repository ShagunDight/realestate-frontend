import React, {
  useEffect,
  useRef,
  useState,
} from "react";

import BlogCard from "../components/BlogCard";
import Footer from "../components/Footer";

const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";

const BLOGS_PER_PAGE = 6;

const Blogs = () => {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] =
    useState(1);

  const blogRef = useRef(null);

  /*
  |--------------------------------------------------------------------------
  | FETCH BLOGS
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    fetchBlogs();
  }, []);

  const fetchBlogs = async () => {
    try {
      setLoading(true);

      const response = await fetch(
        `${API_BASE}/api/blogs`
      );

      if (!response.ok) {
        throw new Error(
          "Failed to fetch blogs"
        );
      }

      const data =
        await response.json();

      const filtered = (
        Array.isArray(data?.data)
          ? data.data
          : []
      ).filter(
        (item) =>
          item?.type === "blog"
      );

      setBlogs(filtered);
      setCurrentPage(1);
    } catch (error) {
      console.error(
        "Blog Error:",
        error
      );

      setBlogs([]);
    } finally {
      setLoading(false);
    }
  };

  /*
  |--------------------------------------------------------------------------
  | PAGINATION DATA
  |--------------------------------------------------------------------------
  */

  const totalBlogs =
    blogs.length;

  const totalPages =
    Math.max(
      1,
      Math.ceil(
        totalBlogs /
          BLOGS_PER_PAGE
      )
    );

  const startIndex =
    (currentPage - 1) *
    BLOGS_PER_PAGE;

  const endIndex =
    startIndex +
    BLOGS_PER_PAGE;

  const currentBlogs =
    blogs.slice(
      startIndex,
      endIndex
    );

  /*
  |--------------------------------------------------------------------------
  | PAGE CHANGE
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    if (!loading) {
      blogRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  }, [
    currentPage,
    loading,
  ]);

  const changePage = (
    newPage
  ) => {
    if (
      newPage < 1 ||
      newPage > totalPages
    ) {
      return;
    }

    setCurrentPage(
      newPage
    );
  };

  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <>
    <main
      ref={blogRef}
      className="
        min-h-screen
        bg-[#f6f9ff]
        px-3
        py-6
        sm:px-5
        sm:py-8
        lg:px-8
        lg:py-12
      "
    >
      <div
        className="
          mx-auto
          w-full
          max-w-[1380px]
        "
      >

        {/* ==================================================
            HEADER
        =================================================== */}

        <section
          className="
            relative
            overflow-hidden
            rounded-[26px]
            border
            border-sky-100
            bg-white
            px-5
            py-7
            shadow-sm
            sm:px-7
            sm:py-9
            lg:px-10
            lg:py-11
          "
        >

          {/* DECORATIVE GLOW */}

          <div
            className="
              pointer-events-none
              absolute
              -right-16
              -top-16
              h-40
              w-40
              rounded-full
              bg-sky-100/70
              blur-3xl
              sm:h-56
              sm:w-56
            "
          />

          <div className="relative">

            <div
              className="
                flex
                items-center
                gap-1.5
              "
            >
              <span
                className="
                  h-1.5
                  w-1.5
                  rounded-full
                  bg-sky-300
                "
              />

              <span
                className="
                  h-2.5
                  w-2.5
                  rounded-full
                  bg-sky-500
                "
              />

              <span
                className="
                  h-1.5
                  w-1.5
                  rounded-full
                  bg-sky-300
                "
              />
            </div>

            <p
              className="
                mt-3
                text-[10px]
                font-bold
                uppercase
                tracking-[0.18em]
                text-sky-500
                sm:text-xs
              "
            >
              Insights & Updates
            </p>

            <h1
              className="
                mt-1
                break-words
                text-3xl
                font-extrabold
                tracking-tight
                text-gray-900
                sm:text-4xl
                md:text-5xl
              "
            >
              Latest Blogs
            </h1>

            <p
              className="
                mt-3
                max-w-2xl
                text-xs
                leading-6
                text-gray-500
                sm:text-sm
                sm:leading-7
              "
            >
              Explore the latest real estate insights,
              market updates, investment ideas, property
              trends, and useful guidance.
            </p>

          </div>
        </section>


        {/* ==================================================
            BLOG CONTENT
        =================================================== */}

        <section className="mt-6 sm:mt-8">

          {/* LOADING */}

          {loading ? (

            <div
              className="
                grid
                grid-cols-1
                gap-4
                sm:grid-cols-2
                sm:gap-5
                lg:grid-cols-3
                lg:gap-6
              "
            >

              {Array.from(
                {
                  length: BLOGS_PER_PAGE,
                },
                (_, index) => (
                  <div
                    key={index}
                    className="
                      overflow-hidden
                      rounded-2xl
                      border
                      border-gray-100
                      bg-white
                      shadow-sm
                    "
                  >
                    <div
                      className="
                        aspect-[16/10]
                        animate-pulse
                        bg-gray-100
                      "
                    />

                    <div className="p-5">

                      <div
                        className="
                          h-4
                          w-3/4
                          animate-pulse
                          rounded
                          bg-gray-100
                        "
                      />

                      <div
                        className="
                          mt-3
                          h-3
                          w-full
                          animate-pulse
                          rounded
                          bg-gray-100
                        "
                      />

                      <div
                        className="
                          mt-2
                          h-3
                          w-5/6
                          animate-pulse
                          rounded
                          bg-gray-100
                        "
                      />

                    </div>
                  </div>
                )
              )}

            </div>

          ) : currentBlogs.length >
            0 ? (

            <>
              {/* RESULT INFO */}

              <div
                className="
                  mb-4
                  flex
                  flex-col
                  gap-2
                  sm:flex-row
                  sm:items-center
                  sm:justify-between
                "
              >

                <div>
                  <p
                    className="
                      text-sm
                      font-semibold
                      text-gray-900
                    "
                  >
                    Latest Articles
                  </p>

                  <p
                    className="
                      mt-0.5
                      text-xs
                      text-gray-500
                    "
                  >
                    Showing{" "}
                    <span className="font-semibold text-gray-700">
                      {startIndex + 1}
                    </span>{" "}
                    -{" "}
                    <span className="font-semibold text-gray-700">
                      {Math.min(
                        endIndex,
                        totalBlogs
                      )}
                    </span>{" "}
                    of{" "}
                    <span className="font-semibold text-gray-700">
                      {totalBlogs}
                    </span>
                  </p>
                </div>

                <span
                  className="
                    w-fit
                    rounded-full
                    bg-sky-50
                    px-3
                    py-1.5
                    text-[10px]
                    font-semibold
                    text-sky-600
                    sm:text-xs
                  "
                >
                  {totalBlogs} Articles
                </span>

              </div>


              {/* BLOG GRID */}

              <div
                className="
                  grid
                  grid-cols-1
                  gap-4
                  sm:grid-cols-2
                  sm:gap-5
                  lg:grid-cols-3
                  lg:gap-6
                "
              >

                {currentBlogs.map(
                  (
                    blog,
                    index
                  ) => (
                    <div
                      key={
                        blog?._id ||
                        blog?.id ||
                        blog?.slug ||
                        index
                      }
                      className="
                        min-w-0
                        transition
                        duration-300
                        hover:-translate-y-1
                      "
                    >
                      <BlogCard
                        blog={blog}
                      />
                    </div>
                  )
                )}

              </div>


              {/* ==================================================
                  PAGINATION
              =================================================== */}

              {totalPages > 1 && (
                <div
                  className="
                    mt-8
                    flex
                    flex-col
                    gap-4
                    sm:mt-10
                    sm:flex-row
                    sm:items-center
                    sm:justify-between
                  "
                >

                  {/* SUMMARY */}

                  <p
                    className="
                      text-center
                      text-xs
                      text-gray-500
                      sm:text-left
                    "
                  >
                    Page{" "}
                    <span className="font-semibold text-gray-700">
                      {currentPage}
                    </span>{" "}
                    of{" "}
                    <span className="font-semibold text-gray-700">
                      {totalPages}
                    </span>
                  </p>


                  {/* BUTTONS */}

                  <div
                    className="
                      flex
                      items-center
                      justify-center
                      gap-2
                    "
                  >

                    <button
                      type="button"
                      onClick={() =>
                        changePage(
                          currentPage - 1
                        )
                      }
                      disabled={
                        currentPage === 1
                      }
                      className="
                        flex
                        h-10
                        w-10
                        items-center
                        justify-center
                        rounded-xl
                        border
                        border-gray-200
                        bg-white
                        text-sm
                        text-gray-700
                        shadow-sm
                        transition
                        hover:border-sky-300
                        hover:bg-sky-50
                        hover:text-sky-600
                        disabled:cursor-not-allowed
                        disabled:opacity-40
                      "
                      aria-label="Previous page"
                    >
                      <span className="text-lg">
                        ←
                      </span>
                    </button>


                    {/* PAGE NUMBERS */}

                    <div
                      className="
                        flex
                        max-w-[70vw]
                        items-center
                        gap-1.5
                        overflow-x-auto
                        scrollbar-hide
                      "
                    >

                      {Array.from(
                        {
                          length:
                            totalPages,
                        },
                        (_, index) => {

                          const page =
                            index + 1;

                          return (
                            <button
                              key={
                                page
                              }
                              type="button"
                              onClick={() =>
                                changePage(
                                  page
                                )
                              }
                              className={`
                                flex
                                h-10
                                min-w-10
                                shrink-0
                                items-center
                                justify-center
                                rounded-xl
                                px-3
                                text-xs
                                font-semibold
                                transition

                                ${
                                  currentPage ===
                                  page
                                    ? "bg-sky-500 text-white shadow-sm"
                                    : "border border-gray-200 bg-white text-gray-600 hover:border-sky-300 hover:bg-sky-50"
                                }
                              `}
                            >
                              {page}
                            </button>
                          );
                        }
                      )}

                    </div>


                    <button
                      type="button"
                      onClick={() =>
                        changePage(
                          currentPage + 1
                        )
                      }
                      disabled={
                        currentPage ===
                        totalPages
                      }
                      className="
                        flex
                        h-10
                        w-10
                        items-center
                        justify-center
                        rounded-xl
                        border
                        border-gray-200
                        bg-white
                        text-sm
                        text-gray-700
                        shadow-sm
                        transition
                        hover:border-sky-300
                        hover:bg-sky-50
                        hover:text-sky-600
                        disabled:cursor-not-allowed
                        disabled:opacity-40
                      "
                      aria-label="Next page"
                    >
                      <span className="text-lg">
                        →
                      </span>
                    </button>

                  </div>

                </div>
              )}

            </>

          ) : (

            /* ==================================================
               EMPTY STATE
            =================================================== */

            <div
              className="
                rounded-[24px]
                border
                border-dashed
                border-sky-200
                bg-white
                px-5
                py-14
                text-center
                shadow-sm
                sm:py-20
              "
            >

              <div
                className="
                  mx-auto
                  flex
                  h-16
                  w-16
                  items-center
                  justify-center
                  rounded-full
                  bg-sky-50
                  text-2xl
                  text-sky-500
                "
              >
                📰
              </div>

              <h2
                className="
                  mt-4
                  text-xl
                  font-bold
                  text-gray-900
                  sm:text-2xl
                "
              >
                No Blogs Found
              </h2>

              <p
                className="
                  mx-auto
                  mt-2
                  max-w-md
                  text-xs
                  leading-6
                  text-gray-500
                  sm:text-sm
                "
              >
                There are no published blog posts available
                right now. Please check back later.
              </p>

            </div>

          )}

        </section>

      </div>
    </main>
    <Footer/>
    </>
  );
};

export default Blogs;