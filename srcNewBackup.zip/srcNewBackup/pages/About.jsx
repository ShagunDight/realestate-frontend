import React from "react";

import {
  FaHandshake,
  FaAward,
  FaUsers,
  FaCheckCircle,
  FaArrowRight,
} from "react-icons/fa";

import Team from "../components/Team";
import Footer from "../components/Footer";


export default function About() {

  const stats = [
    {
      num: "200+",
      label: "Happy Customers",
    },
    {
      num: "10k+",
      label: "Properties",
    },
    {
      num: "16+",
      label: "Years Experience",
    },
  ];


  const values = [
    {
      title: "Trust",
      desc: "Trust is the cornerstone of every successful real estate transaction.",
      icon: <FaHandshake />,
    },

    {
      title: "Excellence",
      desc: "We set the bar high for ourselves, from properties to services.",
      icon: <FaAward />,
    },

    {
      title: "Client-Centric",
      desc: "Your needs are at the center of everything we do.",
      icon: <FaUsers />,
    },

    {
      title: "Commitment",
      desc: "We provide the highest level of service and professionalism.",
      icon: <FaCheckCircle />,
    },
  ];


  const achievements = [
    {
      title: "3+ Years Growth",
      desc: "Strong industry presence and continuously growing expertise.",
    },

    {
      title: "Happy Clients",
      desc: "Client satisfaction remains one of our biggest achievements.",
    },

    {
      title: "Industry Recognition",
      desc: "Trusted by clients and professionals across the property industry.",
    },
  ];


  const steps = [
    "Discover properties",
    "Shortlist your options",
    "Get expert guidance",
    "Schedule visits",
    "Final evaluation",
    "Close the deal",
  ];


  return (
    <>
      <main
        className="
          min-h-screen
          bg-gradient-to-b
          from-white
          via-white
          to-sky-50
          px-3
          py-6
          sm:px-5
          sm:py-8
          lg:px-8
          lg:py-12
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1380px]
          "
        >

          {/* ==================================================
              HERO / OUR JOURNEY
          =================================================== */}

          <section
            className="
              grid
              grid-cols-1
              items-center
              gap-8
              lg:grid-cols-2
              lg:gap-14
            "
          >

            {/* LEFT */}

            <div className="min-w-0">

              <p
                className="
                  text-[10px]
                  font-bold
                  uppercase
                  tracking-[0.18em]
                  text-sky-500
                  sm:text-xs
                "
              >
                Our Story
              </p>


              <h1
                className="
                  mt-2
                  text-3xl
                  font-extrabold
                  leading-tight
                  tracking-tight
                  text-gray-900
                  sm:text-4xl
                  md:text-5xl
                "
              >
                Our Journey
              </h1>


              <p
                className="
                  mt-4
                  max-w-2xl
                  text-sm
                  leading-7
                  text-gray-600
                  sm:text-base
                "
              >
                Our story is one of continuous growth and
                evolution. We started as a small team with big
                dreams, determined to create a real estate
                platform that transcends the ordinary.
              </p>


              {/* STATS */}

              <div
                className="
                  mt-7
                  grid
                  grid-cols-3
                  gap-2
                  sm:gap-4
                "
              >

                {stats.map(
                  (
                    item,
                    index
                  ) => (
                    <div
                      key={
                        index
                      }
                      className="
                        min-w-0
                        rounded-2xl
                        border
                        border-sky-100
                        bg-white
                        p-3
                        text-center
                        shadow-sm
                        transition
                        hover:-translate-y-1
                        hover:shadow-md
                        sm:p-4
                      "
                    >

                      <h3
                        className="
                          text-xl
                          font-extrabold
                          text-sky-600
                          sm:text-2xl
                        "
                      >
                        {item.num}
                      </h3>

                      <p
                        className="
                          mt-1
                          break-words
                          text-[9px]
                          leading-4
                          text-gray-500
                          sm:text-xs
                        "
                      >
                        {item.label}
                      </p>

                    </div>
                  )
                )}

              </div>

            </div>


            {/* RIGHT IMAGE */}

            <div
              className="
                relative
                min-w-0
              "
            >

              {/* GLOW */}

              <div
                className="
                  pointer-events-none
                  absolute
                  -inset-5
                  rounded-full
                  bg-sky-200/30
                  blur-3xl
                "
              />

              <div
                className="
                  relative
                  overflow-hidden
                  rounded-[24px]
                  border
                  border-sky-100
                  bg-gray-100
                  shadow-2xl
                  sm:rounded-[30px]
                "
              >

                <img
                  src="https://images.unsplash.com/photo-1560518883-ce09059eeffa"
                  alt="Real estate"
                  className="
                    block
                    h-[280px]
                    w-full
                    object-cover
                    sm:h-[380px]
                    md:h-[430px]
                    lg:h-[500px]
                  "
                />

                <div
                  className="
                    absolute
                    inset-x-0
                    bottom-0
                    h-1/3
                    bg-gradient-to-t
                    from-black/40
                    to-transparent
                  "
                />

              </div>

            </div>

          </section>


          {/* ==================================================
              VALUES
          =================================================== */}

          <section
            className="
              mt-16
              sm:mt-20
              lg:mt-24
            "
          >

            <SectionHeading
              eyebrow="Core Values"
              title="Our Values"
              description="The principles that guide how we serve our clients and build long-term relationships."
            />


            <div
              className="
                mt-8
                grid
                grid-cols-1
                gap-3
                sm:grid-cols-2
                sm:gap-5
              "
            >

              {values.map(
                (
                  item,
                  index
                ) => (
                  <div
                    key={
                      index
                    }
                    className="
                      group
                      min-w-0
                      rounded-2xl
                      border
                      border-gray-100
                      bg-white
                      p-5
                      shadow-sm
                      transition-all
                      duration-300
                      hover:-translate-y-1
                      hover:shadow-lg
                      sm:p-6
                    "
                  >

                    <div
                      className="
                        flex
                        items-start
                        gap-4
                      "
                    >

                      <div
                        className="
                          flex
                          h-11
                          w-11
                          shrink-0
                          items-center
                          justify-center
                          rounded-xl
                          bg-sky-50
                          text-sky-500
                          transition
                          group-hover:bg-sky-500
                          group-hover:text-white
                        "
                      >
                        {item.icon}
                      </div>


                      <div
                        className="
                          min-w-0
                        "
                      >

                        <h3
                          className="
                            text-base
                            font-bold
                            text-gray-900
                            sm:text-lg
                          "
                        >
                          {item.title}
                        </h3>

                        <p
                          className="
                            mt-1.5
                            break-words
                            text-xs
                            leading-6
                            text-gray-500
                            sm:text-sm
                          "
                        >
                          {item.desc}
                        </p>

                      </div>

                    </div>

                  </div>
                )
              )}

            </div>

          </section>


          {/* ==================================================
              ACHIEVEMENTS
          =================================================== */}

          <section
            className="
              mt-16
              sm:mt-20
              lg:mt-24
            "
          >

            <SectionHeading
              eyebrow="Milestones"
              title="Our Achievements"
              description="A few milestones that reflect the trust and growth we've built over time."
            />


            <div
              className="
                mt-8
                grid
                grid-cols-1
                gap-3
                sm:grid-cols-3
                sm:gap-5
              "
            >

              {achievements.map(
                (
                  item,
                  index
                ) => (
                  <div
                    key={
                      index
                    }
                    className="
                      relative
                      overflow-hidden
                      rounded-2xl
                      border
                      border-gray-100
                      bg-white
                      p-5
                      shadow-sm
                      transition
                      hover:-translate-y-1
                      hover:shadow-lg
                      sm:p-6
                    "
                  >

                    <div
                      className="
                        absolute
                        right-0
                        top-0
                        h-20
                        w-20
                        rounded-full
                        bg-sky-50
                        blur-2xl
                      "
                    />

                    <div
                      className="
                        relative
                      "
                    >

                      <p
                        className="
                          text-[10px]
                          font-bold
                          uppercase
                          tracking-[0.15em]
                          text-sky-500
                        "
                      >
                        0{index + 1}
                      </p>

                      <h3
                        className="
                          mt-3
                          text-base
                          font-bold
                          text-gray-900
                          sm:text-lg
                        "
                      >
                        {item.title}
                      </h3>

                      <p
                        className="
                          mt-2
                          text-xs
                          leading-6
                          text-gray-500
                          sm:text-sm
                        "
                      >
                        {item.desc}
                      </p>

                    </div>

                  </div>
                )
              )}

            </div>

          </section>


          {/* ==================================================
              PROCESS
          =================================================== */}

          <section
            className="
              mt-16
              pb-6
              sm:mt-20
              lg:mt-24
            "
          >

            <SectionHeading
              eyebrow="Our Process"
              title="Navigating the Estatein Experience"
              description="A simple and guided process designed to make your property journey easier."
            />


            <div
              className="
                mt-8
                grid
                grid-cols-1
                gap-3
                sm:grid-cols-2
                sm:gap-5
                lg:grid-cols-3
              "
            >

              {steps.map(
                (
                  title,
                  index
                ) => (
                  <div
                    key={
                      index
                    }
                    className="
                      group
                      relative
                      overflow-hidden
                      rounded-2xl
                      border
                      border-gray-100
                      bg-white
                      p-5
                      shadow-sm
                      transition-all
                      duration-300
                      hover:-translate-y-1
                      hover:shadow-lg
                      sm:p-6
                    "
                  >

                    {/* NUMBER */}

                    <div
                      className="
                        flex
                        h-10
                        w-10
                        items-center
                        justify-center
                        rounded-xl
                        bg-sky-50
                        text-xs
                        font-bold
                        text-sky-600
                        transition
                        group-hover:bg-sky-500
                        group-hover:text-white
                      "
                    >
                      {String(
                        index + 1
                      ).padStart(
                        2,
                        "0"
                      )}
                    </div>


                    {/* CONTENT */}

                    <h3
                      className="
                        mt-5
                        text-base
                        font-bold
                        text-gray-900
                        sm:text-lg
                      "
                    >
                      {title}
                    </h3>


                    <p
                      className="
                        mt-2
                        text-xs
                        leading-6
                        text-gray-500
                        sm:text-sm
                      "
                    >
                      Smooth and guided steps to help
                      you move confidently toward the
                      right property decision.
                    </p>


                    {/* ARROW */}

                    <div
                      className="
                        mt-5
                        flex
                        items-center
                        gap-1.5
                        text-xs
                        font-semibold
                        text-sky-500
                      "
                    >
                      Learn more

                      <FaArrowRight
                        className="
                          text-[10px]
                          transition
                          group-hover:translate-x-1
                        "
                      />
                    </div>

                  </div>
                )
              )}

            </div>

          </section>

        </div>

      </main>


      {/* ==================================================
          TEAM
      =================================================== */}

      <Team />


      {/* ==================================================
          FOOTER
      =================================================== */}

      <Footer />
    </>
  );
}


/*
|--------------------------------------------------------------------------
| SECTION HEADING
|--------------------------------------------------------------------------
*/

const SectionHeading = ({
  eyebrow,
  title,
  description,
}) => {

  return (
    <div
      className="
        mx-auto
        max-w-2xl
        text-center
      "
    >

      <p
        className="
          text-[10px]
          font-bold
          uppercase
          tracking-[0.18em]
          text-sky-500
          sm:text-xs
        "
      >
        {eyebrow}
      </p>


      <h2
        className="
          mt-2
          break-words
          text-2xl
          font-bold
          text-gray-900
          sm:text-3xl
          md:text-4xl
        "
      >
        {title}
      </h2>


      {description && (
        <p
          className="
            mt-3
            text-xs
            leading-6
            text-gray-500
            sm:text-sm
          "
        >
          {description}
        </p>
      )}

    </div>
  );
};
