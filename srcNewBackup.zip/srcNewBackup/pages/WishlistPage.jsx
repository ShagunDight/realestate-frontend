import React, {
  useEffect,
} from "react";

import {
  Link,
  useNavigate,
} from "react-router-dom";

import {
  FaHeart,
} from "react-icons/fa";

import {
  useWishlist,
} from "../components/WishlistContext";

import PropertyCard from "../components/PropertyCard";
import Footer from "../components/Footer";


const WishlistPage = () => {

  const {
    wishlist = [],
  } = useWishlist();

  const navigate =
    useNavigate();


  /*
  |--------------------------------------------------------------------------
  | LOGIN CHECK
  |--------------------------------------------------------------------------
  */

  const isLoggedIn =
    !!localStorage.getItem(
      "customer_token"
    );


  /*
  |--------------------------------------------------------------------------
  | REDIRECT IF NOT LOGGED IN
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    if (!isLoggedIn) {

      navigate(
        "/",
        {
          replace: true,
        }
      );

    }

  }, [
    isLoggedIn,
    navigate,
  ]);


  if (!isLoggedIn) {
    return null;
  }


  return (
    <>
      <main
        className="
          min-h-screen
          bg-[#f6f9ff]
          px-3
          py-5
          sm:px-5
          sm:py-7
          lg:px-8
          lg:py-10
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1380px]
          "
        >

          {/* ==================================================
              HEADER
          =================================================== */}

          <section
            className="
              relative
              overflow-hidden
              rounded-[26px]
              border
              border-sky-100
              bg-white
              p-5
              shadow-sm
              sm:p-7
              lg:p-8
            "
          >

            {/* SOFT BACKGROUND */}

            <div
              className="
                pointer-events-none
                absolute
                -right-20
                -top-20
                h-40
                w-40
                rounded-full
                bg-sky-100/60
                blur-3xl
                sm:h-56
                sm:w-56
              "
            />


            <div
              className="
                relative
                flex
                flex-col
                gap-5
                sm:flex-row
                sm:items-center
                sm:justify-between
              "
            >

              <div className="min-w-0">

                {/* EYEBROW */}

                <div
                  className="
                    flex
                    items-center
                    gap-2
                  "
                >

                  <div
                    className="
                      flex
                      h-8
                      w-8
                      items-center
                      justify-center
                      rounded-xl
                      bg-red-50
                      text-red-500
                    "
                  >
                    <FaHeart
                      size={13}
                    />
                  </div>

                  <p
                    className="
                      text-[10px]
                      font-bold
                      uppercase
                      tracking-[0.16em]
                      text-sky-500
                      sm:text-xs
                    "
                  >
                    Saved Properties
                  </p>

                </div>


                {/* TITLE */}

                <h1
                  className="
                    mt-3
                    break-words
                    text-2xl
                    font-extrabold
                    tracking-tight
                    text-gray-900
                    sm:text-3xl
                    lg:text-4xl
                  "
                >
                  My Wishlist
                </h1>


                {/* DESCRIPTION */}

                <p
                  className="
                    mt-2
                    max-w-2xl
                    text-xs
                    leading-6
                    text-gray-500
                    sm:text-sm
                  "
                >
                  Your favorite properties are saved here.
                  Revisit them anytime and explore the details
                  when you're ready.
                </p>

              </div>


              {/* COUNT */}

              <div
                className="
                  flex
                  w-fit
                  shrink-0
                  items-center
                  gap-3
                  rounded-2xl
                  border
                  border-sky-100
                  bg-sky-50
                  px-4
                  py-3
                "
              >

                <div
                  className="
                    text-right
                  "
                >
                  <p
                    className="
                      text-[10px]
                      font-medium
                      uppercase
                      tracking-wide
                      text-gray-400
                    "
                  >
                    Total Saved
                  </p>

                  <p
                    className="
                      mt-0.5
                      text-2xl
                      font-extrabold
                      leading-none
                      text-sky-600
                    "
                  >
                    {wishlist.length}
                  </p>
                </div>


                <div
                  className="
                    flex
                    h-10
                    w-10
                    items-center
                    justify-center
                    rounded-xl
                    bg-white
                    text-red-500
                    shadow-sm
                  "
                >
                  <FaHeart
                    size={14}
                  />
                </div>

              </div>

            </div>

          </section>


          {/* ==================================================
              CONTENT
          =================================================== */}

          {wishlist.length === 0 ? (

            /* =================================================
               EMPTY STATE
            ================================================== */

            <section
              className="
                mt-5
                rounded-[26px]
                border
                border-dashed
                border-sky-200
                bg-white
                px-5
                py-14
                text-center
                shadow-sm
                sm:mt-6
                sm:px-8
                sm:py-20
              "
            >

              {/* ICON */}

              <div
                className="
                  mx-auto
                  flex
                  h-20
                  w-20
                  items-center
                  justify-center
                  rounded-full
                  bg-sky-50
                  text-3xl
                  text-sky-500
                "
              >
                🏠
              </div>


              <h2
                className="
                  mt-5
                  text-xl
                  font-bold
                  text-gray-900
                  sm:text-2xl
                "
              >
                Your Wishlist is Empty
              </h2>


              <p
                className="
                  mx-auto
                  mt-2
                  max-w-md
                  text-xs
                  leading-6
                  text-gray-500
                  sm:text-sm
                "
              >
                Save properties you love by tapping the
                heart icon. They'll appear here for easy
                access later.
              </p>


              <Link
                to="/properties"
                className="
                  mt-6
                  inline-flex
                  min-h-[46px]
                  items-center
                  justify-center
                  rounded-xl
                  bg-sky-500
                  px-6
                  py-3
                  text-sm
                  font-semibold
                  text-white
                  shadow-md
                  shadow-sky-500/20
                  transition
                  hover:bg-sky-600
                  active:scale-[0.98]
                "
              >
                Explore Properties
                <span className="ml-2">
                  →
                </span>
              </Link>

            </section>

          ) : (

            <>
              {/* =================================================
                  LIST HEADER
              ================================================== */}

              <div
                className="
                  mt-6
                  flex
                  flex-col
                  gap-2
                  sm:flex-row
                  sm:items-center
                  sm:justify-between
                "
              >

                <div>

                  <p
                    className="
                      text-sm
                      font-semibold
                      text-gray-900
                    "
                  >
                    Your Saved Properties
                  </p>

                  <p
                    className="
                      mt-0.5
                      text-xs
                      text-gray-500
                    "
                  >
                    {wishlist.length}{" "}
                    {wishlist.length ===
                    1
                      ? "property"
                      : "properties"}{" "}
                    saved in your wishlist.
                  </p>

                </div>


                <Link
                  to="/properties"
                  className="
                    w-fit
                    rounded-xl
                    border
                    border-sky-200
                    bg-white
                    px-4
                    py-2.5
                    text-xs
                    font-semibold
                    text-sky-600
                    transition
                    hover:border-sky-400
                    hover:bg-sky-50
                  "
                >
                  Find More Properties
                </Link>

              </div>


              {/* =================================================
                  GRID
              ================================================== */}

              <section
                className="
                  mt-4
                  grid
                  grid-cols-1
                  gap-4
                  sm:grid-cols-2
                  sm:gap-5
                  xl:grid-cols-3
                  xl:gap-6
                "
              >

                {wishlist.map(
                  (
                    property,
                    index
                  ) => (

                    <div
                      key={
                        property?._id ||
                        property?.id ||
                        index
                      }
                      className="
                        min-w-0
                      "
                    >

                      <PropertyCard
                        item={
                          property
                        }
                      />

                    </div>

                  )
                )}

              </section>

            </>
          )}

        </div>

      </main>


      <Footer />
    </>
  );
};


export default WishlistPage;
