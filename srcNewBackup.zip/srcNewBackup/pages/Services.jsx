import React, {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  FaArrowRight,
  FaBuilding,
  FaChartBar,
  FaChartLine,
  FaCogs,
  FaDraftingCompass,
  FaFileAlt,
  FaHandshake,
  FaHome,
  FaLightbulb,
  FaPercentage,
  FaCheck,
  FaChevronRight,
} from "react-icons/fa";

import { useNavigate } from "react-router-dom";

import Footer from "../components/Footer";
import FAQ from "../components/FAQ";

const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";

const ServicesPage = () => {
  const navigate = useNavigate();

  const [services, setServices] = useState({});
  const [services1, setServices1] = useState([]);
  const [loading, setLoading] = useState(true);

  /*
  |--------------------------------------------------------------------------
  | FETCH SERVICES
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    const loadServices = async () => {
      try {
        setLoading(true);

        const [servicesRes, moreServicesRes] =
          await Promise.all([
            fetch(`${API_BASE}/api/services`),
            fetch(`${API_BASE}/api/moreservices`),
          ]);

        if (!servicesRes.ok || !moreServicesRes.ok) {
          throw new Error("Unable to fetch services");
        }

        const servicesData = await servicesRes.json();
        const moreServicesData = await moreServicesRes.json();

        setServices(servicesData?.data || {});
        setServices1(
          Array.isArray(moreServicesData?.data)
            ? moreServicesData.data
            : []
        );
      } catch (error) {
        console.error("Services Error:", error);
        setServices({});
        setServices1([]);
      } finally {
        setLoading(false);
      }
    };

    loadServices();
  }, []);

  /*
  |--------------------------------------------------------------------------
  | HELPERS
  |--------------------------------------------------------------------------
  */

  const parseFeatures = (features) => {
    if (!features) return [];

    if (Array.isArray(features)) {
      return features;
    }

    try {
      const parsed = JSON.parse(features);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  };

  const iconMap = {
    FaHome,
    FaBuilding,
    FaChartLine,
    FaCogs,
    FaLightbulb,
    FaChartBar,
    FaPercentage,
    FaDraftingCompass,
    FaFileAlt,
    FaHandshake,
  };

  const getServiceIcon = (title = "") => {
    const value = title.toLowerCase();

    if (
      value.includes("buy") ||
      value.includes("sell") ||
      value.includes("home") ||
      value.includes("residential")
    ) {
      return <FaHome />;
    }

    if (
      value.includes("invest") ||
      value.includes("market") ||
      value.includes("advis")
    ) {
      return <FaChartLine />;
    }

    if (
      value.includes("manage") ||
      value.includes("management")
    ) {
      return <FaCogs />;
    }

    if (
      value.includes("valuation") ||
      value.includes("value")
    ) {
      return <FaChartBar />;
    }

    if (
      value.includes("design") ||
      value.includes("plan") ||
      value.includes("architect")
    ) {
      return <FaDraftingCompass />;
    }

    if (
      value.includes("legal") ||
      value.includes("document")
    ) {
      return <FaFileAlt />;
    }

    return <FaBuilding />;
  };

  /*
  |--------------------------------------------------------------------------
  | FEATURED SERVICES
  |--------------------------------------------------------------------------
  */

  const featuredServices = useMemo(() => {
    return services1.slice(0, 4);
  }, [services1]);

  /*
  |--------------------------------------------------------------------------
  | LOADING
  |--------------------------------------------------------------------------
  */

  if (loading) {
    return (
      <main className="min-h-screen bg-[#f7fbff] px-3 py-6 sm:px-5 sm:py-8 lg:px-8 lg:py-12">
        <div className="mx-auto w-full max-w-[1380px]">
          <div className="rounded-[30px] bg-white px-5 py-10 shadow-sm sm:px-8 sm:py-14">
            <div className="h-3 w-28 animate-pulse rounded-full bg-sky-100" />

            <div className="mt-5 h-12 w-full max-w-2xl animate-pulse rounded-xl bg-gray-100" />

            <div className="mt-4 h-4 w-full max-w-3xl animate-pulse rounded bg-gray-100" />
          </div>

          <div className="mt-6 space-y-4">
            {Array.from({ length: 5 }, (_, index) => (
              <div
                key={index}
                className="h-40 animate-pulse rounded-[24px] bg-white shadow-sm"
              />
            ))}
          </div>
        </div>
      </main>
    );
  }

  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <>
      <main className="min-h-screen overflow-hidden bg-white">

        {/* ==================================================
            HERO
        =================================================== */}

        <section className="relative overflow-hidden bg-[#f5faff] px-3 pb-12 pt-8 sm:px-5 sm:pb-16 sm:pt-10 lg:px-8 lg:pb-20 lg:pt-16">
          <div className="pointer-events-none absolute -left-20 top-0 h-64 w-64 rounded-full bg-sky-200/40 blur-3xl" />
          <div className="pointer-events-none absolute -right-20 top-10 h-72 w-72 rounded-full bg-cyan-100/50 blur-3xl" />

          <div className="relative mx-auto grid w-full max-w-[1380px] grid-cols-1 items-end gap-8 lg:grid-cols-[minmax(0,1fr)_300px] lg:gap-12">
            
            <div className="max-w-4xl">
              <div className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-sky-300" />
                <span className="h-2.5 w-2.5 rounded-full bg-sky-500" />
                <span className="h-1.5 w-1.5 rounded-full bg-sky-300" />
              </div>

              <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.2em] text-sky-500 sm:text-xs">
                What We Do
              </p>

              <h1 className="mt-2 break-words text-3xl font-extrabold leading-[1.08] tracking-tight text-gray-900 sm:text-4xl md:text-5xl lg:text-6xl">
                Real Estate
                <span className="text-sky-500"> Services</span>
                <br />
                Built Around You
              </h1>

              <p className="mt-5 max-w-3xl text-sm leading-7 text-gray-600 sm:text-base sm:leading-8">
                From finding the right property to evaluating opportunities,
                planning spaces, managing assets and making smarter investments,
                our services are designed around the way you move through real estate.
              </p>
            </div>

            <div className="hidden lg:block">
              <div className="border-l border-sky-200 pl-6">
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-gray-400">
                  Our Approach
                </p>

                <p className="mt-2 text-sm font-medium leading-6 text-gray-700">
                  Expert guidance.
                  <br />
                  Better decisions.
                  <br />
                  Long-term value.
                </p>

                <button
                  type="button"
                  onClick={() => navigate("/contact")}
                  className="mt-5 inline-flex items-center gap-2 text-xs font-semibold text-sky-500 transition hover:text-sky-600"
                >
                  Talk to our team
                  <FaArrowRight className="text-[9px]" />
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* ==================================================
            QUICK SERVICE STRIP
        =================================================== */}

        <section className="relative z-10 bg-[#f5faff] px-3 pb-6 sm:px-5 sm:pb-8 lg:px-8 lg:pb-10">
          <div className="mx-auto grid w-full max-w-[1380px] grid-cols-2 overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm sm:grid-cols-4">
            {[
              { icon: <FaHome />, title: "Buy & Sell" },
              { icon: <FaChartLine />, title: "Investment" },
              { icon: <FaBuilding />, title: "Valuation" },
              { icon: <FaCogs />, title: "Management" },
            ].map((item, index) => (
              <div
                key={index}
                className="flex min-w-0 items-center gap-3 border-b border-gray-100 px-4 py-4 even:border-l sm:border-b-0 sm:border-r sm:px-5 sm:py-5 sm:last:border-r-0"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sky-50 text-sky-500 sm:h-10 sm:w-10">
                  {item.icon}
                </div>

                <p className="min-w-0 truncate text-xs font-semibold text-gray-800 sm:text-sm">
                  {item.title}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* ==================================================
            CORE SERVICES - EDITORIAL
        =================================================== */}

        <section className="px-3 py-12 sm:px-5 sm:py-16 lg:px-8 lg:py-20">
          <div className="mx-auto w-full max-w-[1380px]">
            
            <div className="max-w-3xl">
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-sky-500 sm:text-xs">
                Core Services
              </p>

              <h2 className="mt-2 text-2xl font-bold leading-tight text-gray-900 sm:text-3xl md:text-4xl">
                Everything You Need
                <span className="text-sky-500"> Under One Roof</span>
              </h2>

              <p className="mt-3 text-xs leading-6 text-gray-500 sm:text-sm sm:leading-7">
                Professional solutions that simplify property decisions,
                reduce complexity and help you move forward with confidence.
              </p>
            </div>

            <div className="mt-8 divide-y divide-gray-200 border-y border-gray-200">
              {services1.length > 0 ? (
                services1.map((item, index) => {
                  const Icon = iconMap[item?.icon];
                  const features = parseFeatures(item?.features);

                  return (
                    <article
                      key={item?.id || item?._id || index}
                      className="group grid grid-cols-1 gap-5 py-7 sm:py-8 lg:grid-cols-[70px_minmax(0,1fr)_auto] lg:items-start lg:gap-7"
                    >
                      <div className="flex items-center gap-3 lg:block">
                        <span className="text-xs font-bold tracking-[0.15em] text-gray-300">
                          {String(index + 1).padStart(2, "0")}
                        </span>

                        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sky-50 text-lg text-sky-500 transition group-hover:bg-sky-500 group-hover:text-white lg:mt-5">
                          {Icon ? (
                            <Icon />
                          ) : item?.icon ? (
                            <img
                              src={`${API_BASE}/public${item.icon}`}
                              alt=""
                              className="h-6 w-6 object-contain"
                            />
                          ) : (
                            <FaBuilding />
                          )}
                        </div>
                      </div>

                      <div className="min-w-0">
                        <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-sky-500">
                          Property Service
                        </p>

                        <h3 className="mt-1 break-words text-xl font-bold text-gray-900 transition group-hover:text-sky-600 sm:text-2xl">
                          {item?.title || "Real Estate Service"}
                        </h3>

                        <p className="mt-3 max-w-3xl break-words text-xs leading-6 text-gray-500 sm:text-sm sm:leading-7">
                          {item?.description ||
                            "Professional real estate solutions tailored to your requirements."}
                        </p>

                        {features.length > 0 && (
                          <div className="mt-5 flex flex-wrap gap-x-5 gap-y-2">
                            {features.map((feature, featureIndex) => (
                              <div
                                key={featureIndex}
                                className="flex items-start gap-2 text-xs text-gray-600 sm:text-sm"
                              >
                                <FaCheck className="mt-1 shrink-0 text-[9px] text-sky-500" />
                                <span className="break-words">{feature}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => navigate("/contact")}
                        className="inline-flex w-fit items-center gap-2 self-start text-xs font-semibold text-sky-500 transition hover:text-sky-600 sm:text-sm"
                      >
                        Talk to an Expert
                        <FaArrowRight className="text-[9px] transition group-hover:translate-x-1" />
                      </button>
                    </article>
                  );
                })
              ) : (
                <div className="py-12 text-center text-sm text-gray-400">
                  No services available.
                </div>
              )}
            </div>
          </div>
        </section>

        {/* ==================================================
            FEATURED SERVICE CARDS
        =================================================== */}

        {featuredServices.length > 0 && (
          <section className="bg-[#f7fbff] px-3 py-12 sm:px-5 sm:py-16 lg:px-8 lg:py-20">
            <div className="mx-auto w-full max-w-[1380px]">
              
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div className="max-w-3xl">
                  <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-sky-500 sm:text-xs">
                    Featured Services
                  </p>

                  <h2 className="mt-2 text-2xl font-bold text-gray-900 sm:text-3xl md:text-4xl">
                    A Closer Look at What We Offer
                  </h2>
                </div>

                <button
                  type="button"
                  onClick={() => navigate("/contact")}
                  className="inline-flex w-fit items-center gap-2 text-xs font-semibold text-sky-500 sm:text-sm"
                >
                  Contact Us
                  <FaArrowRight className="text-[9px]" />
                </button>
              </div>

              <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {featuredServices.map((item, index) => {
                  const features = parseFeatures(item?.features);

                  return (
                    <article
                      key={item?.id || item?._id || index}
                      className="group relative min-w-0 overflow-hidden rounded-[24px] border border-gray-100 bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl sm:p-6"
                    >
                      <div className="absolute right-0 top-0 h-28 w-28 rounded-full bg-sky-100/60 blur-3xl" />

                      <div className="relative z-10">
                        <div className="flex items-center justify-between">
                          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-50 text-xl text-sky-500 transition group-hover:bg-sky-500 group-hover:text-white">
                            {getServiceIcon(item?.title)}
                          </div>

                          <span className="text-xs font-bold text-gray-300">
                            0{index + 1}
                          </span>
                        </div>

                        <h3 className="mt-5 break-words text-lg font-bold text-gray-900">
                          {item?.title || "Service"}
                        </h3>

                        <p className="mt-2 line-clamp-4 break-words text-xs leading-6 text-gray-500 sm:text-sm">
                          {item?.description ||
                            "Professional real estate service tailored to your requirements."}
                        </p>

                        {features.length > 0 && (
                          <div className="mt-5 space-y-2">
                            {features.slice(0, 3).map(
                              (feature, featureIndex) => (
                                <div
                                  key={featureIndex}
                                  className="flex items-start gap-2 text-xs text-gray-600"
                                >
                                  <FaCheck className="mt-1 shrink-0 text-[8px] text-sky-500" />
                                  <span className="break-words">{feature}</span>
                                </div>
                              )
                            )}
                          </div>
                        )}

                        <button
                          type="button"
                          onClick={() => navigate("/contact")}
                          className="mt-6 inline-flex items-center gap-2 text-xs font-semibold text-sky-500"
                        >
                          Explore
                          <FaChevronRight className="text-[8px] transition group-hover:translate-x-1" />
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            </div>
          </section>
        )}

        {/* ==================================================
            ADDITIONAL SERVICES
        =================================================== */}

        {Object.entries(services).map(
          ([sectionName, sectionItems], sectionIndex) => {
            if (
              !Array.isArray(sectionItems) ||
              sectionItems.length === 0
            ) {
              return null;
            }

            return (
              <section
                key={sectionIndex}
                className="border-t border-gray-100 px-3 py-12 sm:px-5 sm:py-16 lg:px-8 lg:py-20"
              >
                <div className="mx-auto w-full max-w-[1380px]">
                  
                  <div className="max-w-3xl">
                    <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-sky-500 sm:text-xs">
                      More Solutions
                    </p>

                    <h2 className="mt-2 break-words text-2xl font-bold text-gray-900 sm:text-3xl">
                      {sectionName}
                    </h2>

                    <p className="mt-3 text-xs leading-6 text-gray-500 sm:text-sm">
                      Additional solutions designed to support your property journey.
                    </p>
                  </div>

                  <div className="mt-7 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
                    {sectionItems.map((item, index) => {
                      const Icon = iconMap[item?.icon];

                      return (
                        <article
                          key={item?.id || item?._id || index}
                          className="group flex min-w-0 gap-4 border-b border-gray-200 py-5 sm:px-3 sm:first:pl-0 lg:border-r lg:px-5 lg:first:pl-0 lg:[&:nth-child(4n)]:border-r-0"
                        >
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-50 text-sky-500 transition group-hover:bg-sky-500 group-hover:text-white">
                            {Icon ? (
                              <Icon />
                            ) : item?.icon ? (
                              <img
                                src={`${API_BASE}/public${item.icon}`}
                                alt=""
                                className="h-5 w-5 object-contain"
                              />
                            ) : (
                              <FaBuilding />
                            )}
                          </div>

                          <div className="min-w-0">
                            <h3 className="break-words text-sm font-bold text-gray-900">
                              {item?.title || "Service"}
                            </h3>

                            <p className="mt-1.5 line-clamp-3 break-words text-xs leading-5 text-gray-500">
                              {item?.description ||
                                "Professional service for your real estate requirements."}
                            </p>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </div>
              </section>
            );
          }
        )}

        {/* ==================================================
            WHY ESTATEIN
        =================================================== */}

        <section className="border-t border-gray-100 bg-[#f7fbff] px-3 py-12 sm:px-5 sm:py-16 lg:px-8 lg:py-20">
          <div className="mx-auto grid w-full max-w-[1380px] grid-cols-1 items-center gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-14">
            
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-sky-500 sm:text-xs">
                Why Estatein
              </p>

              <h2 className="mt-2 max-w-xl text-2xl font-bold leading-tight text-gray-900 sm:text-3xl md:text-4xl">
                More Than a Service.
                <span className="text-sky-500">
                  {" "}A Long-Term Partner.
                </span>
              </h2>

              <p className="mt-4 max-w-xl text-xs leading-7 text-gray-500 sm:text-sm">
                Real estate decisions can be complex. Our goal is to make them
                easier through professional guidance, transparent processes and
                practical market insight.
              </p>

              <button
                type="button"
                onClick={() => navigate("/contact")}
                className="mt-6 inline-flex items-center gap-2 rounded-xl bg-gray-900 px-5 py-3 text-xs font-semibold text-white transition hover:bg-gray-800 sm:text-sm"
              >
                Speak With Our Team
                <FaArrowRight className="text-[9px]" />
              </button>
            </div>

            <div className="divide-y divide-gray-200 border-y border-gray-200">
              {[
                {
                  title: "Transparent Advice",
                  desc: "Clear recommendations without unnecessary complexity.",
                },
                {
                  title: "Market Knowledge",
                  desc: "Practical insights that support better property decisions.",
                },
                {
                  title: "End-to-End Support",
                  desc: "From discovery to final execution, we're there with you.",
                },
                {
                  title: "Long-Term Value",
                  desc: "Our focus extends beyond one transaction.",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className="grid grid-cols-[36px_minmax(0,1fr)] gap-4 py-5"
                >
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-sky-50 text-[10px] font-bold text-sky-600">
                    {String(index + 1).padStart(2, "0")}
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-gray-900 sm:text-base">
                      {item.title}
                    </h3>

                    <p className="mt-1 text-xs leading-6 text-gray-500 sm:text-sm">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </section>

        {/* ==================================================
            FAQ
        =================================================== */}

        <section className="border-t border-gray-100 bg-white">
          <FAQ />
        </section>

        {/* ==================================================
            CTA
        =================================================== */}

        <section className="px-3 py-10 sm:px-5 sm:py-14 lg:px-8 lg:py-20">
          <div className="relative mx-auto w-full max-w-[1380px] overflow-hidden rounded-[28px] bg-gray-900 px-5 py-8 sm:px-8 sm:py-10 lg:px-12 lg:py-14">
            
            <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-sky-500/20 blur-3xl" />

            <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
              
              <div className="max-w-2xl">
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-sky-400 sm:text-xs">
                  Let's Talk
                </p>

                <h2 className="mt-2 text-2xl font-bold leading-tight text-white sm:text-3xl md:text-4xl">
                  Have a Property Goal in Mind?
                </h2>

                <p className="mt-3 text-xs leading-6 text-gray-400 sm:text-sm">
                  Tell us what you're looking for and let our team help you find
                  the right path forward.
                </p>
              </div>

              <button
                type="button"
                onClick={() => navigate("/contact")}
                className="inline-flex min-h-[48px] w-full items-center justify-center rounded-xl bg-sky-500 px-6 py-3 text-sm font-semibold text-white transition hover:bg-sky-600 sm:w-fit"
              >
                Get Started
                <FaArrowRight className="ml-2 text-[9px]" />
              </button>

            </div>
          </div>
        </section>

      </main>

      <Footer />
    </>
  );
};

export default ServicesPage;