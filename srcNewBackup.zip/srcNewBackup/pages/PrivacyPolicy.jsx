import React from "react";
import Footer from "../components/Footer";

const PrivacyPolicy = () => {
  const sections = [
    {
      number: "01",
      title: "Information We Collect",
      content:
        "We collect personal information such as name, email address, phone number, and property preferences when you use our website, submit forms, or contact us.",
    },
    {
      number: "02",
      title: "How We Use Your Information",
      content:
        "Your data is used to provide better property recommendations, respond to inquiries, improve user experience, and send important updates related to our services.",
    },
    {
      number: "03",
      title: "Data Protection",
      content:
        "We implement strict security measures to protect your personal information from unauthorized access, alteration, or disclosure.",
    },
    {
      number: "04",
      title: "Cookies Policy",
      content:
        "We use cookies to improve website performance, track user behavior, and personalize your experience. You can disable cookies in your browser settings.",
    },
    {
      number: "05",
      title: "Third-Party Services",
      content:
        "We may use trusted third-party services for analytics, payments, and marketing. These providers follow strict privacy standards.",
    },
    {
      number: "06",
      title: "Your Rights",
      content:
        "You have the right to access, update, or delete your personal data at any time by contacting our support team.",
    },
    {
      number: "07",
      title: "Changes to This Policy",
      content:
        "We may update this Privacy Policy from time to time. All changes will be posted on this page.",
    },
  ];

  return (
    <>
      <main className="min-h-screen bg-[#f7fbff]">
        {/* ==================================================
            HERO
        =================================================== */}

        <section className="relative overflow-hidden bg-gradient-to-b from-sky-50 via-white to-white px-3 py-8 sm:px-5 sm:py-10 lg:px-8 lg:py-14">
          {/* Decorative glow */}
          <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-sky-100/70 blur-3xl" />

          <div className="relative mx-auto w-full max-w-[1200px]">
            <div className="max-w-3xl">
              <div className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-sky-300" />
                <span className="h-2.5 w-2.5 rounded-full bg-sky-500" />
                <span className="h-1.5 w-1.5 rounded-full bg-sky-300" />
              </div>

              <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.18em] text-sky-500 sm:text-xs">
                Legal & Privacy
              </p>

              <h1 className="mt-2 break-words text-3xl font-extrabold leading-tight tracking-tight text-gray-900 sm:text-4xl md:text-5xl">
                Privacy Policy
              </h1>

              <p className="mt-4 max-w-2xl text-xs leading-6 text-gray-600 sm:text-sm sm:leading-7">
                Your privacy is important to us. This policy explains
                how we collect, use, and protect your information.
              </p>
            </div>
          </div>
        </section>

        {/* ==================================================
            CONTENT
        =================================================== */}

        <section className="px-3 py-6 sm:px-5 sm:py-8 lg:px-8 lg:py-10">
          <div className="mx-auto grid w-full max-w-[1200px] grid-cols-1 gap-6 lg:grid-cols-[220px_minmax(0,1fr)]">
            {/* SIDE SUMMARY */}

            <aside className="hidden lg:block">
              <div className="sticky top-24 rounded-2xl border border-sky-100 bg-white p-5 shadow-sm">
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-sky-500">
                  On This Page
                </p>

                <div className="mt-4 space-y-2">
                  {sections.map((section) => (
                    <div
                      key={section.number}
                      className="flex items-start gap-2"
                    >
                      <span className="text-[10px] font-bold text-sky-500">
                        {section.number}
                      </span>

                      <span className="text-xs leading-5 text-gray-500">
                        {section.title}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </aside>

            {/* POLICY CONTENT */}

            <div className="min-w-0">
              <div className="overflow-hidden rounded-[26px] border border-gray-100 bg-white shadow-sm">
                {sections.map((section, index) => (
                  <article
                    key={section.number}
                    className={`p-5 sm:p-7 ${
                      index !== sections.length - 1
                        ? "border-b border-gray-100"
                        : ""
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      {/* NUMBER */}

                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-50 text-[10px] font-bold text-sky-600 sm:h-11 sm:w-11">
                        {section.number}
                      </div>

                      {/* CONTENT */}

                      <div className="min-w-0">
                        <h2 className="break-words text-base font-bold text-gray-900 sm:text-lg">
                          {section.title}
                        </h2>

                        <p className="mt-2 break-words text-xs leading-6 text-gray-600 sm:text-sm sm:leading-7">
                          {section.content}
                        </p>
                      </div>
                    </div>
                  </article>
                ))}

                {/* LAST UPDATED */}

                <div className="border-t border-gray-100 bg-gray-50 px-5 py-4 sm:px-7">
                  <p className="text-center text-[10px] text-gray-400 sm:text-xs">
                    Last updated: June 2026
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default PrivacyPolicy;