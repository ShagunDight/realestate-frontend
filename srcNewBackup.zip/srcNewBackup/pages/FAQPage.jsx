import React, {
  useEffect,
  useState,
} from "react";

import Footer from "../components/Footer";

import {
  FaChevronDown,
  FaQuestionCircle,
} from "react-icons/fa";


const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";


const FAQPage = () => {

  const [
    faqs,
    setFaqs,
  ] = useState([]);

  const [
    openIndex,
    setOpenIndex,
  ] = useState(null);

  const [
    loading,
    setLoading,
  ] = useState(true);


  /*
  |--------------------------------------------------------------------------
  | FETCH FAQS
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    const fetchFAQs =
      async () => {

        try {

          setLoading(true);

          const response =
            await fetch(
              `${API_BASE}/api/faqs`
            );

          if (!response.ok) {
            throw new Error(
              "Failed to fetch FAQs"
            );
          }

          const data =
            await response.json();

          const result =
            Array.isArray(
              data?.data
            )
              ? data.data
              : Array.isArray(
                  data
                )
              ? data
              : [];

          setFaqs(result);

        } catch (error) {

          console.error(
            "FAQ Error:",
            error
          );

          setFaqs([]);

        } finally {

          setLoading(false);

        }
      };

    fetchFAQs();

  }, []);


  /*
  |--------------------------------------------------------------------------
  | TOGGLE
  |--------------------------------------------------------------------------
  */

  const toggleFAQ =
    (index) => {

      setOpenIndex(
        (prev) =>
          prev === index
            ? null
            : index
      );

    };


  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <>
      <main
        className="
          min-h-screen
          bg-gradient-to-b
          from-sky-50
          via-white
          to-white
          px-3
          py-7
          sm:px-5
          sm:py-10
          lg:px-8
          lg:py-14
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1100px]
          "
        >

          {/* ==================================================
              HERO
          =================================================== */}

          <section
            className="
              overflow-hidden
              rounded-[26px]
              border
              border-sky-100
              bg-white
              px-5
              py-8
              text-center
              shadow-sm
              sm:px-8
              sm:py-10
            "
          >

            <div
              className="
                flex
                justify-center
              "
            >

              <div
                className="
                  flex
                  items-center
                  gap-1.5
                "
              >

                <span
                  className="
                    h-1.5
                    w-1.5
                    rounded-full
                    bg-sky-300
                  "
                />

                <span
                  className="
                    h-2.5
                    w-2.5
                    rounded-full
                    bg-sky-500
                  "
                />

                <span
                  className="
                    h-1.5
                    w-1.5
                    rounded-full
                    bg-sky-300
                  "
                />

              </div>

            </div>


            <div
              className="
                mx-auto
                mt-4
                flex
                h-12
                w-12
                items-center
                justify-center
                rounded-2xl
                bg-sky-50
                text-sky-500
              "
            >
              <FaQuestionCircle />
            </div>


            <p
              className="
                mt-4
                text-[10px]
                font-bold
                uppercase
                tracking-[0.18em]
                text-sky-500
                sm:text-xs
              "
            >
              Help Center
            </p>


            <h1
              className="
                mt-2
                break-words
                text-3xl
                font-extrabold
                leading-tight
                tracking-tight
                text-gray-900
                sm:text-4xl
                md:text-5xl
              "
            >
              Frequently Asked Questions
            </h1>


            <p
              className="
                mx-auto
                mt-3
                max-w-2xl
                text-xs
                leading-6
                text-gray-500
                sm:text-sm
                sm:leading-7
              "
            >
              Everything you need to know about
              properties, services, pricing, listings,
              and support.
            </p>

          </section>


          {/* ==================================================
              FAQ CONTENT
          =================================================== */}

          <section
            className="
              mt-6
              sm:mt-8
            "
          >

            {/* LOADING */}

            {loading ? (

              <div
                className="
                  space-y-3
                "
              >

                {Array.from(
                  {
                    length: 6,
                  },
                  (_, index) => (
                    <div
                      key={
                        index
                      }
                      className="
                        h-20
                        animate-pulse
                        rounded-2xl
                        border
                        border-gray-100
                        bg-white
                        shadow-sm
                      "
                    />
                  )
                )}

              </div>

            ) : faqs.length ===
              0 ? (

              /* EMPTY */

              <div
                className="
                  rounded-2xl
                  border
                  border-dashed
                  border-sky-200
                  bg-white
                  px-5
                  py-14
                  text-center
                  shadow-sm
                "
              >

                <div
                  className="
                    mx-auto
                    flex
                    h-16
                    w-16
                    items-center
                    justify-center
                    rounded-full
                    bg-sky-50
                    text-2xl
                    text-sky-500
                  "
                >
                  ?
                </div>


                <h2
                  className="
                    mt-4
                    text-lg
                    font-bold
                    text-gray-800
                  "
                >
                  No FAQs Found
                </h2>


                <p
                  className="
                    mt-2
                    text-xs
                    leading-6
                    text-gray-500
                  "
                >
                  We couldn't find any frequently
                  asked questions right now.
                </p>

              </div>

            ) : (

              /* FAQ LIST */

              <div
                className="
                  space-y-3
                  sm:space-y-4
                "
              >

                {faqs.map(
                  (
                    faq,
                    index
                  ) => {

                    const isOpen =
                      openIndex ===
                      index;

                    return (
                      <article
                        key={
                          faq?._id ||
                          faq?.id ||
                          index
                        }
                        className={`
                          overflow-hidden
                          rounded-2xl
                          border
                          bg-white
                          shadow-sm
                          transition-all
                          duration-300

                          ${
                            isOpen
                              ? "border-sky-200 shadow-md"
                              : "border-gray-100 hover:border-sky-100 hover:shadow-md"
                          }
                        `}
                      >

                        {/* QUESTION */}

                        <button
                          type="button"
                          onClick={() =>
                            toggleFAQ(
                              index
                            )
                          }
                          aria-expanded={
                            isOpen
                          }
                          className="
                            flex
                            w-full
                            min-w-0
                            items-center
                            justify-between
                            gap-4
                            px-4
                            py-4
                            text-left
                            sm:px-5
                            sm:py-5
                          "
                        >

                          <div
                            className="
                              flex
                              min-w-0
                              items-start
                              gap-3
                            "
                          >

                            <div
                              className={`
                                mt-0.5
                                flex
                                h-8
                                w-8
                                shrink-0
                                items-center
                                justify-center
                                rounded-xl
                                text-xs
                                transition
                                ${
                                  isOpen
                                    ? "bg-sky-500 text-white"
                                    : "bg-sky-50 text-sky-500"
                                }
                              `}
                            >
                              {String(
                                index + 1
                              ).padStart(
                                2,
                                "0"
                              )}
                            </div>


                            <span
                              className={`
                                break-words
                                pr-1
                                text-sm
                                font-semibold
                                leading-6
                                transition
                                sm:text-base
                                ${
                                  isOpen
                                    ? "text-sky-600"
                                    : "text-gray-800"
                                }
                              `}
                            >
                              {faq?.question ||
                                "No Question"}
                            </span>

                          </div>


                          {/* ICON */}

                          <span
                            className={`
                              flex
                              h-9
                              w-9
                              shrink-0
                              items-center
                              justify-center
                              rounded-full
                              border
                              transition-all
                              duration-300
                              ${
                                isOpen
                                  ? "rotate-180 border-sky-200 bg-sky-50 text-sky-500"
                                  : "border-gray-200 bg-white text-gray-500"
                              }
                            `}
                          >
                            <FaChevronDown
                              size={
                                11
                              }
                            />
                          </span>

                        </button>


                        {/* ANSWER */}

                        <div
                          className={`
                            grid
                            transition-all
                            duration-300
                            ease-in-out

                            ${
                              isOpen
                                ? "grid-rows-[1fr] opacity-100"
                                : "grid-rows-[0fr] opacity-0"
                            }
                          `}
                        >

                          <div
                            className="
                              min-h-0
                              overflow-hidden
                            "
                          >

                            <div
                              className="
                                border-t
                                border-gray-100
                                px-4
                                pb-5
                                pt-4
                                text-sm
                                leading-7
                                text-gray-600
                                sm:px-5
                                sm:pl-[68px]
                              "
                            >
                              {faq?.answer ||
                                "No answer available."}
                            </div>

                          </div>

                        </div>

                      </article>
                    );

                  }
                )}

              </div>

            )}

          </section>

        </div>

      </main>


      <Footer />
    </>
  );
};


export default FAQPage;