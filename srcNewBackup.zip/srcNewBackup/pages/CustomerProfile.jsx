import React, {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  useNavigate,
} from "react-router-dom";

import {
  FaUser,
  FaCamera,
  FaPhone,
  FaMapMarkerAlt,
  FaGlobe,
  FaLock,
  FaCheckCircle,
  FaSave,
} from "react-icons/fa";

import Footer from "../components/Footer";


const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";


const CustomerProfile = () => {

  const navigate =
    useNavigate();


  /*
  |--------------------------------------------------------------------------
  | CUSTOMER
  |--------------------------------------------------------------------------
  */

  const [
    customer,
    setCustomer,
  ] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    country: "",
    img: "",
  });


  const [
    hasPassword,
    setHasPassword,
  ] = useState(false);


  const [
    passwordData,
    setPasswordData,
  ] = useState({
    current_password: "",
    new_password: "",
    new_password_confirmation: "",
  });


  const [
    selectedImage,
    setSelectedImage,
  ] = useState(null);


  const [
    loadingProfile,
    setLoadingProfile,
  ] = useState(true);


  const [
    savingProfile,
    setSavingProfile,
  ] = useState(false);


  const [
    savingPassword,
    setSavingPassword,
  ] = useState(false);


  const [
    imagePreview,
    setImagePreview,
  ] = useState("");


  /*
  |--------------------------------------------------------------------------
  | LOGIN
  |--------------------------------------------------------------------------
  */

  const isLoggedIn =
    !!localStorage.getItem(
      "customer_token"
    );


  /*
  |--------------------------------------------------------------------------
  | REDIRECT
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    if (!isLoggedIn) {

      navigate(
        "/",
        {
          replace: true,
        }
      );

    }

  }, [
    isLoggedIn,
    navigate,
  ]);


  /*
  |--------------------------------------------------------------------------
  | FETCH PROFILE
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    if (!isLoggedIn) {
      return;
    }

    const id =
      localStorage.getItem(
        "customer_id"
      );

    if (!id) {
      setLoadingProfile(false);
      return;
    }

    const fetchProfile =
      async () => {

        try {

          setLoadingProfile(
            true
          );

          const response =
            await fetch(
              `${API_BASE}/api/customer/profile/${id}`
            );

          if (!response.ok) {
            throw new Error(
              "Failed to fetch profile"
            );
          }

          const data =
            await response.json();

          if (data?.data) {

            setCustomer(
              data.data
            );

            setHasPassword(
              !!data.has_password
            );

          }

        } catch (error) {

          console.error(
            "Profile Error:",
            error
          );

        } finally {

          setLoadingProfile(
            false
          );

        }
      };

    fetchProfile();

  }, [
    isLoggedIn,
  ]);


  /*
  |--------------------------------------------------------------------------
  | CLEANUP IMAGE PREVIEW
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    return () => {

      if (
        imagePreview &&
        imagePreview.startsWith(
          "blob:"
        )
      ) {
        URL.revokeObjectURL(
          imagePreview
        );
      }

    };

  }, [
    imagePreview,
  ]);


  /*
  |--------------------------------------------------------------------------
  | HANDLERS
  |--------------------------------------------------------------------------
  */

  const handleChange =
    (event) => {

      const {
        name,
        value,
      } = event.target;

      setCustomer(
        (prev) => ({
          ...prev,
          [name]: value,
        })
      );

    };


  const handlePasswordChange =
    (event) => {

      const {
        name,
        value,
      } = event.target;

      setPasswordData(
        (prev) => ({
          ...prev,
          [name]: value,
        })
      );

    };


  /*
  |--------------------------------------------------------------------------
  | IMAGE
  |--------------------------------------------------------------------------
  */

  const handleImage =
    (event) => {

      const file =
        event.target.files?.[0];

      if (!file) {
        return;
      }

      setSelectedImage(
        file
      );

      const preview =
        URL.createObjectURL(
          file
        );

      setImagePreview(
        preview
      );

    };


  /*
  |--------------------------------------------------------------------------
  | IMAGE URL
  |--------------------------------------------------------------------------
  */

  const profileImage =
    useMemo(() => {

      if (
        imagePreview
      ) {
        return imagePreview;
      }

      if (
        customer?.img &&
        typeof customer.img ===
          "string"
      ) {

        return `${API_BASE}/public${customer.img}`;

      }

      const name =
        encodeURIComponent(
          customer?.name ||
            "Customer"
        );

      return `https://ui-avatars.com/api/?name=${name}&background=0ea5e9&color=fff&size=256`;

    }, [
      customer?.img,
      customer?.name,
      imagePreview,
    ]);


  /*
  |--------------------------------------------------------------------------
  | SAVE PROFILE
  |--------------------------------------------------------------------------
  */

  const handleSubmit =
    async () => {

      try {

        setSavingProfile(
          true
        );

        const formData =
          new FormData();


        Object.entries(
          customer
        ).forEach(
          ([
            key,
            value,
          ]) => {

            if (
              key ===
              "img"
            ) {
              return;
            }

            formData.append(
              key,
              value ?? ""
            );

          }
        );


        if (
          selectedImage
        ) {

          formData.append(
            "img",
            selectedImage
          );

        }


        const response =
          await fetch(
            `${API_BASE}/api/customer/profile/update`,
            {
              method: "POST",

              headers: {
                Authorization:
                  `Bearer ${localStorage.getItem(
                    "customer_token"
                  )}`,
              },

              body: formData,
            }
          );


        const data =
          await response.json();


        if (
          data?.status
        ) {

          const updatedCustomer =
            data.customer;


          setCustomer(
            updatedCustomer
          );


          localStorage.setItem(
            "customer",
            JSON.stringify({
              id:
                updatedCustomer?._id ||
                updatedCustomer?.id,

              name:
                updatedCustomer?.name,

              email:
                updatedCustomer?.email,

              phone:
                updatedCustomer?.phone ||
                null,

              image:
                updatedCustomer?.img ||
                null,
            })
          );


          setSelectedImage(
            null
          );

          if (
            imagePreview
          ) {
            URL.revokeObjectURL(
              imagePreview
            );

            setImagePreview(
              ""
            );
          }


          alert(
            "Profile Updated Successfully"
          );

        } else {

          alert(
            data?.message ||
              "Unable to update profile"
          );

        }

      } catch (
        error
      ) {

        console.error(
          "Profile update error:",
          error
        );

        alert(
          "Server error. Please try again later."
        );

      } finally {

        setSavingProfile(
          false
        );

      }

    };


  /*
  |--------------------------------------------------------------------------
  | UPDATE PASSWORD
  |--------------------------------------------------------------------------
  */

  const handleUpdatePassword =
    async () => {

      if (
        !passwordData
          .new_password
      ) {

        alert(
          "Please enter a new password."
        );

        return;

      }


      if (
        passwordData
          .new_password !==
        passwordData
          .new_password_confirmation
      ) {

        alert(
          "New password and confirmation do not match."
        );

        return;

      }


      try {

        setSavingPassword(
          true
        );

        const response =
          await fetch(
            `${API_BASE}/api/customer/change-password`,
            {
              method: "POST",

              headers: {
                "Content-Type":
                  "application/json",

                Authorization:
                  `Bearer ${localStorage.getItem(
                    "customer_token"
                  )}`,
              },

              body:
                JSON.stringify({
                  email:
                    customer.email,

                  ...passwordData,
                }),
            }
          );


        const data =
          await response.json();


        if (
          data?.status
        ) {

          alert(
            data?.message ||
              "Password updated successfully."
          );


          setPasswordData({
            current_password:
              "",
            new_password:
              "",
            new_password_confirmation:
              "",
          });

        } else {

          alert(
            data?.message ||
              "Unable to update password."
          );

        }

      } catch (
        error
      ) {

        console.error(
          "Password update error:",
          error
        );

        alert(
          "Server error. Please try again later."
        );

      } finally {

        setSavingPassword(
          false
        );

      }

    };


  /*
  |--------------------------------------------------------------------------
  | LOADING
  |--------------------------------------------------------------------------
  */

  if (!isLoggedIn) {
    return null;
  }


  if (
    loadingProfile
  ) {

    return (
      <main
        className="
          min-h-screen
          bg-[#f6f9ff]
          px-3
          py-6
          sm:px-5
          sm:py-10
          lg:px-8
          lg:py-14
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1200px]
          "
        >

          <div
            className="
              animate-pulse
              rounded-[28px]
              bg-white
              p-6
              shadow-sm
              sm:p-8
            "
          >

            <div
              className="
                h-7
                w-48
                rounded
                bg-gray-100
              "
            />

            <div
              className="
                mt-6
                grid
                grid-cols-1
                gap-6
                lg:grid-cols-[300px_minmax(0,1fr)]
              "
            >

              <div
                className="
                  h-80
                  rounded-2xl
                  bg-gray-100
                "
              />

              <div
                className="
                  h-80
                  rounded-2xl
                  bg-gray-100
                "
              />

            </div>

          </div>

        </div>

      </main>
    );

  }


  return (
    <>
      <main
        className="
          min-h-screen
          bg-[#f6f9ff]
          px-3
          py-5
          sm:px-5
          sm:py-8
          lg:px-8
          lg:py-12
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1200px]
          "
        >

          {/* ==================================================
              HEADER
          =================================================== */}

          <section
            className="
              relative
              overflow-hidden
              rounded-[26px]
              border
              border-sky-100
              bg-white
              px-5
              py-6
              shadow-sm
              sm:px-7
              sm:py-8
            "
          >

            <div
              className="
                pointer-events-none
                absolute
                -right-20
                -top-20
                h-48
                w-48
                rounded-full
                bg-sky-100/60
                blur-3xl
              "
            />

            <div
              className="
                relative
              "
            >

              <p
                className="
                  text-[10px]
                  font-bold
                  uppercase
                  tracking-[0.18em]
                  text-sky-500
                  sm:text-xs
                "
              >
                My Account
              </p>

              <h1
                className="
                  mt-1
                  break-words
                  text-2xl
                  font-extrabold
                  text-gray-900
                  sm:text-3xl
                "
              >
                Profile Settings
              </h1>

              <p
                className="
                  mt-2
                  max-w-2xl
                  text-xs
                  leading-6
                  text-gray-500
                  sm:text-sm
                "
              >
                Manage your personal information,
                profile photo and account password.
              </p>

            </div>

          </section>


          {/* ==================================================
              MAIN CONTENT
          =================================================== */}

          <div
            className="
              mt-5
              grid
              min-w-0
              grid-cols-1
              gap-5
              lg:grid-cols-[300px_minmax(0,1fr)]
              lg:gap-6
            "
          >

            {/* =================================================
                PROFILE SIDEBAR
            ================================================== */}

            <aside
              className="
                min-w-0
                rounded-[26px]
                border
                border-gray-100
                bg-white
                p-5
                text-center
                shadow-sm
                sm:p-6
                lg:sticky
                lg:top-6
                lg:self-start
              "
            >

              {/* PROFILE IMAGE */}

              <div
                className="
                  relative
                  mx-auto
                  w-fit
                "
              >

                <img
                  src={
                    profileImage
                  }
                  alt={
                    customer.name ||
                    "Customer"
                  }
                  className="
                    h-28
                    w-28
                    rounded-full
                    border-4
                    border-sky-100
                    object-cover
                    shadow-md
                    sm:h-32
                    sm:w-32
                  "
                />

                <label
                  className="
                    absolute
                    bottom-0
                    right-0
                    flex
                    h-9
                    w-9
                    cursor-pointer
                    items-center
                    justify-center
                    rounded-full
                    border-4
                    border-white
                    bg-sky-500
                    text-white
                    shadow-md
                    transition
                    hover:bg-sky-600
                  "
                  title="Change profile photo"
                >

                  <FaCamera
                    size={12}
                  />

                  <input
                    type="file"
                    accept="image/*"
                    onChange={
                      handleImage
                    }
                    className="
                      hidden
                    "
                  />

                </label>

              </div>


              {/* NAME */}

              <h2
                className="
                  mt-5
                  break-words
                  text-xl
                  font-bold
                  text-gray-900
                  sm:text-2xl
                "
              >
                {customer.name ||
                  "Customer"}
              </h2>


              {/* EMAIL */}

              <p
                className="
                  mt-1
                  break-all
                  text-xs
                  text-gray-500
                "
              >
                {customer.email ||
                  "Email not available"}
              </p>


              {/* STATUS */}

              <div
                className="
                  mt-4
                  inline-flex
                  items-center
                  gap-2
                  rounded-full
                  bg-green-50
                  px-3
                  py-1.5
                  text-[10px]
                  font-semibold
                  text-green-600
                "
              >

                <FaCheckCircle />

                Account Active

              </div>


              {/* LOCATION */}

              <div
                className="
                  mt-6
                  space-y-3
                  border-t
                  border-gray-100
                  pt-5
                  text-left
                "
              >

                <ProfileRow
                  icon={
                    <FaPhone />
                  }
                  label="Phone"
                  value={
                    customer.phone
                  }
                />

                <ProfileRow
                  icon={
                    <FaMapMarkerAlt />
                  }
                  label="City"
                  value={
                    customer.city
                  }
                />

                <ProfileRow
                  icon={
                    <FaGlobe />
                  }
                  label="Country"
                  value={
                    customer.country
                  }
                />

              </div>

            </aside>


            {/* =================================================
                RIGHT CONTENT
            ================================================== */}

            <div
              className="
                min-w-0
                space-y-5
              "
            >

              {/* =================================================
                  PERSONAL INFORMATION
              ================================================== */}

              <section
                className="
                  rounded-[26px]
                  border
                  border-gray-100
                  bg-white
                  p-5
                  shadow-sm
                  sm:p-7
                "
              >

                <div
                  className="
                    flex
                    items-start
                    gap-3
                  "
                >

                  <div
                    className="
                      flex
                      h-10
                      w-10
                      shrink-0
                      items-center
                      justify-center
                      rounded-xl
                      bg-sky-50
                      text-sky-500
                    "
                  >
                    <FaUser
                      size={15}
                    />
                  </div>

                  <div>
                    <h2
                      className="
                        text-lg
                        font-bold
                        text-gray-900
                        sm:text-xl
                      "
                    >
                      Personal Information
                    </h2>

                    <p
                      className="
                        mt-1
                        text-xs
                        text-gray-500
                      "
                    >
                      Keep your profile information up to date.
                    </p>
                  </div>

                </div>


                <div
                  className="
                    mt-6
                    grid
                    grid-cols-1
                    gap-4
                    sm:grid-cols-2
                  "
                >

                  <ProfileInput
                    label="Full Name"
                    name="name"
                    value={
                      customer.name
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Full Name"
                  />

                  <ProfileInput
                    label="Phone Number"
                    name="phone"
                    value={
                      customer.phone
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Phone Number"
                    type="tel"
                  />

                  <ProfileInput
                    label="City"
                    name="city"
                    value={
                      customer.city
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="City"
                  />

                  <ProfileInput
                    label="State"
                    name="state"
                    value={
                      customer.state
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="State"
                  />

                  <ProfileInput
                    label="Country"
                    name="country"
                    value={
                      customer.country
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Country"
                  />

                  <ProfileInput
                    label="Address"
                    name="address"
                    value={
                      customer.address
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Address"
                    className="sm:col-span-2"
                  />

                </div>


                <div
                  className="
                    mt-6
                    flex
                    flex-col
                    gap-3
                    sm:flex-row
                    sm:items-center
                    sm:justify-between
                  "
                >

                  {selectedImage ? (
                    <p
                      className="
                        break-all
                        text-xs
                        text-gray-500
                      "
                    >
                      Selected:
                      {" "}
                      <span className="font-medium text-gray-700">
                        {selectedImage.name}
                      </span>
                    </p>
                  ) : (
                    <p
                      className="
                        text-xs
                        text-gray-400
                      "
                    >
                      JPG, PNG or WEBP image recommended.
                    </p>
                  )}


                  <button
                    type="button"
                    onClick={
                      handleSubmit
                    }
                    disabled={
                      savingProfile
                    }
                    className="
                      inline-flex
                      min-h-[46px]
                      w-full
                      items-center
                      justify-center
                      gap-2
                      rounded-xl
                      bg-sky-500
                      px-5
                      py-3
                      text-sm
                      font-semibold
                      text-white
                      shadow-sm
                      transition
                      hover:bg-sky-600
                      active:scale-[0.98]
                      disabled:cursor-not-allowed
                      disabled:opacity-50
                      sm:w-fit
                    "
                  >

                    <FaSave
                      className="text-xs"
                    />

                    {savingProfile
                      ? "Saving..."
                      : "Save Changes"}

                  </button>

                </div>

              </section>


              {/* =================================================
                  PASSWORD
              ================================================== */}

              <section
                className="
                  rounded-[26px]
                  border
                  border-gray-100
                  bg-white
                  p-5
                  shadow-sm
                  sm:p-7
                "
              >

                <div
                  className="
                    flex
                    items-start
                    gap-3
                  "
                >

                  <div
                    className="
                      flex
                      h-10
                      w-10
                      shrink-0
                      items-center
                      justify-center
                      rounded-xl
                      bg-green-50
                      text-green-500
                    "
                  >
                    <FaLock
                      size={14}
                    />
                  </div>


                  <div>
                    <h2
                      className="
                        text-lg
                        font-bold
                        text-gray-900
                        sm:text-xl
                      "
                    >
                      {hasPassword
                        ? "Change Password"
                        : "Create Password"}
                    </h2>

                    <p
                      className="
                        mt-1
                        text-xs
                        text-gray-500
                      "
                    >
                      {hasPassword
                        ? "Update your password to keep your account secure."
                        : "Create a password to secure your account."}
                    </p>
                  </div>

                </div>


                <div
                  className="
                    mt-6
                    space-y-4
                  "
                >

                  {hasPassword && (
                    <PasswordInput
                      label="Current Password"
                      name="current_password"
                      value={
                        passwordData.current_password
                      }
                      onChange={
                        handlePasswordChange
                      }
                      placeholder="Current Password"
                    />
                  )}


                  <PasswordInput
                    label="New Password"
                    name="new_password"
                    value={
                      passwordData.new_password
                    }
                    onChange={
                      handlePasswordChange
                    }
                    placeholder="New Password"
                  />

                  <PasswordInput
                    label="Confirm New Password"
                    name="new_password_confirmation"
                    value={
                      passwordData.new_password_confirmation
                    }
                    onChange={
                      handlePasswordChange
                    }
                    placeholder="Confirm New Password"
                  />

                </div>


                <div
                  className="
                    mt-6
                    flex
                    flex-col
                    gap-3
                    sm:flex-row
                    sm:items-center
                    sm:justify-between
                  "
                >

                  <p
                    className="
                      text-xs
                      leading-5
                      text-gray-400
                    "
                  >
                    Use a strong password that you don't use
                    on other websites.
                  </p>


                  <button
                    type="button"
                    onClick={
                      handleUpdatePassword
                    }
                    disabled={
                      savingPassword
                    }
                    className="
                      inline-flex
                      min-h-[46px]
                      w-full
                      items-center
                      justify-center
                      gap-2
                      rounded-xl
                      bg-green-500
                      px-5
                      py-3
                      text-sm
                      font-semibold
                      text-white
                      transition
                      hover:bg-green-600
                      active:scale-[0.98]
                      disabled:cursor-not-allowed
                      disabled:opacity-50
                      sm:w-fit
                    "
                  >

                    <FaLock
                      className="text-xs"
                    />

                    {savingPassword
                      ? "Updating..."
                      : hasPassword
                      ? "Update Password"
                      : "Create Password"}

                  </button>

                </div>

              </section>

            </div>

          </div>

        </div>

      </main>

      <Footer />
    </>
  );
};


/*
|--------------------------------------------------------------------------
| PROFILE ROW
|--------------------------------------------------------------------------
*/

const ProfileRow = ({
  icon,
  label,
  value,
}) => {

  return (
    <div
      className="
        flex
        min-w-0
        items-start
        gap-3
      "
    >

      <div
        className="
          flex
          h-8
          w-8
          shrink-0
          items-center
          justify-center
          rounded-lg
          bg-sky-50
          text-sky-500
        "
      >
        {icon}
      </div>


      <div
        className="
          min-w-0
        "
      >

        <p
          className="
            text-[10px]
            uppercase
            tracking-wide
            text-gray-400
          "
        >
          {label}
        </p>

        <p
          className="
            mt-0.5
            break-words
            text-xs
            font-medium
            text-gray-700
          "
        >
          {value ||
            "N/A"}
        </p>

      </div>

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| INPUT
|--------------------------------------------------------------------------
*/

const ProfileInput = ({
  label,
  name,
  value,
  onChange,
  placeholder,
  type = "text",
  className = "",
}) => {

  return (
    <div
      className={`min-w-0 ${className}`}
    >

      <label
        className="
          mb-2
          block
          text-xs
          font-semibold
          text-gray-700
        "
      >
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value || ""}
        onChange={onChange}
        placeholder={placeholder}
        className="
          h-12
          w-full
          min-w-0
          rounded-xl
          border
          border-gray-200
          bg-gray-50
          px-4
          text-sm
          text-gray-700
          outline-none
          transition
          placeholder:text-gray-400
          focus:border-sky-400
          focus:bg-white
          focus:ring-2
          focus:ring-sky-100
        "
      />

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| PASSWORD INPUT
|--------------------------------------------------------------------------
*/

const PasswordInput = ({
  label,
  name,
  value,
  onChange,
  placeholder,
}) => {

  return (
    <div
      className="
        min-w-0
      "
    >

      <label
        className="
          mb-2
          block
          text-xs
          font-semibold
          text-gray-700
        "
      >
        {label}
      </label>

      <input
        type="password"
        name={name}
        value={value || ""}
        onChange={onChange}
        placeholder={placeholder}
        className="
          h-12
          w-full
          rounded-xl
          border
          border-gray-200
          bg-gray-50
          px-4
          text-sm
          text-gray-700
          outline-none
          transition
          placeholder:text-gray-400
          focus:border-green-400
          focus:bg-white
          focus:ring-2
          focus:ring-green-100
        "
      />

    </div>
  );
};


export default CustomerProfile;