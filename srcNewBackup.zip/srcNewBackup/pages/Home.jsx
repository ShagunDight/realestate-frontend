import React, { useState } from "react";

import Features from "../components/Features";
import FeaturedProperties from "../components/FeaturedProperties";
import Testimonials from "../components/Testimonials";
import FAQ from "../components/FAQ";
import CTASection from "../components/CTASection";
import Footer from "../components/Footer";
import SearchBar from "../components/SearchBar";
import MultiImageSlider from "../components/MultiImageSlider";
import MobileNearbyProperties from "../components/MobileNearbyProperties";

const Home = () => {
  const [filters, setFilters] = useState({
    location: "",
    type: "",
    space_use: "",
    listing_type: "",
    min_price: "",
    max_price: "",
  });

  /*
  |--------------------------------------------------------------------------
  | SEARCH
  |--------------------------------------------------------------------------
  */

  const handleSearch = async () => {
    try {
      const query = new URLSearchParams(filters).toString();

      const res = await fetch(
        `https://lightblue-moose-690494.hostingersite.com/api/properties?${query}`
      );

      const data = await res.json();

      console.log("SEARCH RESULT:", data);
    } catch (error) {
      console.error("Search Error:", error);
    }
  };

  return (
    <>
      {/* =========================================================
          MOBILE + TABLET HOME
          ========================================================= */}

      <section className="block overflow-hidden bg-white lg:hidden">
        {/* =======================================================
            HERO
            ======================================================= */}

        <div
          className="
            relative
            overflow-hidden
            bg-gradient-to-b
            from-sky-50
            via-white
            to-white
          "
        >
          {/* Decorative glow */}

          <div
            className="
              pointer-events-none
              absolute
              -right-24
              -top-24
              h-56
              w-56
              rounded-full
              bg-sky-200/30
              blur-3xl
              sm:h-72
              sm:w-72
            "
          />

          <div
            className="
              pointer-events-none
              absolute
              -left-24
              bottom-0
              h-48
              w-48
              rounded-full
              bg-sky-100/40
              blur-3xl
              sm:h-60
              sm:w-60
            "
          />

          <div
            className="
              relative
              mx-auto
              max-w-3xl
              px-4
              pb-8
              pt-10
              sm:px-6
              sm:pb-10
              sm:pt-12
              md:px-8
              md:pb-12
              md:pt-14
            "
          >
            {/* HERO CONTENT */}

            <div
              className="
                mx-auto
                max-w-2xl
                text-center
              "
            >
              <span
                className="
                  inline-flex
                  items-center
                  rounded-full
                  border
                  border-sky-100
                  bg-white
                  px-3
                  py-1.5
                  text-[10px]
                  font-semibold
                  uppercase
                  tracking-[0.15em]
                  text-sky-500
                  shadow-sm
                  sm:px-4
                  sm:py-2
                  sm:text-xs
                "
              >
                Find Your Place
              </span>

              <h1
                className="
                  mt-4
                  text-[34px]
                  font-extrabold
                  leading-[1.08]
                  tracking-tight
                  text-gray-900
                  sm:text-[42px]
                  md:text-[48px]
                "
              >
                Find Your
                <span className="block text-sky-500">
                  Dream Property
                </span>
                With Confidence
              </h1>

              <p
                className="
                  mx-auto
                  mt-4
                  max-w-[360px]
                  text-sm
                  leading-6
                  text-gray-600
                  sm:max-w-xl
                  sm:text-base
                  sm:leading-7
                "
              >
                Find the perfect property easily with our modern
                platform designed to simplify your search and help
                you discover spaces that match your lifestyle and budget.
              </p>
            </div>

            {/* SEARCH */}

            <div
              className="
                relative
                z-20
                mx-auto
                mt-7
                max-w-2xl
                sm:mt-8
                md:mt-10
              "
            >
              <div
                className="
                  rounded-2xl
                  border
                  border-gray-100
                  bg-white
                  p-2
                  shadow-[0_15px_40px_rgba(0,0,0,0.08)]
                  sm:rounded-3xl
                  sm:p-3
                "
              >
                <SearchBar
                  filters={filters}
                  setFilters={setFilters}
                  onSearch={handleSearch}
                  hideAdvancedFilters={true}
                />
              </div>
            </div>
          </div>
        </div>

        {/* =======================================================
            LOCATION BASED PROPERTIES
            ======================================================= */}

        <MobileNearbyProperties />
      </section>

      {/* =========================================================
          DESKTOP HOME
          ========================================================= */}

      <section
        className="
          relative
          hidden
          overflow-hidden
          bg-white
          lg:block
        "
      >
        <div
          className="
            mx-auto
            max-w-[1300px]
            px-4
            sm:px-6
            xl:px-0
          "
        >
          <div
            className="
              grid
              grid-cols-2
              items-center
              gap-10
              py-12
              lg:py-16
              xl:gap-14
            "
          >
            {/* =================================================
                LEFT CONTENT
                ================================================= */}

            <div className="text-left">
              <h1
                className="
                  text-4xl
                  font-extrabold
                  leading-tight
                  text-gray-900
                  lg:text-5xl
                  xl:text-6xl
                "
              >
                Find Your

                <span className="block text-sky-500">
                  Dream Property
                </span>

                With Confidence
              </h1>

              <p
                className="
                  mt-4
                  max-w-md
                  text-sm
                  leading-6
                  text-gray-600
                  lg:text-base
                  lg:leading-7
                "
              >
                Find the perfect property easily with our modern
                platform designed to simplify your search and help
                you discover homes that truly match your lifestyle
                and budget.
              </p>

              {/* STATS */}

              <div
                className="
                  mt-6
                  grid
                  max-w-xl
                  grid-cols-3
                  gap-4
                  xl:mt-8
                "
              >
                {[
                  {
                    num: "200+",
                    text: "Customers",
                  },
                  {
                    num: "10k+",
                    text: "Properties",
                  },
                  {
                    num: "16+",
                    text: "Experience",
                  },
                ].map((item, index) => (
                  <div
                    key={index}
                    className="
                      rounded-2xl
                      border
                      border-gray-100
                      bg-white
                      py-4
                      text-center
                      shadow-lg
                      transition
                      duration-300
                      hover:-translate-y-1
                      hover:shadow-xl
                      lg:py-5
                    "
                  >
                    <h2
                      className="
                        text-lg
                        font-bold
                        text-gray-900
                      "
                    >
                      {item.num}
                    </h2>

                    <p className="mt-1 text-xs text-gray-500">
                      {item.text}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* =================================================
                RIGHT IMAGE
                ================================================= */}

            <div className="relative flex justify-end">
              <div
                className="
                  relative
                  h-[360px]
                  w-full
                  max-w-[650px]
                  lg:h-[400px]
                "
              >
                {/* Glow */}

                <div
                  className="
                    absolute
                    inset-0
                    rounded-full
                    bg-sky-300/20
                    blur-[90px]
                  "
                />

                {/* Main Image */}

                <img
                  src="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00"
                  alt="Modern property building"
                  className="
                    relative
                    h-full
                    w-full
                    rounded-[28px]
                    object-cover
                    shadow-2xl
                    lg:rounded-[32px]
                  "
                />

                {/* Rotating Circle */}

                <div
                  className="
                    absolute
                    left-[-32px]
                    top-1/2
                    hidden
                    -translate-y-1/2
                    sm:block
                    lg:left-[-50px]
                  "
                >
                  <div
                    className="
                      relative
                      flex
                      h-20
                      w-20
                      items-center
                      justify-center
                      rounded-full
                      border
                      border-sky-200
                      bg-white/80
                      shadow-lg
                      backdrop-blur-md
                      lg:h-24
                      lg:w-24
                    "
                  >
                    <svg
                      className="
                        absolute
                        h-full
                        w-full
                        animate-spin-slow
                      "
                      viewBox="0 0 100 100"
                    >
                      <defs>
                        <path
                          id="circlePath"
                          d="M 50,50 m -40,0 a 40,40 0 1,1 80,0 a 40,40 0 1,1 -80,0"
                        />
                      </defs>

                      <text
                        fill="#0EA5E9"
                        fontSize="10"
                        letterSpacing="2"
                      >
                        <textPath href="#circlePath">
                          • DISCOVER • DREAM • PROPERTY •
                        </textPath>
                      </text>
                    </svg>

                    <div
                      className="
                        z-10
                        flex
                        h-9
                        w-9
                        items-center
                        justify-center
                        rounded-full
                        bg-sky-500
                        text-sm
                        text-white
                        lg:h-10
                        lg:w-10
                      "
                    >
                      ↗
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* =======================================================
            DESKTOP SEARCH
            ======================================================= */}

        <div
          className="
            mx-auto
            max-w-[1320px]
            px-4
            sm:px-6
            xl:px-0
          "
        >
          <div
            className="
              mb-8
              mt-6
              md:mt-8
            "
          >
            <SearchBar
              filters={filters}
              setFilters={setFilters}
              onSearch={handleSearch}
            />
          </div>
        </div>
      </section>

      {/* =========================================================
          COMMON SECTIONS
          ========================================================= */}

      <Features />

      <FeaturedProperties />

      <MultiImageSlider />

      <Testimonials />

      <CTASection />

      <FAQ />

      <Footer />
    </>
  );
};

export default Home;
