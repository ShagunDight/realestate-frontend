import React from "react";
import { useNavigate } from "react-router-dom";
import {
  FaHeart,
  FaRegHeart,
} from "react-icons/fa";
import { useWishlist } from "./WishlistContext";

const PropertyCard = ({
  item,
  setShowLogin,
}) => {
  const navigate = useNavigate();

  const {
    toggleWishlist,
    isWished,
  } = useWishlist();

  /*
  |--------------------------------------------------------------------------
  | PROPERTY ID
  |--------------------------------------------------------------------------
  */

  const propertyId =
    item?._id || item?.id;


  /*
  |--------------------------------------------------------------------------
  | LOGIN CHECK
  |--------------------------------------------------------------------------
  */

  const isLoggedIn =
    !!localStorage.getItem(
      "customer_token"
    );


  /*
  |--------------------------------------------------------------------------
  | STRIP HTML
  |--------------------------------------------------------------------------
  */

  const stripHtml = (html) => {
    const div =
      document.createElement("div");

    div.innerHTML = html || "";

    return (
      div.textContent ||
      div.innerText ||
      ""
    );
  };


  /*
  |--------------------------------------------------------------------------
  | IMAGE
  |--------------------------------------------------------------------------
  */

  const getImage = () => {
    const fallback =
      "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg";

    let images = item?.image;

    if (typeof images === "string") {
      try {
        images = JSON.parse(images);
      } catch {
        return fallback;
      }
    }

    if (
      !Array.isArray(images) ||
      images.length === 0
    ) {
      return fallback;
    }

    const firstImage = images[0];

    if (
      typeof firstImage === "object" &&
      firstImage?.path
    ) {
      return `https://lightblue-moose-690494.hostingersite.com/public/${firstImage.path}`;
    }

    if (
      typeof firstImage === "string"
    ) {
      return `https://lightblue-moose-690494.hostingersite.com/public/${firstImage}`;
    }

    return fallback;
  };


  /*
  |--------------------------------------------------------------------------
  | STATUS
  |--------------------------------------------------------------------------
  */

  const statusStyles = {
    active:
      "bg-green-100 text-green-700 border-green-200",

    sold:
      "bg-red-100 text-red-700 border-red-200",

    pending:
      "bg-yellow-100 text-yellow-700 border-yellow-200",

    rented:
      "bg-blue-100 text-blue-700 border-blue-200",
  };


  const statusLabel =
    item?.status
      ? item.status
          .charAt(0)
          .toUpperCase() +
        item.status.slice(1)
      : "Unknown";


  /*
  |--------------------------------------------------------------------------
  | PRICE
  |--------------------------------------------------------------------------
  */

  const propertyType =
    item?.property_type?.name
      ?.toLowerCase() || "";


  const isLease =
    propertyType.includes("lease") ||
    propertyType.includes("rent");


  const price = isLease
    ? item?.monthly_rent
    : item?.sale_price;


  const formattedPrice =
    price !== null &&
    price !== undefined &&
    price !== ""
      ? `₹${Number(
          price
        ).toLocaleString("en-IN")}`
      : "Price on request";


  /*
  |--------------------------------------------------------------------------
  | WISHLIST
  |--------------------------------------------------------------------------
  */

  const handleWishlistClick = (
    event
  ) => {
    event.stopPropagation();

    if (!isLoggedIn) {
      setShowLogin?.(true);
      return;
    }

    toggleWishlist(item);
  };


  /*
  |--------------------------------------------------------------------------
  | VIEW PROPERTY
  |--------------------------------------------------------------------------
  */

  const handleViewProperty = (
    event
  ) => {
    event.stopPropagation();

    navigate(
      `/property/${propertyId}`
    );
  };


  /*
  |--------------------------------------------------------------------------
  | CARD
  |--------------------------------------------------------------------------
  */

  return (
    <article
      onClick={() =>
        navigate(
          `/property/${propertyId}`
        )
      }
      className="
        group
        flex
        h-full
        cursor-pointer
        flex-col
        overflow-hidden
        rounded-2xl
        border
        border-gray-200
        bg-white
        shadow-sm
        transition-all
        duration-300
        hover:-translate-y-1
        hover:shadow-2xl
        active:scale-[0.995]
        sm:rounded-[22px]
      "
    >

      {/* ======================================================
          IMAGE
      ======================================================= */}

      <div
        className="
          relative
          aspect-[16/10]
          w-full
          overflow-hidden
          bg-gray-100
          sm:aspect-[16/10]
        "
      >

        <img
          src={getImage()}
          alt={
            item?.title ||
            "Property"
          }
          loading="lazy"
          className="
            h-full
            w-full
            object-cover
            transition-transform
            duration-500
            group-hover:scale-105
          "
          onError={(e) => {
            e.currentTarget.src =
              "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg";
          }}
        />


        {/* IMAGE GRADIENT */}

        <div
          className="
            pointer-events-none
            absolute
            inset-x-0
            bottom-0
            h-20
            bg-gradient-to-t
            from-black/30
            to-transparent
          "
        />


        {/* STATUS BADGE */}

        <div
          className="
            absolute
            left-3
            top-3
          "
        >
          <span
            className={`
              inline-flex
              items-center
              rounded-full
              border
              px-3
              py-1.5
              text-[10px]
              font-semibold
              shadow-sm
              backdrop-blur-md
              sm:text-xs

              ${
                statusStyles[
                  item?.status
                ] ||
                "border-gray-200 bg-gray-100 text-gray-600"
              }
            `}
          >
            {statusLabel}
          </span>
        </div>


        {/* WISHLIST */}

        <button
          type="button"
          aria-label={
            isWished(propertyId)
              ? "Remove from wishlist"
              : "Add to wishlist"
          }
          onClick={
            handleWishlistClick
          }
          className="
            absolute
            right-3
            top-3
            flex
            h-10
            w-10
            items-center
            justify-center
            rounded-full
            border
            border-white/50
            bg-white/90
            text-sm
            shadow-md
            backdrop-blur-md
            transition-all
            duration-200
            hover:scale-105
            active:scale-95
            sm:h-11
            sm:w-11
          "
        >
          {isWished(
            propertyId
          ) ? (
            <FaHeart className="text-red-500" />
          ) : (
            <FaRegHeart className="text-gray-500" />
          )}
        </button>

      </div>


      {/* ======================================================
          CONTENT
      ======================================================= */}

      <div
        className="
          flex
          flex-1
          flex-col
          p-4
          sm:p-5
        "
      >

        {/* TITLE */}

        <h3
          className="
            line-clamp-2
            min-h-[40px]
            text-sm
            font-bold
            leading-5
            text-gray-900
            transition-colors
            group-hover:text-sky-600
            sm:text-base
            sm:leading-6
          "
        >
          {item?.title ||
            "Untitled Property"}
        </h3>


        {/* LOCATION */}

        <div
          className="
            mt-2
            flex
            items-center
            gap-2
          "
        >

          <p
            className="
              min-w-0
              flex-1
              truncate
              text-xs
              text-gray-500
              sm:text-sm
            "
          >
            📍{" "}
            {item?.location ||
              item?.city ||
              "Location not available"}
          </p>


          {item?.zip_code && (
            <span
              className="
                shrink-0
                rounded-lg
                border
                border-sky-100
                bg-sky-50
                px-2
                py-1
                text-[10px]
                font-semibold
                text-sky-600
                sm:text-xs
              "
            >
              {item.zip_code}
            </span>
          )}

        </div>


        {/* PRICE */}

        <div
          className="
            mt-4
            rounded-xl
            bg-gray-50
            px-3
            py-3
          "
        >

          <p
            className="
              text-[10px]
              font-medium
              uppercase
              tracking-wide
              text-gray-400
            "
          >
            {isLease
              ? "Monthly Rent"
              : "Sale Price"}
          </p>

          <p
            className="
              mt-0.5
              text-base
              font-bold
              text-sky-600
              sm:text-lg
            "
          >
            {formattedPrice}
          </p>

        </div>


        {/* VIEW BUTTON */}

        <button
          type="button"
          onClick={
            handleViewProperty
          }
          className="
            mt-4
            flex
            min-h-[44px]
            w-full
            items-center
            justify-center
            rounded-xl
            bg-sky-500
            px-4
            py-2.5
            text-xs
            font-semibold
            text-white
            shadow-sm
            transition-all
            duration-200
            hover:bg-sky-600
            hover:shadow-md
            active:scale-[0.98]
            sm:text-sm
          "
        >
          View Details
          <span className="ml-1.5 text-sm">
            →
          </span>
        </button>

      </div>
    </article>
  );
};

export default PropertyCard;
