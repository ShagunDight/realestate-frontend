import React, {
  useEffect,
  useRef,
  useState,
} from "react";

import {
  Link,
  NavLink,
} from "react-router-dom";

import {
  FaHeart,
  FaUser,
  FaSignOutAlt,
  FaChevronRight,
  FaBuilding,
} from "react-icons/fa";

import {
  useWishlist,
} from "./WishlistContext";


const Navbar = ({
  setShowLogin,
  customer,
  setCustomer,
}) => {
  const [profileOpen, setProfileOpen] =
    useState(false);

  const profileRef =
    useRef(null);

  const {
    wishlist = [],
  } = useWishlist();


  /*
  |--------------------------------------------------------------------------
  | CUSTOMER
  |--------------------------------------------------------------------------
  */

  const customerInfo =
    customer || null;


  /*
  |--------------------------------------------------------------------------
  | CLOSE PROFILE ON OUTSIDE CLICK
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        profileRef.current &&
        !profileRef.current.contains(event.target)
      ) {
        setProfileOpen(false);
      }
    };

    document.addEventListener(
      "mousedown",
      handleOutsideClick
    );

    return () => {
      document.removeEventListener(
        "mousedown",
        handleOutsideClick
      );
    };
  }, []);


  /*
  |--------------------------------------------------------------------------
  | CLOSE PROFILE WITH ESC
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setProfileOpen(false);
      }
    };

    document.addEventListener(
      "keydown",
      handleKeyDown
    );

    return () => {
      document.removeEventListener(
        "keydown",
        handleKeyDown
      );
    };
  }, []);


  /*
  |--------------------------------------------------------------------------
  | LOGOUT
  |--------------------------------------------------------------------------
  */

  const handleLogout = () => {
    localStorage.removeItem("customer_token");
    localStorage.removeItem("customer_id");
    localStorage.removeItem("customer_name");
    localStorage.removeItem("customer_email");
    localStorage.removeItem("customer_phone");
    localStorage.removeItem("customer");

    setProfileOpen(false);
    setShowLogin(false);

    setCustomer?.(null);
  };


  /*
  |--------------------------------------------------------------------------
  | PROFILE IMAGE
  |--------------------------------------------------------------------------
  */

  const profileImage =
    customerInfo?.image ||
    customerInfo?.img
      ? `https://lightblue-moose-690494.hostingersite.com/public/${
          customerInfo?.image ||
          customerInfo?.img
        }`
      : `https://ui-avatars.com/api/?name=${encodeURIComponent(
          customerInfo?.name || "Customer"
        )}&background=0ea5e9&color=fff&size=128`;


  /*
  |--------------------------------------------------------------------------
  | NAV LINK STYLE
  |--------------------------------------------------------------------------
  */

  const navClass = ({ isActive }) => `
    flex
    shrink-0
    items-center
    justify-center
    whitespace-nowrap
    rounded-lg
    px-3
    py-2
    text-xs
    font-medium
    transition-all
    duration-200

    sm:rounded-xl
    sm:px-3.5
    sm:py-2.5
    sm:text-sm

    ${
      isActive
        ? "bg-sky-100 text-sky-600"
        : "text-gray-600 hover:bg-sky-50 hover:text-sky-500"
    }
  `;


  /*
  |--------------------------------------------------------------------------
  | LOGO CLICK
  |--------------------------------------------------------------------------
  */

  const handleLogoClick = () => {
    setProfileOpen(false);
  };


  return (
    <>
      <header
        className="
          sticky
          top-0
          z-[100]
          w-full
          border-b
          border-gray-200
          bg-white/95
          shadow-sm
          backdrop-blur-xl
        "
      >

        {/* =====================================================
            ANNOUNCEMENT BAR
        ====================================================== */}

        <div
          className="
            hidden
            bg-gradient-to-r
            from-sky-500
            to-blue-500
            px-4
            py-2
            text-center
            text-[10px]
            font-medium
            text-white

            sm:block
            sm:text-xs
          "
        >
          Discover Your Dream Property — Built for Modern Living
        </div>


        {/* =====================================================
            MAIN NAVBAR
        ====================================================== */}

        <div
          className="
            mx-auto
            w-full
            max-w-[1380px]
            px-3

            sm:px-5
            lg:px-8
          "
        >

          {/* =================================================
              TOP ROW
          ================================================= */}

          <div
            className="
              flex
              min-h-[64px]
              w-full
              items-center
              justify-between
              gap-3

              sm:min-h-[72px]
              sm:gap-4
            "
          >

            {/* =================================================
                LOGO
            ================================================= */}

            <Link
              to="/"
              onClick={handleLogoClick}
              className="
                flex
                shrink-0
                items-center
                gap-2

                sm:gap-2.5
              "
            >

              <div
                className="
                  flex
                  h-9
                  w-9
                  shrink-0
                  items-center
                  justify-center
                  rounded-lg
                  bg-sky-500
                  shadow-md

                  sm:h-11
                  sm:w-11
                  sm:rounded-xl
                "
              >
                <span
                  className="
                    text-sm
                    font-extrabold
                    text-white

                    sm:text-lg
                  "
                >
                  E
                </span>
              </div>


              <span
                className="
                  text-base
                  font-extrabold
                  tracking-tight
                  text-gray-900

                  sm:text-xl
                "
              >
                Estatein
              </span>

            </Link>


            {/* =================================================
                DESKTOP NAV
                >= 1024px
            ================================================= */}

            <nav
              className="
                hidden
                min-w-0
                flex-1
                items-center
                justify-center
                gap-1

                lg:flex
                lg:gap-1.5
                xl:gap-2
              "
            >

              <NavLink
                to="/"
                className={navClass}
              >
                Home
              </NavLink>

              <NavLink
                to="/about"
                className={navClass}
              >
                About
              </NavLink>

              <NavLink
                to="/properties"
                className={navClass}
              >
                Properties
              </NavLink>

              <NavLink
                to="/services"
                className={navClass}
              >
                Services
              </NavLink>

              <NavLink
                to="/contact"
                className={navClass}
              >
                Contact
              </NavLink>

            </nav>


            {/* =================================================
                LOGIN / PROFILE
            ================================================= */}

            <div
              ref={profileRef}
              className="
                relative
                flex
                shrink-0
                items-center
              "
            >

              {!customerInfo ? (

                <button
                  type="button"
                  onClick={() =>
                    setShowLogin(true)
                  }
                  className="
                    flex
                    h-9
                    items-center
                    justify-center
                    rounded-lg
                    bg-sky-500
                    px-3
                    text-xs
                    font-semibold
                    text-white
                    shadow-sm
                    transition
                    hover:bg-sky-600
                    active:scale-[0.97]

                    sm:h-11
                    sm:rounded-xl
                    sm:px-5
                    sm:text-sm
                  "
                >
                  Login
                </button>

              ) : (

                <button
                  type="button"
                  onClick={() =>
                    setProfileOpen(
                      (previous) => !previous
                    )
                  }
                  aria-label="Open profile"
                  className="
                    flex
                    h-9
                    w-9
                    items-center
                    justify-center
                    overflow-hidden
                    rounded-full
                    border-2
                    border-sky-500
                    bg-sky-50
                    shadow-sm
                    transition
                    hover:ring-4
                    hover:ring-sky-100

                    sm:h-11
                    sm:w-11
                  "
                >

                  <img
                    src={profileImage}
                    alt={
                      customerInfo?.name ||
                      "Customer"
                    }
                    className="
                      h-full
                      w-full
                      object-cover
                    "
                  />

                </button>

              )}

              {customerInfo &&
                profileOpen && (
                  <ProfileDropdown
                    customer={customerInfo}
                    wishlistCount={
                      wishlist.length
                    }
                    onClose={() =>
                      setProfileOpen(false)
                    }
                    onLogout={
                      handleLogout
                    }
                  />
                )}

            </div>

          </div>


          {/* =================================================
              MOBILE + TABLET NAVIGATION
              < 1024px
          ================================================= */}

          <div
            className="
              block
              w-full
              pb-2

              lg:hidden
            "
          >

            <nav
              className="
                flex
                w-full
                items-center
                gap-1.5
                overflow-x-auto
                overflow-y-hidden
                pb-1

                scrollbar-hide

                sm:justify-center
                sm:gap-2
              "
            >

              <NavLink
                to="/"
                className={navClass}
              >
                Home
              </NavLink>

              <NavLink
                to="/about"
                className={navClass}
              >
                About
              </NavLink>

              <NavLink
                to="/properties"
                className={navClass}
              >
                Properties
              </NavLink>

              <NavLink
                to="/services"
                className={navClass}
              >
                Services
              </NavLink>

              <NavLink
                to="/contact"
                className={navClass}
              >
                Contact
              </NavLink>

            </nav>

          </div>

        </div>

      </header>
    </>
  );
};


/*
|--------------------------------------------------------------------------
| PROFILE DROPDOWN
|--------------------------------------------------------------------------
*/

const ProfileDropdown = ({
  customer,
  wishlistCount,
  onClose,
  onLogout,
}) => {

  return (
    <div
      className="
        absolute
        right-0
        top-[calc(100%+10px)]
        z-[200]

        w-[280px]
        max-w-[calc(100vw-24px)]

        overflow-hidden
        rounded-2xl
        border
        border-gray-100
        bg-white
        shadow-2xl
      "
    >

      {/* ==================================================
          PROFILE HEADER
      =================================================== */}

      <div
        className="
          bg-gradient-to-r
          from-sky-500
          to-blue-500
          px-5
          py-4
          text-white
        "
      >

        <div
          className="
            flex
            items-center
            gap-3
          "
        >

          <div
            className="
              flex
              h-10
              w-10
              shrink-0
              items-center
              justify-center
              rounded-full
              bg-white/20
              text-sm
              font-bold
            "
          >
            {customer?.name
              ?.charAt(0)
              ?.toUpperCase() || "C"}
          </div>

          <div className="min-w-0">

            <p className="truncate font-semibold">
              {customer?.name || "Customer"}
            </p>

            <p
              className="
                mt-0.5
                truncate
                text-xs
                text-sky-100
              "
            >
              {customer?.email || ""}
            </p>

          </div>

        </div>

      </div>


      {/* ==================================================
          PROFILE LINKS
      =================================================== */}

      <div className="p-2">

        <ProfileLink
          to="/profile"
          icon={
            <FaUser className="text-sky-500" />
          }
          label="My Profile"
          onClick={onClose}
        />


        <ProfileLink
          to="/wishlist"
          icon={
            <FaHeart className="text-red-500" />
          }
          label="Wishlist"
          badge={
            wishlistCount > 0
              ? wishlistCount
              : null
          }
          onClick={onClose}
        />


        <ProfileLink
          to="/properties"
          icon={
            <FaBuilding className="text-sky-500" />
          }
          label="Browse Properties"
          onClick={onClose}
        />


        <div
          className="
            my-2
            h-px
            bg-gray-100
          "
        />


        <button
          type="button"
          onClick={onLogout}
          className="
            flex
            w-full
            items-center
            gap-3
            rounded-xl
            px-4
            py-3
            text-left
            text-sm
            text-red-500
            transition
            hover:bg-red-50
          "
        >

          <FaSignOutAlt />

          Logout

        </button>

      </div>

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| PROFILE LINK
|--------------------------------------------------------------------------
*/

const ProfileLink = ({
  to,
  icon,
  label,
  badge,
  onClick,
}) => {

  return (
    <Link
      to={to}
      onClick={onClick}
      className="
        flex
        items-center
        justify-between
        rounded-xl
        px-4
        py-3
        text-sm
        text-gray-700
        transition
        hover:bg-sky-50
      "
    >

      <span
        className="
          flex
          min-w-0
          items-center
          gap-3
        "
      >

        <span className="shrink-0">
          {icon}
        </span>

        <span className="truncate">
          {label}
        </span>

      </span>


      <span
        className="
          flex
          shrink-0
          items-center
          gap-2
        "
      >

        {badge && (
          <span
            className="
              flex
              h-5
              min-w-5
              items-center
              justify-center
              rounded-full
              bg-red-500
              px-1
              text-[9px]
              font-bold
              text-white
            "
          >
            {badge > 99 ? "99+" : badge}
          </span>
        )}


        <FaChevronRight
          className="
            text-[9px]
            text-gray-300
          "
        />

      </span>

    </Link>
  );
};


export default Navbar;