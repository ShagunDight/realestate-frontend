import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

const WishlistContext =
  createContext(null);


const STORAGE_KEY =
  "wishlist";


/*
|--------------------------------------------------------------------------
| GET PROPERTY ID
|--------------------------------------------------------------------------
*/

const getPropertyId = (
  item
) => {
  if (!item) {
    return null;
  }

  return (
    item?._id ||
    item?.id ||
    null
  );
};


/*
|--------------------------------------------------------------------------
| PROVIDER
|--------------------------------------------------------------------------
*/

export const WishlistProvider = ({
  children,
}) => {

  const [
    wishlist,
    setWishlist,
  ] = useState(() => {

    try {

      const saved =
        localStorage.getItem(
          STORAGE_KEY
        );

      if (!saved) {
        return [];
      }

      const parsed =
        JSON.parse(saved);

      return Array.isArray(
        parsed
      )
        ? parsed
        : [];

    } catch (error) {

      console.error(
        "Wishlist localStorage error:",
        error
      );

      return [];
    }

  });


  /*
  |--------------------------------------------------------------------------
  | SAVE WISHLIST
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    try {

      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(
          wishlist
        )
      );

    } catch (error) {

      console.error(
        "Unable to save wishlist:",
        error
      );

    }

  }, [
    wishlist,
  ]);


  /*
  |--------------------------------------------------------------------------
  | TOGGLE WISHLIST
  |--------------------------------------------------------------------------
  */

  const toggleWishlist =
    (item) => {

      const propertyId =
        getPropertyId(item);

      if (!propertyId) {
        console.warn(
          "Wishlist item has no valid ID:",
          item
        );

        return;
      }


      setWishlist(
        (previous) => {

          const exists =
            previous.some(
              (property) =>
                String(
                  getPropertyId(
                    property
                  )
                ) ===
                String(
                  propertyId
                )
            );


          if (exists) {

            return previous.filter(
              (property) =>
                String(
                  getPropertyId(
                    property
                  )
                ) !==
                String(
                  propertyId
                )
            );

          }


          return [
            ...previous,
            item,
          ];

        }
      );

    };


  /*
  |--------------------------------------------------------------------------
  | CHECK WISHLIST
  |--------------------------------------------------------------------------
  */

  const isWished =
    (id) => {

      if (!id) {
        return false;
      }

      return wishlist.some(
        (property) =>
          String(
            getPropertyId(
              property
            )
          ) ===
          String(id)
      );

    };


  /*
  |--------------------------------------------------------------------------
  | REMOVE ITEM
  |--------------------------------------------------------------------------
  */

  const removeFromWishlist =
    (id) => {

      if (!id) {
        return;
      }

      setWishlist(
        (previous) =>
          previous.filter(
            (property) =>
              String(
                getPropertyId(
                  property
                )
              ) !==
              String(id)
          )
      );

    };


  /*
  |--------------------------------------------------------------------------
  | CLEAR WISHLIST
  |--------------------------------------------------------------------------
  */

  const clearWishlist =
    () => {

      setWishlist([]);

    };


  /*
  |--------------------------------------------------------------------------
  | COUNT
  |--------------------------------------------------------------------------
  */

  const wishlistCount =
    useMemo(
      () =>
        wishlist.length,
      [wishlist]
    );


  /*
  |--------------------------------------------------------------------------
  | CONTEXT VALUE
  |--------------------------------------------------------------------------
  */

  const value = {
    wishlist,
    wishlistCount,
    toggleWishlist,
    isWished,
    removeFromWishlist,
    clearWishlist,
  };


  return (
    <WishlistContext.Provider
      value={value}
    >
      {children}
    </WishlistContext.Provider>
  );
};


/*
|--------------------------------------------------------------------------
| HOOK
|--------------------------------------------------------------------------
*/

export const useWishlist =
  () => {

    const context =
      useContext(
        WishlistContext
      );

    if (!context) {

      throw new Error(
        "useWishlist must be used inside WishlistProvider"
      );

    }

    return context;

  };