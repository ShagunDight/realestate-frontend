import React, {
  useEffect,
  useState,
} from "react";

import {
  FiX,
  FiChevronDown,
  FiChevronLeft,
  FiSearch,
  FiRefreshCw,
  FiMapPin,
  FiSliders,
} from "react-icons/fi";


const FilterModal = ({
  filters = {},
  setFilters = () => {},
  onClose = () => {},
  onSearch = () => {},
}) => {

  const [activeTab, setActiveTab] =
    useState("sale");

  const [types, setTypes] =
    useState([]);

  const [openGroups, setOpenGroups] =
    useState({});

  const [spaceUses, setSpaceUses] =
    useState([]);

  const [locations, setLocations] =
    useState([]);

  const [additionalFilters, setAdditionalFilters] =
    useState([]);

  const [columns, setColumns] =
    useState([]);

  const [loading, setLoading] =
    useState(false);

  const [loadingAdditional, setLoadingAdditional] =
    useState(false);


  /*
  |--------------------------------------------------------------------------
  | FETCH PROPERTY TYPES
  |--------------------------------------------------------------------------
  */

  const fetchTypes = async () => {

    try {

      const response =
        await fetch(
          "https://lightblue-moose-690494.hostingersite.com/api/property-types"
        );

      if (!response.ok) {
        throw new Error(
          "Failed to fetch property types"
        );
      }

      const data =
        await response.json();

      const finalTypes =
        data?.data || [];

      setTypes(finalTypes);

      if (
        finalTypes.length > 0 &&
        !filters?.type
      ) {

        const firstType =
          finalTypes[0];

        const firstId =
          firstType?._id ||
          firstType?.id;

        setFilters({
          ...filters,
          type: firstId,
          type_name:
            firstType?.name || "",
          space_use: [],
          space_use_id: [],
        });

        fetchSpaceUses(firstId);
      }

    } catch (error) {

      console.error(
        "Property Types Error:",
        error
      );

      setTypes([]);

    }

  };


  /*
  |--------------------------------------------------------------------------
  | BUILD TREE
  |--------------------------------------------------------------------------
  */

  const buildTree = (data) => {

    const map = {};
    const roots = [];

    data.forEach((item) => {

      const id =
        item?._id ||
        item?.id;

      map[id] = {
        ...item,
        id,
        children: [],
      };

    });


    data.forEach((item) => {

      const id =
        item?._id ||
        item?.id;

      const parent =
        item?.parent_id;


      if (
        parent &&
        map[parent]
      ) {

        map[parent].children.push(
          map[id]
        );

      } else {

        roots.push(
          map[id]
        );

      }

    });

    return roots;
  };


  /*
  |--------------------------------------------------------------------------
  | FETCH SPACE USES
  |--------------------------------------------------------------------------
  */

  const fetchSpaceUses = async (
    typeId
  ) => {

    if (!typeId) {

      setSpaceUses([]);

      return;

    }

    try {

      setLoading(true);

      const response =
        await fetch(
          `https://lightblue-moose-690494.hostingersite.com/api/space-uses?type_id=${typeId}`
        );

      if (!response.ok) {
        throw new Error(
          "Failed to fetch space uses"
        );
      }

      const data =
        await response.json();

      setSpaceUses(
        buildTree(
          data?.data || []
        )
      );

      setOpenGroups({});

    } catch (error) {

      console.error(
        "Space Uses Error:",
        error
      );

      setSpaceUses([]);

    } finally {

      setLoading(false);

    }

  };


  /*
  |--------------------------------------------------------------------------
  | CHILD IDS
  |--------------------------------------------------------------------------
  */

  const getAllChildIds = (item) => {

    let ids = [];

    item?.children?.forEach(
      (child) => {

        ids.push(child.id);

        if (
          child?.children?.length
        ) {

          ids = ids.concat(
            getAllChildIds(child)
          );

        }

      }
    );

    return ids;
  };


  /*
  |--------------------------------------------------------------------------
  | TOGGLE SPACE USE
  |--------------------------------------------------------------------------
  */

  const toggleNode = (
    node,
    checked
  ) => {

    let parentIds =
      Array.isArray(
        filters?.space_use
      )
        ? [...filters.space_use]
        : [];

    let childIds =
      Array.isArray(
        filters?.space_use_id
      )
        ? [...filters.space_use_id]
        : [];


    const hasChildren =
      node?.children?.length > 0;


    if (hasChildren) {

      const allChildIds =
        getAllChildIds(node);


      if (checked) {

        if (
          !parentIds.includes(
            node.id
          )
        ) {

          parentIds.push(
            node.id
          );

        }


        allChildIds.forEach(
          (id) => {

            if (
              !childIds.includes(id)
            ) {

              childIds.push(id);

            }

          }
        );

      } else {

        parentIds =
          parentIds.filter(
            (id) =>
              id !== node.id
          );

        childIds =
          childIds.filter(
            (id) =>
              !allChildIds.includes(id)
          );

      }

    } else {

      if (checked) {

        if (
          !parentIds.includes(
            node.id
          )
        ) {

          parentIds.push(
            node.id
          );

        }

      } else {

        parentIds =
          parentIds.filter(
            (id) =>
              id !== node.id
          );

      }

    }


    setFilters({
      ...filters,
      space_use: parentIds,
      space_use_id: childIds,
    });

  };


  /*
  |--------------------------------------------------------------------------
  | RENDER TREE
  |--------------------------------------------------------------------------
  */

  const renderTree = (items) => {

    return items.map(
      (item) => {

        const id =
          item.id;

        const hasChildren =
          item?.children?.length > 0;

        const isOpen =
          !!openGroups[id];

        const isChecked =
          (
            filters?.space_use ||
            []
          ).includes(id);


        return (
          <div
            key={id}
            className="
              border-b
              border-gray-100
              last:border-b-0
            "
          >

            {/* PARENT */}

            <div
              className="
                flex
                items-center
                justify-between
                gap-3
                rounded-xl
                px-2
                py-2.5
              "
            >

              <label
                className="
                  flex
                  min-w-0
                  flex-1
                  cursor-pointer
                  items-center
                  gap-3
                "
              >

                <input
                  type="checkbox"
                  checked={
                    isChecked
                  }
                  onChange={(e) =>
                    toggleNode(
                      item,
                      e.target.checked
                    )
                  }
                  className="
                    h-4
                    w-4
                    shrink-0
                    rounded
                    border-gray-300
                    accent-sky-500
                  "
                />

                <span
                  className="
                    truncate
                    text-sm
                    font-medium
                    text-gray-700
                  "
                >
                  {item.name}
                </span>

              </label>


              {hasChildren && (
                <button
                  type="button"
                  onClick={() =>
                    setOpenGroups(
                      (prev) => ({
                        ...prev,
                        [id]:
                          !prev[id],
                      })
                    )
                  }
                  className="
                    flex
                    h-8
                    w-8
                    shrink-0
                    items-center
                    justify-center
                    rounded-lg
                    text-gray-500
                    transition
                    hover:bg-sky-50
                    hover:text-sky-500
                  "
                >
                  <FiChevronDown
                    className={`
                      transition-transform
                      ${
                        isOpen
                          ? "rotate-180"
                          : ""
                      }
                    `}
                  />
                </button>
              )}

            </div>


            {/* CHILDREN */}

            {isOpen &&
              hasChildren && (

                <div
                  className="
                    mb-2
                    ml-5
                    space-y-1
                    border-l-2
                    border-sky-100
                    pl-3
                  "
                >

                  {item.children.map(
                    (child) => {

                      const checked =
                        (
                          filters?.space_use_id ||
                          []
                        ).includes(
                          child.id
                        );


                      return (
                        <label
                          key={child.id}
                          className="
                            flex
                            cursor-pointer
                            items-center
                            gap-2.5
                            rounded-lg
                            px-2
                            py-2
                            text-sm
                            text-gray-600
                            transition
                            hover:bg-sky-50
                          "
                        >

                          <input
                            type="checkbox"
                            checked={
                              checked
                            }
                            onChange={(e) =>
                              toggleNode(
                                child,
                                e.target.checked
                              )
                            }
                            className="
                              h-4
                              w-4
                              rounded
                              border-gray-300
                              accent-sky-500
                            "
                          />

                          <span>
                            {child.name}
                          </span>

                        </label>
                      );

                    }
                  )}

                </div>

              )}

          </div>
        );

      }
    );

  };


  /*
  |--------------------------------------------------------------------------
  | FETCH LOCATIONS
  |--------------------------------------------------------------------------
  */

  const fetchLocations = async () => {

    try {

      const response =
        await fetch(
          "https://lightblue-moose-690494.hostingersite.com/api/locations"
        );

      if (!response.ok) {
        throw new Error(
          "Failed to fetch locations"
        );
      }

      const data =
        await response.json();

      setLocations(
        data?.data || []
      );

    } catch (error) {

      console.error(
        "Locations Error:",
        error
      );

      setLocations([]);

    }

  };


  /*
  |--------------------------------------------------------------------------
  | FETCH ADDITIONAL FILTERS
  |--------------------------------------------------------------------------
  */

  const fetchAdditionalFilters = async (
    typeId,
    spaceUseIds
  ) => {

    if (
      !typeId ||
      !spaceUseIds
    ) {

      setAdditionalFilters([]);

      return;

    }


    try {

      setLoadingAdditional(
        true
      );

      const response =
        await fetch(
          `https://lightblue-moose-690494.hostingersite.comapi/filters?type_id=${typeId}&space_use_id=${spaceUseIds}`
        );

      if (!response.ok) {
        throw new Error(
          "Failed to fetch additional filters"
        );
      }

      const data =
        await response.json();

      setAdditionalFilters(
        data?.data || []
      );

    } catch (error) {

      console.error(
        "Additional Filters Error:",
        error
      );

      setAdditionalFilters([]);

    } finally {

      setLoadingAdditional(
        false
      );

    }

  };


  /*
  |--------------------------------------------------------------------------
  | FETCH PROPERTY COLUMNS
  |--------------------------------------------------------------------------
  */

  const fetchColumns = async () => {

    try {

      const response =
        await fetch(
          "https://lightblue-moose-690494.hostingersite.com/api/property-columns"
        );

      if (!response.ok) {
        throw new Error(
          "Failed to fetch property columns"
        );
      }

      const data =
        await response.json();

      if (data?.status) {

        setColumns(
          data?.data || []
        );

      }

    } catch (error) {

      console.error(
        "Property Columns Error:",
        error
      );

      setColumns([]);

    }

  };


  /*
  |--------------------------------------------------------------------------
  | INITIAL LOAD
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    fetchTypes();
    fetchLocations();
    fetchColumns();

  }, []);


  /*
  |--------------------------------------------------------------------------
  | TYPE CHANGE
  |--------------------------------------------------------------------------
  */

  const handleTypeChange = (
    id,
    name = ""
  ) => {

    setFilters({
      ...filters,
      type: id,
      type_name: name,
      space_use: [],
      space_use_id: [],
    });

    setAdditionalFilters([]);

    fetchSpaceUses(id);

  };


  /*
  |--------------------------------------------------------------------------
  | SPACE USE CHANGE
  |--------------------------------------------------------------------------
  */

  const handleSpaceUse =
    (id) => {

      const currentSelected =
        filters?.space_use_id ||
        [];

      let updatedSelected;


      if (
        currentSelected.includes(id)
      ) {

        updatedSelected =
          currentSelected.filter(
            (value) =>
              value !== id
          );

      } else {

        updatedSelected = [
          ...currentSelected,
          id,
        ];

      }


      const updatedFilters = {
        ...filters,
        space_use_id:
          updatedSelected,
      };


      setFilters(
        updatedFilters
      );


      if (
        updatedSelected.length > 0
      ) {

        fetchAdditionalFilters(
          updatedFilters.type,
          updatedSelected.join(",")
        );

      } else {

        setAdditionalFilters([]);

      }

    };


  /*
  |--------------------------------------------------------------------------
  | HANDLE CHANGE
  |--------------------------------------------------------------------------
  */

  const handleChange = (
    name,
    value
  ) => {

    setFilters({
      ...filters,
      [name]: value,
    });

  };


  /*
  |--------------------------------------------------------------------------
  | CLEAR
  |--------------------------------------------------------------------------
  */

  const handleClear = () => {

    const clearedFilters = {
      location: "",
      latitude: "",
      longitude: "",
      location_selected:
        false,

      type: "",
      type_name: "",

      space_use: [],
      space_use_id: [],

      listing_type: "",

      min_price: "",
      max_price: "",

      land_size_min: "",
      land_size_max: "",

      building_min_size: "",
      building_max_size: "",

      building_size_min: "",
      building_size_max: "",

      year_built_min: "",
      year_built_max: "",
    };


    setFilters(
      clearedFilters
    );

    setAdditionalFilters([]);

    setOpenGroups({});

  };


  /*
  |--------------------------------------------------------------------------
  | SEARCH
  |--------------------------------------------------------------------------
  */

  const handleSearch = () => {

    onSearch({
      ...filters,
      listing_type:
        activeTab,
    });

    onClose();

  };


  /*
  |--------------------------------------------------------------------------
  | BODY SCROLL LOCK
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    document.body.style.overflow =
      "hidden";

    return () => {
      document.body.style.overflow =
        "";
    };

  }, []);


  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <div
      className="
        fixed
        inset-0
        z-[200]
        flex
        items-end
        justify-center
        bg-black/50
        backdrop-blur-[2px]
        sm:items-center
        sm:p-4
      "
    >

      {/* =====================================================
          MODAL
      ====================================================== */}

      <div
        className="
          flex
          h-[92vh]
          w-full
          flex-col
          overflow-hidden
          rounded-t-[28px]
          bg-white
          shadow-2xl
          sm:h-auto
          sm:max-h-[92vh]
          sm:max-w-5xl
          sm:rounded-[24px]
          lg:max-w-6xl
        "
      >

        {/* ===================================================
            HEADER
        ==================================================== */}

        <div
          className="
            flex
            shrink-0
            items-center
            justify-between
            border-b
            border-gray-100
            bg-white
            px-4
            py-4
            sm:px-6
            sm:py-5
          "
        >

          <div
            className="
              flex
              min-w-0
              items-center
              gap-3
            "
          >

            {/* BACK ON MOBILE */}

            <button
              type="button"
              onClick={onClose}
              className="
                flex
                h-9
                w-9
                shrink-0
                items-center
                justify-center
                rounded-full
                bg-gray-100
                text-gray-600
                transition
                hover:bg-sky-100
                hover:text-sky-500
                sm:hidden
              "
              aria-label="Close filters"
            >
              <FiChevronLeft />
            </button>


            <div>

              <p
                className="
                  text-[10px]
                  font-bold
                  uppercase
                  tracking-[0.15em]
                  text-sky-500
                "
              >
                Refine Search
              </p>

              <h2
                className="
                  mt-0.5
                  truncate
                  text-lg
                  font-bold
                  text-gray-900
                  sm:text-xl
                "
              >
                All Filters
              </h2>

            </div>

          </div>


          {/* CLOSE */}

          <button
            type="button"
            onClick={onClose}
            aria-label="Close filter modal"
            className="
              flex
              h-10
              w-10
              shrink-0
              items-center
              justify-center
              rounded-full
              bg-gray-100
              text-gray-600
              transition
              hover:bg-red-50
              hover:text-red-500
            "
          >
            <FiX />
          </button>

        </div>


        {/* ===================================================
            CONTENT
        ==================================================== */}

        <div
          className="
            flex-1
            overflow-y-auto
            overscroll-contain
            bg-gray-50/60
            px-4
            py-4
            sm:px-6
            sm:py-5
          "
        >

          {/* =================================================
              PROPERTY TYPES
          ================================================== */}

          <section
            className="
              mb-5
              rounded-2xl
              border
              border-gray-100
              bg-white
              p-4
              shadow-sm
              sm:p-5
            "
          >

            <div className="mb-3">

              <div className="flex items-center gap-2">

                <FiSliders
                  className="text-sky-500"
                />

                <h3
                  className="
                    text-sm
                    font-bold
                    text-gray-900
                    sm:text-base
                  "
                >
                  Property Type
                </h3>

              </div>

              <p
                className="
                  mt-1
                  text-[11px]
                  text-gray-400
                  sm:text-xs
                "
              >
                Select the type of property you are looking for.
              </p>

            </div>


            {/* TYPE TABS */}

            <div
              className="
                flex
                gap-2
                overflow-x-auto
                pb-1
                scrollbar-hide
              "
            >

              {types.map((item) => {

                const id =
                  item?._id ||
                  item?.id;

                const active =
                  filters?.type === id;


                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() =>
                      handleTypeChange(
                        id,
                        item?.name || ""
                      )
                    }
                    className={`
                      shrink-0
                      rounded-xl
                      border
                      px-4
                      py-2.5
                      text-xs
                      font-semibold
                      transition-all
                      duration-200
                      sm:text-sm

                      ${
                        active
                          ? "border-sky-500 bg-sky-500 text-white shadow-sm"
                          : "border-gray-200 bg-white text-gray-600 hover:border-sky-200 hover:bg-sky-50 hover:text-sky-600"
                      }
                    `}
                  >
                    {item.name}
                  </button>
                );

              })}

            </div>
          </section>


          {/* =================================================
              MAIN FILTER LAYOUT
          ================================================== */}

          <div
            className="
              grid
              grid-cols-1
              gap-5
              lg:grid-cols-3
            "
          >

            {/* =================================================
                LEFT FILTERS
            ================================================== */}

            <div className="space-y-5">

              {/* SPACE USE */}

              <section
                className="
                  rounded-2xl
                  border
                  border-gray-100
                  bg-white
                  p-4
                  shadow-sm
                  sm:p-5
                "
              >

                <div className="mb-3">

                  <h3
                    className="
                      text-sm
                      font-bold
                      text-gray-900
                      sm:text-base
                    "
                  >
                    Space Uses
                  </h3>

                  <p
                    className="
                      mt-1
                      text-[11px]
                      text-gray-400
                      sm:text-xs
                    "
                  >
                    Choose one or more suitable spaces.
                  </p>

                </div>


                <div
                  className="
                    max-h-[280px]
                    overflow-y-auto
                    rounded-xl
                    border
                    border-gray-100
                    p-2
                    sm:max-h-[340px]
                  "
                >

                  {loading ? (

                    <div
                      className="
                        flex
                        items-center
                        justify-center
                        py-8
                      "
                    >

                      <div
                        className="
                          h-6
                          w-6
                          animate-spin
                          rounded-full
                          border-2
                          border-gray-200
                          border-t-sky-500
                        "
                      />

                    </div>

                  ) : spaceUses.length ===
                    0 ? (

                    <p
                      className="
                        px-3
                        py-7
                        text-center
                        text-xs
                        text-gray-400
                      "
                    >
                      No space uses available.
                    </p>

                  ) : (

                    renderTree(
                      spaceUses
                    )

                  )}

                </div>

              </section>


              {/* LOCATION */}

              <section
                className="
                  rounded-2xl
                  border
                  border-gray-100
                  bg-white
                  p-4
                  shadow-sm
                  sm:p-5
                "
              >

                <div className="mb-3 flex items-center gap-2">

                  <FiMapPin
                    className="text-sky-500"
                  />

                  <h3
                    className="
                      text-sm
                      font-bold
                      text-gray-900
                      sm:text-base
                    "
                  >
                    Location
                  </h3>

                </div>


                <div className="relative">

                  <select
                    value={
                      filters?.location ||
                      ""
                    }
                    onChange={(e) =>
                      handleChange(
                        "location",
                        e.target.value
                      )
                    }
                    className="
                      h-12
                      w-full
                      appearance-none
                      rounded-xl
                      border
                      border-gray-200
                      bg-white
                      px-4
                      pr-10
                      text-sm
                      text-gray-700
                      outline-none
                      transition
                      focus:border-sky-400
                      focus:ring-2
                      focus:ring-sky-100
                    "
                  >

                    <option value="">
                      Select Location
                    </option>

                    {locations.map(
                      (location, index) => (
                        <option
                          key={index}
                          value={location}
                        >
                          {location}
                        </option>
                      )
                    )}

                  </select>


                  <FiChevronDown
                    className="
                      pointer-events-none
                      absolute
                      right-4
                      top-1/2
                      -translate-y-1/2
                      text-gray-400
                    "
                  />

                </div>

              </section>


              {/* ADDITIONAL FILTERS */}

              <section
                className="
                  rounded-2xl
                  border
                  border-gray-100
                  bg-white
                  p-4
                  shadow-sm
                  sm:p-5
                "
              >

                <div className="mb-4">

                  <h3
                    className="
                      text-sm
                      font-bold
                      text-gray-900
                      sm:text-base
                    "
                  >
                    Additional Filters
                  </h3>

                  <p
                    className="
                      mt-1
                      text-[11px]
                      text-gray-400
                      sm:text-xs
                    "
                  >
                    Extra options based on your selections.
                  </p>

                </div>


                {loadingAdditional ? (

                  <div
                    className="
                      flex
                      items-center
                      justify-center
                      py-8
                    "
                  >

                    <div
                      className="
                        h-6
                        w-6
                        animate-spin
                        rounded-full
                        border-2
                        border-gray-200
                        border-t-sky-500
                      "
                    />

                  </div>

                ) : additionalFilters.length ===
                  0 ? (

                  <p
                    className="
                      rounded-xl
                      bg-gray-50
                      px-4
                      py-6
                      text-center
                      text-xs
                      text-gray-400
                    "
                  >
                    Select a space use to see additional filters.
                  </p>

                ) : (

                  <div
                    className="
                      grid
                      grid-cols-1
                      gap-4
                      sm:grid-cols-2
                    "
                  >

                    {additionalFilters.map(
                      (item) => (

                        <DynamicAdditionalFilter
                          key={
                            item.id ||
                            item.name
                          }
                          item={item}
                          filters={filters}
                          handleChange={
                            handleChange
                          }
                        />

                      )
                    )}

                  </div>

                )}

              </section>

            </div>


            {/* =================================================
                PROPERTY FILTERS
            ================================================== */}

            <section
              className="
                rounded-2xl
                border
                border-gray-100
                bg-white
                p-4
                shadow-sm
                sm:p-5
                lg:col-span-2
              "
            >

              <div className="mb-4">

                <h3
                  className="
                    text-sm
                    font-bold
                    text-gray-900
                    sm:text-base
                  "
                >
                  Property Filters
                </h3>

                <p
                  className="
                    mt-1
                    text-[11px]
                    text-gray-400
                    sm:text-xs
                  "
                >
                  Fine-tune your property search.
                </p>

              </div>


              {columns &&
              Object.keys(columns).length >
                0 ? (

                <div
                  className="
                    grid
                    grid-cols-1
                    gap-4
                    sm:grid-cols-2
                  "
                >

                  {Object.entries(
                    columns
                  ).map(
                    ([key, item]) => (

                      <DynamicPropertyFilter
                        key={key}
                        filterKey={key}
                        item={item}
                        filters={filters}
                        handleChange={
                          handleChange
                        }
                      />

                    )
                  )}

                </div>

              ) : (

                <div
                  className="
                    rounded-xl
                    bg-gray-50
                    px-4
                    py-8
                    text-center
                    text-xs
                    text-gray-400
                  "
                >
                  No property filters available.
                </div>

              )}

            </section>

          </div>

        </div>


        {/* ===================================================
            FOOTER
        ==================================================== */}

        <div
          className="
            flex
            shrink-0
            flex-col
            gap-2
            border-t
            border-gray-100
            bg-white
            p-3
            sm:flex-row
            sm:items-center
            sm:justify-end
            sm:gap-3
            sm:p-4
          "
        >

          {/* CLEAR */}

          <button
            type="button"
            onClick={
              handleClear
            }
            className="
              flex
              min-h-12
              w-full
              items-center
              justify-center
              gap-2
              rounded-xl
              border
              border-gray-200
              bg-gray-50
              px-5
              py-3
              text-sm
              font-semibold
              text-gray-700
              transition
              hover:bg-gray-100
              active:scale-[0.98]
              sm:w-auto
            "
          >
            <FiRefreshCw />

            Clear
          </button>


          {/* SEARCH */}

          <button
            type="button"
            onClick={
              handleSearch
            }
            className="
              flex
              min-h-12
              w-full
              items-center
              justify-center
              gap-2
              rounded-xl
              bg-sky-500
              px-6
              py-3
              text-sm
              font-semibold
              text-white
              shadow-md
              shadow-sky-500/20
              transition-all
              hover:bg-sky-600
              hover:shadow-lg
              active:scale-[0.98]
              sm:w-auto
            "
          >
            <FiSearch />

            Search Properties
          </button>

        </div>

      </div>
    </div>
  );
};


/*
|--------------------------------------------------------------------------
| ADDITIONAL FILTER COMPONENT
|--------------------------------------------------------------------------
*/

const DynamicAdditionalFilter = ({
  item,
  filters,
  handleChange,
}) => {

  const value =
    filters?.[item.name];


  return (
    <div>

      <label
        className="
          mb-1.5
          block
          text-xs
          font-semibold
          text-gray-700
          sm:text-sm
        "
      >
        {item.name}
      </label>


      {/* TEXT */}

      {item.field_type ===
        "text" && (

        <input
          type="text"
          value={
            value || ""
          }
          onChange={(e) =>
            handleChange(
              item.name,
              e.target.value
            )
          }
          className="
            h-11
            w-full
            rounded-xl
            border
            border-gray-200
            px-3
            text-sm
            outline-none
            transition
            focus:border-sky-400
            focus:ring-2
            focus:ring-sky-100
          "
        />

      )}


      {/* SELECT */}

      {(
        item.field_type ===
          "select" ||
        item.field_type ===
          "single_select"
      ) && (

        <div className="relative">

          <select
            value={
              value || ""
            }
            onChange={(e) =>
              handleChange(
                item.name,
                e.target.value
              )
            }
            className="
              h-11
              w-full
              appearance-none
              rounded-xl
              border
              border-gray-200
              bg-white
              px-3
              pr-9
              text-sm
              outline-none
              focus:border-sky-400
              focus:ring-2
              focus:ring-sky-100
            "
          >

            <option value="">
              Select
            </option>

            {item.options?.map(
              (option, index) => (
                <option
                  key={index}
                  value={option}
                >
                  {option}
                </option>
              )
            )}

          </select>


          <FiChevronDown
            className="
              pointer-events-none
              absolute
              right-3
              top-1/2
              -translate-y-1/2
              text-gray-400
            "
          />

        </div>

      )}


      {/* MULTI SELECT */}

      {item.field_type ===
        "multi_select" && (

        <div
          className="
            flex
            flex-wrap
            gap-2
          "
        >

          {item.options?.map(
            (option, index) => {

              const checked =
                (
                  value || []
                ).includes(
                  option
                );


              return (
                <label
                  key={index}
                  className={`
                    inline-flex
                    cursor-pointer
                    items-center
                    gap-2
                    rounded-lg
                    border
                    px-3
                    py-2
                    text-xs
                    transition

                    ${
                      checked
                        ? "border-sky-500 bg-sky-50 text-sky-600"
                        : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                    }
                  `}
                >

                  <input
                    type="checkbox"
                    value={option}
                    checked={checked}
                    onChange={(e) => {

                      let updated =
                        value || [];

                      if (
                        e.target
                          .checked
                      ) {

                        updated = [
                          ...updated,
                          option,
                        ];

                      } else {

                        updated =
                          updated.filter(
                            (entry) =>
                              entry !==
                              option
                          );

                      }

                      handleChange(
                        item.name,
                        updated
                      );

                    }}
                    className="
                      h-3.5
                      w-3.5
                      accent-sky-500
                    "
                  />

                  {option}

                </label>
              );

            }
          )}

        </div>

      )}

    </div>
  );
};


/*
|--------------------------------------------------------------------------
| PROPERTY FILTER COMPONENT
|--------------------------------------------------------------------------
*/

const DynamicPropertyFilter = ({
  filterKey,
  item,
  filters,
  handleChange,
}) => {

  const value =
    filters?.[filterKey];


  const label =
    item?.label ||
    item ||
    filterKey;


  /*
  |--------------------------------------------------------------------------
  | TEXT
  |--------------------------------------------------------------------------
  */

  if (
    !item?.type ||
    item?.type ===
      "text"
  ) {

    return (
      <div>

        <label
          className="
            mb-1.5
            block
            text-xs
            font-semibold
            text-gray-700
            sm:text-sm
          "
        >
          {label}
        </label>

        <input
          type="text"
          value={
            value || ""
          }
          onChange={(e) =>
            handleChange(
              filterKey,
              e.target.value
            )
          }
          className="
            h-11
            w-full
            rounded-xl
            border
            border-gray-200
            px-3
            text-sm
            outline-none
            focus:border-sky-400
            focus:ring-2
            focus:ring-sky-100
          "
        />

      </div>
    );
  }


  /*
  |--------------------------------------------------------------------------
  | NUMBER
  |--------------------------------------------------------------------------
  */

  if (
    item.type ===
    "number"
  ) {

    return (
      <div>

        <label
          className="
            mb-1.5
            block
            text-xs
            font-semibold
            text-gray-700
            sm:text-sm
          "
        >
          {label}
        </label>

        <input
          type="number"
          inputMode="numeric"
          value={
            value || ""
          }
          onChange={(e) =>
            handleChange(
              filterKey,
              e.target.value
            )
          }
          className="
            h-11
            w-full
            rounded-xl
            border
            border-gray-200
            px-3
            text-sm
            outline-none
            focus:border-sky-400
            focus:ring-2
            focus:ring-sky-100
          "
        />

      </div>
    );
  }


  /*
  |--------------------------------------------------------------------------
  | RADIO
  |--------------------------------------------------------------------------
  */

  if (
    item.type ===
    "radio"
  ) {

    return (
      <div>

        <label
          className="
            mb-2
            block
            text-xs
            font-semibold
            text-gray-700
            sm:text-sm
          "
        >
          {label}
        </label>


        <div
          className="
            flex
            flex-wrap
            gap-2
          "
        >

          {item.options?.map(
            (option, index) => {

              const value =
                option?.value ??
                option;

              const optionLabel =
                option?.label ??
                option;

              const checked =
                String(
                  filters?.[
                    filterKey
                  ] || ""
                ) ===
                String(value);


              return (
                <label
                  key={index}
                  className={`
                    inline-flex
                    cursor-pointer
                    items-center
                    gap-2
                    rounded-xl
                    border
                    px-3
                    py-2.5
                    text-xs
                    transition

                    ${
                      checked
                        ? "border-sky-500 bg-sky-50 text-sky-600"
                        : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                    }
                  `}
                >

                  <input
                    type="radio"
                    name={filterKey}
                    value={value}
                    checked={checked}
                    onChange={(e) =>
                      handleChange(
                        filterKey,
                        e.target.value
                      )
                    }
                    className="
                      h-3.5
                      w-3.5
                      accent-sky-500
                    "
                  />

                  {optionLabel}

                </label>
              );

            }
          )}

        </div>

      </div>
    );
  }


  /*
  |--------------------------------------------------------------------------
  | SELECT
  |--------------------------------------------------------------------------
  */

  if (
    item.type ===
    "select"
  ) {

    return (
      <div>

        <label
          className="
            mb-1.5
            block
            text-xs
            font-semibold
            text-gray-700
            sm:text-sm
          "
        >
          {label}
        </label>


        <div className="relative">

          <select
            value={
              value || ""
            }
            onChange={(e) =>
              handleChange(
                filterKey,
                e.target.value
              )
            }
            className="
              h-11
              w-full
              appearance-none
              rounded-xl
              border
              border-gray-200
              bg-white
              px-3
              pr-9
              text-sm
              outline-none
              focus:border-sky-400
              focus:ring-2
              focus:ring-sky-100
            "
          >

            <option value="">
              Select
            </option>

            {item.options?.map(
              (option, index) => {

                const optionValue =
                  option?.value ??
                  option;

                const optionLabel =
                  option?.label ??
                  option;

                return (
                  <option
                    key={index}
                    value={
                      optionValue
                    }
                  >
                    {
                      optionLabel
                    }
                  </option>
                );

              }
            )}

          </select>


          <FiChevronDown
            className="
              pointer-events-none
              absolute
              right-3
              top-1/2
              -translate-y-1/2
              text-gray-400
            "
          />

        </div>

      </div>
    );
  }


  /*
  |--------------------------------------------------------------------------
  | CHECKBOX
  |--------------------------------------------------------------------------
  */

  if (
    item.type ===
    "checkbox"
  ) {

    return (
      <div>

        <label
          className="
            mb-2
            block
            text-xs
            font-semibold
            text-gray-700
            sm:text-sm
          "
        >
          {label}
        </label>


        <div
          className="
            flex
            flex-wrap
            gap-2
          "
        >

          {item.options?.map(
            (option, index) => {

              const value =
                option?.value ??
                option;

              const optionLabel =
                option?.label ??
                option;

              const selected =
                Array.isArray(
                  filters?.[
                    filterKey
                  ]
                ) &&
                filters[
                  filterKey
                ].includes(
                  value
                );


              return (
                <label
                  key={index}
                  className={`
                    inline-flex
                    cursor-pointer
                    items-center
                    gap-2
                    rounded-xl
                    border
                    px-3
                    py-2.5
                    text-xs
                    transition

                    ${
                      selected
                        ? "border-sky-500 bg-sky-50 text-sky-600"
                        : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                    }
                  `}
                >

                  <input
                    type="checkbox"
                    value={value}
                    checked={
                      selected
                    }
                    onChange={(e) => {

                      let updated =
                        Array.isArray(
                          filters?.[
                            filterKey
                          ]
                        )
                          ? [
                              ...filters[
                                filterKey
                              ],
                            ]
                          : [];


                      if (
                        e.target
                          .checked
                      ) {

                        if (
                          !updated.includes(
                            value
                          )
                        ) {

                          updated.push(
                            value
                          );

                        }

                      } else {

                        updated =
                          updated.filter(
                            (entry) =>
                              entry !==
                              value
                          );

                      }


                      handleChange(
                        filterKey,
                        updated
                      );

                    }}
                    className="
                      h-3.5
                      w-3.5
                      accent-sky-500
                    "
                  />

                  {optionLabel}

                </label>
              );

            }
          )}

        </div>

      </div>
    );
  }


  return null;
};


export default FilterModal;
