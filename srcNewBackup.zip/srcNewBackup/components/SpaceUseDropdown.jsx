import React, {
  useEffect,
  useRef,
  useState,
} from "react";

import {
  FiChevronDown,
} from "react-icons/fi";


export default function SpaceUseDropdown({
  spaceUses = [],
  renderTree,
  buttonLabel = "Property Type",
}) {

  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);


  /*
  |--------------------------------------------------------------------------
  | CLOSE ON OUTSIDE CLICK
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    const handleClickOutside = (event) => {

      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(
          event.target
        )
      ) {
        setOpen(false);
      }

    };


    document.addEventListener(
      "mousedown",
      handleClickOutside
    );


    return () => {
      document.removeEventListener(
        "mousedown",
        handleClickOutside
      );
    };

  }, []);


  /*
  |--------------------------------------------------------------------------
  | CLOSE ON ESCAPE
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    const handleEscape = (event) => {

      if (
        event.key === "Escape"
      ) {
        setOpen(false);
      }

    };


    document.addEventListener(
      "keydown",
      handleEscape
    );


    return () => {
      document.removeEventListener(
        "keydown",
        handleEscape
      );
    };

  }, []);


  /*
  |--------------------------------------------------------------------------
  | TOGGLE
  |--------------------------------------------------------------------------
  */

  const toggleDropdown = () => {
    setOpen((prev) => !prev);
  };


  return (
    <div
      ref={dropdownRef}
      className="
        relative
        w-full
      "
    >

      {/* =====================================================
          BUTTON
      ====================================================== */}

      <button
        type="button"
        onClick={toggleDropdown}
        aria-expanded={open}
        aria-haspopup="listbox"
        className={`
          flex
          h-12
          w-full
          items-center
          justify-between
          gap-3
          rounded-xl
          border
          bg-white
          px-4
          text-left
          text-sm
          transition-all
          duration-200
          sm:h-[52px]

          ${
            open
              ? "border-sky-400 ring-2 ring-sky-100"
              : "border-gray-200 hover:border-sky-300"
          }
        `}
      >

        {/* LABEL */}

        <span
          className="
            min-w-0
            flex-1
            truncate
            text-gray-700
          "
        >
          {buttonLabel}
        </span>


        {/* CHEVRON */}

        <FiChevronDown
          className={`
            h-4
            w-4
            shrink-0
            text-gray-400
            transition-transform
            duration-200

            ${
              open
                ? "rotate-180 text-sky-500"
                : ""
            }
          `}
        />

      </button>


      {/* =====================================================
          DROPDOWN
      ====================================================== */}

      {open && (

        <div
          className="
            absolute
            left-0
            top-full
            z-[100]
            mt-2
            w-full
            overflow-hidden
            rounded-2xl
            border
            border-gray-100
            bg-white
            shadow-[0_18px_45px_rgba(0,0,0,0.12)]
          "
          role="listbox"
        >

          {/* HEADER */}

          <div
            className="
              flex
              items-center
              justify-between
              border-b
              border-gray-100
              px-4
              py-3
            "
          >

            <div>

              <p
                className="
                  text-[10px]
                  font-bold
                  uppercase
                  tracking-[0.14em]
                  text-sky-500
                "
              >
                Space Use
              </p>

              <p
                className="
                  mt-0.5
                  text-xs
                  text-gray-400
                "
              >
                Choose one or more options
              </p>

            </div>


            <button
              type="button"
              onClick={() =>
                setOpen(false)
              }
              className="
                hidden
                rounded-lg
                px-2
                py-1
                text-xs
                text-gray-400
                hover:bg-gray-50
                hover:text-gray-600
                sm:block
              "
            >
              Close
            </button>

          </div>


          {/* TREE */}

          <div
            className="
              max-h-[55vh]
              overflow-y-auto
              overscroll-contain
              p-2
              sm:max-h-[360px]
              md:max-h-[400px]
            "
          >

            {spaceUses?.length > 0 ? (

              renderTree(
                spaceUses
              )

            ) : (

              <div
                className="
                  px-4
                  py-8
                  text-center
                "
              >

                <div
                  className="
                    mx-auto
                    flex
                    h-10
                    w-10
                    items-center
                    justify-center
                    rounded-full
                    bg-sky-50
                    text-sky-500
                  "
                >
                  —
                </div>

                <p
                  className="
                    mt-3
                    text-sm
                    font-medium
                    text-gray-700
                  "
                >
                  No options available
                </p>

                <p
                  className="
                    mt-1
                    text-xs
                    text-gray-400
                  "
                >
                  Select a property type first.
                </p>

              </div>

            )}

          </div>

        </div>

      )}

    </div>
  );
}
