import React, {
  useEffect,
  useState,
} from "react";

import {
  FaArrowRight,
} from "react-icons/fa";


const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";

const FALLBACK_IMAGE =
  "https://img.magnific.com/free-psd/contact-icon-illustration-isolated_23-2151903337.jpg";


export default function Team() {

  const [
    team,
    setTeam,
  ] = useState([]);

  const [
    loading,
    setLoading,
  ] = useState(true);


  /*
  |--------------------------------------------------------------------------
  | FETCH TEAM
  |--------------------------------------------------------------------------
  */

  useEffect(() => {

    const fetchTeam =
      async () => {

        try {

          setLoading(true);

          const response =
            await fetch(
              `${API_BASE}/api/team`
            );

          if (!response.ok) {
            throw new Error(
              "Unable to fetch team"
            );
          }

          const data =
            await response.json();

          setTeam(
            Array.isArray(
              data?.data
            )
              ? data.data
              : []
          );

        } catch (error) {

          console.error(
            "Team Error:",
            error
          );

          setTeam([]);

        } finally {

          setLoading(false);

        }
      };

    fetchTeam();

  }, []);


  /*
  |--------------------------------------------------------------------------
  | LOADING
  |--------------------------------------------------------------------------
  */

  if (loading) {

    return (
      <section
        className="
          bg-white
          px-3
          py-12
          sm:px-5
          sm:py-14
          lg:px-8
          lg:py-16
        "
      >

        <div
          className="
            mx-auto
            w-full
            max-w-[1380px]
          "
        >

          <div
            className="
              mb-8
              max-w-xl
            "
          >

            <div
              className="
                h-3
                w-20
                animate-pulse
                rounded-full
                bg-sky-100
              "
            />

            <div
              className="
                mt-3
                h-8
                w-56
                animate-pulse
                rounded-lg
                bg-gray-100
              "
            />

            <div
              className="
                mt-3
                h-4
                w-full
                max-w-md
                animate-pulse
                rounded
                bg-gray-100
              "
            />

          </div>


          <div
            className="
              grid
              grid-cols-1
              gap-4
              sm:grid-cols-2
              sm:gap-5
              lg:grid-cols-4
            "
          >

            {Array.from(
              {
                length: 4,
              },
              (_, index) => (
                <div
                  key={
                    index
                  }
                  className="
                    overflow-hidden
                    rounded-2xl
                    border
                    border-gray-100
                    bg-white
                  "
                >

                  <div
                    className="
                      h-[210px]
                      animate-pulse
                      bg-gray-100
                    "
                  />

                  <div
                    className="
                      p-5
                    "
                  >

                    <div
                      className="
                        mx-auto
                        h-5
                        w-28
                        animate-pulse
                        rounded
                        bg-gray-100
                      "
                    />

                    <div
                      className="
                        mx-auto
                        mt-2
                        h-3
                        w-20
                        animate-pulse
                        rounded
                        bg-gray-100
                      "
                    />

                  </div>

                </div>
              )
            )}

          </div>

        </div>

      </section>
    );

  }


  /*
  |--------------------------------------------------------------------------
  | EMPTY
  |--------------------------------------------------------------------------
  */

  if (
    team.length === 0
  ) {

    return null;

  }


  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <section
      className="
        w-full
        bg-white
        px-3
        py-12
        sm:px-5
        sm:py-14
        lg:px-8
        lg:py-16
      "
    >

      <div
        className="
          mx-auto
          w-full
          max-w-[1380px]
        "
      >

        {/* ==================================================
            HEADER
        =================================================== */}

        <div
          className="
            mb-8
            flex
            flex-col
            gap-4
            sm:mb-10
            sm:flex-row
            sm:items-end
            sm:justify-between
          "
        >

          <div
            className="
              min-w-0
            "
          >

            <div
              className="
                flex
                items-center
                gap-1.5
              "
            >

              <span
                className="
                  h-1.5
                  w-1.5
                  rounded-full
                  bg-sky-300
                "
              />

              <span
                className="
                  h-2.5
                  w-2.5
                  rounded-full
                  bg-sky-500
                "
              />

              <span
                className="
                  h-1.5
                  w-1.5
                  rounded-full
                  bg-sky-300
                "
              />

            </div>


            <p
              className="
                mt-3
                text-[10px]
                font-bold
                uppercase
                tracking-[0.18em]
                text-sky-500
                sm:text-xs
              "
            >
              Our People
            </p>


            <h2
              className="
                mt-1
                break-words
                text-2xl
                font-extrabold
                tracking-tight
                text-gray-900
                sm:text-3xl
                md:text-4xl
              "
            >
              Meet the Team
            </h2>


            <p
              className="
                mt-2
                max-w-xl
                text-xs
                leading-6
                text-gray-500
                sm:text-sm
                sm:leading-7
              "
            >
              Get to know the people behind our
              success and the experience that
              drives our property journey.
            </p>

          </div>


          {/* COUNT */}

          <div
            className="
              flex
              w-fit
              shrink-0
              items-center
              gap-2
              rounded-full
              border
              border-sky-100
              bg-sky-50
              px-3
              py-1.5
              text-xs
              font-semibold
              text-sky-600
            "
          >

            <span>
              {team.length}
            </span>

            <span>
              Teams
            </span>

          </div>

        </div>


        {/* ==================================================
            TEAM GRID
        =================================================== */}

        <div
          className="
            grid
            grid-cols-1
            gap-4
            sm:grid-cols-2
            sm:gap-5
            lg:grid-cols-4
            lg:gap-6
          "
        >

          {team.map(
            (
              member,
              index
            ) => {

              const image =
                member?.photo
                  ? `${API_BASE}/public${member.photo}`
                  : FALLBACK_IMAGE;


              return (
                <article
                  key={
                    member?._id ||
                    member?.id ||
                    index
                  }
                  className="
                    group
                    relative
                    min-w-0
                    overflow-hidden
                    rounded-[22px]
                    border
                    border-gray-100
                    bg-white
                    shadow-sm
                    transition-all
                    duration-300
                    hover:-translate-y-1
                    hover:shadow-xl
                  "
                >

                  {/* TOP LINE */}

                  <div
                    className="
                      absolute
                      left-0
                      right-0
                      top-0
                      z-10
                      h-[2px]
                      bg-gradient-to-r
                      from-sky-400
                      via-sky-500
                      to-transparent
                    "
                  />


                  {/* IMAGE */}

                  <div
                    className="
                      relative
                      overflow-hidden
                      bg-gray-50
                    "
                  >

                    <div
                      className="
                        aspect-[4/3]
                        w-full
                      "
                    >

                      <img
                        src={
                          image
                        }
                        alt={
                          member?.name ||
                          "Team member"
                        }
                        loading="lazy"
                        className="
                          block
                          h-full
                          w-full
                          object-cover
                          transition
                          duration-500
                          group-hover:scale-105
                        "
                      />

                    </div>


                    {/* SOFT OVERLAY */}

                    <div
                      className="
                        pointer-events-none
                        absolute
                        inset-x-0
                        bottom-0
                        h-1/4
                        bg-gradient-to-t
                        from-black/20
                        to-transparent
                        opacity-0
                        transition
                        duration-300
                        group-hover:opacity-100
                      "
                    />

                  </div>


                  {/* CONTENT */}

                  <div
                    className="
                      relative
                      p-4
                      text-center
                      sm:p-5
                    "
                  >

                    {/* STAR BADGE */}

                    <div
                      className="
                        absolute
                        left-1/2
                        top-0
                        flex
                        h-9
                        w-9
                        -translate-x-1/2
                        -translate-y-1/2
                        items-center
                        justify-center
                        rounded-full
                        border
                        border-sky-100
                        bg-white
                        text-sky-500
                        shadow-md
                      "
                    >
                      ★
                    </div>


                    <h3
                      className="
                        mt-2
                        line-clamp-2
                        break-words
                        text-base
                        font-bold
                        text-gray-900
                        sm:text-lg
                      "
                    >
                      {member?.name ||
                        "Team Member"}
                    </h3>


                    <p
                      className="
                        mt-1
                        line-clamp-2
                        break-words
                        text-xs
                        leading-5
                        text-gray-500
                        sm:text-sm
                      "
                    >
                      {member?.profession ||
                        "Real Estate Professional"}
                    </p>


                    {/* SMALL ACTION */}

                    <div
                      className="
                        mt-4
                        flex
                        items-center
                        justify-center
                        gap-1.5
                        text-[10px]
                        font-semibold
                        text-sky-500
                        opacity-100
                        transition
                        sm:opacity-0
                        sm:group-hover:opacity-100
                      "
                    >
                      <span>
                        Meet our team
                      </span>

                      <FaArrowRight
                        className="
                          text-[8px]
                          transition
                          group-hover:translate-x-1
                        "
                      />

                    </div>

                  </div>

                </article>
              );
            }
          )}

        </div>

      </div>

    </section>
  );
}