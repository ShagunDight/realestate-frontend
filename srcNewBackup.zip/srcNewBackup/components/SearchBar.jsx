import React, { useEffect, useState, useRef } from "react";
import { Autocomplete } from "@react-google-maps/api";
import FilterModal from "./FilterModal";
import SpaceUseDropdown from "./SpaceUseDropdown";
import { useNavigate, useLocation } from "react-router-dom";

const SearchBar = ({ filters, setFilters, onSearch, hideAdvancedFilters = false, }) => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const [types, setTypes] = useState([]);
  const [spaceUses, setSpaceUses] = useState([]);
  const [showPrice, setShowPrice] = useState(false);
  const [showSize, setShowSize] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [openGroups, setOpenGroups] = useState({});
  const autoRef = useRef(null);

  // ✅ SAFE ARRAY
  // const selectedIds = Array.isArray(filters.section_id) ? filters.section_id : [];
  const selectedIds = [
    ...(Array.isArray(filters.space_use) ? filters.space_use : []),
    ...(Array.isArray(filters.space_use_id) ? filters.space_use_id : []),
  ];

  const selectedParentIds = Array.isArray(filters.space_use) ? filters.space_use : [];
  const selectedChildIds = Array.isArray(filters.space_use_id) ? filters.space_use_id : [];

  useEffect(() => {
    fetchTypes();
  }, []);

  useEffect(() => {
    if (types.length > 0 && !filters.type) {
      const firstType = types[0];
      const firstId = firstType._id || firstType.id;

      const updated = {
        ...filters,
        customer_email: localStorage.getItem("customer_email") || null,
        type: firstId,
        type_name: firstType?.name || "",
      };

      setFilters(updated);
      fetchSpaceUses(firstId);
      // onSearch(updated);
    }
  }, [types]);

  const fetchTypes = async () => {
    const res = await fetch("https://lightblue-moose-690494.hostingersite.com/api/property-types");
    const data = await res.json();
    setTypes(data.data || []);
  };

  // =========================
  // TOGGLE NODE (FIXED)
  // =========================
  const toggleNode = (node, checked) => {
    let parentIds = Array.isArray(filters.space_use) ? [...filters.space_use] : [];
    let childIds = Array.isArray(filters.space_use_id) ? [...filters.space_use_id] : [];

    const hasChildren = node.children && node.children.length > 0;

    const getAllChildIds = (item) => {
      let ids = [];
      item.children?.forEach((c) => {
        ids.push(c.id);
        if (c.children?.length) {
          ids = ids.concat(getAllChildIds(c));
        }
      });
      return ids;
    };

    if (hasChildren) {
      const allChildIds = getAllChildIds(node);

      if (checked) {
        // parent add
        if (!parentIds.includes(node.id)) {
          parentIds.push(node.id);
        }

        // children add
        allChildIds.forEach((id) => {
          if (!childIds.includes(id)) childIds.push(id);
        });

      } else {
        parentIds = parentIds.filter((id) => id !== node.id);
        childIds = childIds.filter((id) => !allChildIds.includes(id));
      }
    } else {
      if (checked) {
        // ✅ treat as parent (IMPORTANT FIX)
        if (!parentIds.includes(node.id)) {
          parentIds.push(node.id);
        }
      } else {
        parentIds = parentIds.filter((id) => id !== node.id);
      }
    }

    const newFilters = { ...filters, space_use: parentIds, space_use_id: childIds };

    setFilters(newFilters);
    // onSearch(newFilters);
  };

  // =========================
  // BUILD TREE
  // =========================
  const buildTree = (data) => {
    const map = {};
    const roots = [];

    data.forEach((item) => {
      const id = item._id || item.id;
      map[id] = { ...item, id, children: [] };
    });

    data.forEach((item) => {
      const id = item._id || item.id;
      const parent = item.parent_id;

      if (parent && map[parent]) {
        map[parent].children.push(map[id]);
      } else {
        roots.push(map[id]);
      }
    });

    return roots;
  };

  // =========================
  // FETCH SPACE USES
  // =========================
  const fetchSpaceUses = async (typeId) => {
    const res = await fetch(`https://lightblue-moose-690494.hostingersite.com/api/space-uses?type_id=${typeId}`);
    const data = await res.json();
    const tree = buildTree(data.data || []);
    setSpaceUses(tree);
  };

  // =========================
  // BUTTON LABEL (FIXED)
  // =========================
  const getSelectedLabel = () => {
    const parentIds = Array.isArray(filters.space_use) ? filters.space_use : [];

    if (parentIds.length === 0) return "Property Types";
    if (parentIds.length > 1) return "Multiple Types";

    const selected = spaceUses.find((item) =>
      parentIds.includes(item.id)
    );

    return selected?.name || "Property Types";
  };

  // =========================
  // RENDER TREE
  // =========================
  const renderTree = (items) => {
    return items.map((item) => {
      const id = item.id;
      const isOpen = !!openGroups[id];

      const hasChildren = item.children && item.children.length > 0;

      const isParentChecked = selectedParentIds.includes(id);
      const isChildChecked = selectedChildIds.includes(id);

      return (
        <div key={id} className="border-b">

          {/* PARENT */}
          <div className="flex items-center justify-between p-2">
            <div className="flex items-center gap-2">
              <input type="checkbox" checked={hasChildren ? isParentChecked : isParentChecked} onChange={(e) => toggleNode(item, e.target.checked)}/>
              <span className="text-sm font-medium">{item.name}</span>
            </div>

            {hasChildren && (
              <button type="button" onClick={() => setOpenGroups((prev) => ({ ...prev, [id]: !prev[id], } )) }>
                {isOpen ? "▲" : "▼"}
              </button>
            )}
          </div>

          {/* CHILDREN */}
          {isOpen && hasChildren && (
            <div className="pl-6 pb-2">
              {item.children.map((child) => {
                const cid = child.id;

                return (
                  <label key={cid} className="flex items-center gap-2 py-1 text-sm">
                    <input type="checkbox" checked={selectedChildIds.includes(cid)} onChange={(e) => toggleNode(child, e.target.checked)} />
                    {child.name}
                  </label>
                );
              })}
            </div>
          )}
        </div>
      );
    });
  };

  // =========================
// UI
// =========================
return (
  <div className="w-full bg-white rounded-2xl shadow-xl border border-gray-200 p-3 sm:p-4 md:p-5">

    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-[2fr_1.25fr_1.25fr_1.15fr_1.15fr_auto] gap-3 items-end">

      {/* LOCATION */}
      <div className="w-full">
        <label className="block text-xs font-semibold text-gray-600 mb-1.5">
          Location
        </label>

        <Autocomplete
          onLoad={(ref) => (autoRef.current = ref)}
          onPlaceChanged={() => {
            const place = autoRef.current?.getPlace();

            if (place?.formatted_address && place.geometry?.location) {
              setFilters((prev) => ({
                ...prev,
                location: place.formatted_address,
                latitude: place.geometry.location.lat(),
                longitude: place.geometry.location.lng(),
                location_selected: true,
              }));
            }
          }}
        >
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
              📍
            </span>

            <input
              type="text"
              placeholder="Search location"
              className="
                w-full h-12
                border border-gray-300
                rounded-xl
                pl-10 pr-4
                bg-gray-50
                text-sm text-gray-800
                placeholder:text-gray-400
                outline-none
                transition
                focus:bg-white
                focus:border-sky-500
                focus:ring-2
                focus:ring-sky-100
              "
              value={filters.location || ""}
              onChange={(e) =>
                setFilters((prev) => ({
                  ...prev,
                  location: e.target.value,
                  location_selected: false,
                }))
              }
            />
          </div>
        </Autocomplete>
      </div>


      {/* PROPERTY TYPE */}
      <div className="w-full">
        <label className="block text-xs font-semibold text-gray-600 mb-1.5">
          Property
        </label>

        <select
          name="type"
          id="type"
          className="
            w-full h-12
            border border-gray-300
            rounded-xl
            px-3
            bg-gray-50
            text-sm text-gray-800
            outline-none
            transition
            cursor-pointer
            focus:bg-white
            focus:border-sky-500
            focus:ring-2
            focus:ring-sky-100
          "
          value={filters.type || ""}
          onChange={(e) => {
            const value = e.target.value;

            const selectedType = types.find(
              (t) => (t._id || t.id) === value
            );

            const updated = {
              ...filters,
              type: value,
              type_name: selectedType?.name || "",
              section_id: [],
            };

            setFilters(updated);
            fetchSpaceUses(value);
          }}
        >
          <option value="">Select Property</option>

          {types.map((t) => (
            <option
              key={t._id || t.id}
              value={t._id || t.id}
            >
              {t.name}
            </option>
          ))}
        </select>
      </div>


      {/* SPACE USE */}
      <div className="w-full">
        <label className="block text-xs font-semibold text-gray-600 mb-1.5">
          Property Type
        </label>

        <div className="h-12">
          <SpaceUseDropdown
            spaceUses={spaceUses}
            renderTree={renderTree}
            buttonLabel={getSelectedLabel()}
          />
        </div>
      </div>


      {/* PRICE FILTER */}
      {!hideAdvancedFilters && filters.type_name && (
        <div className="relative w-full">

          <label className="block text-xs font-semibold text-gray-600 mb-1.5">
            {filters.type_name?.toLowerCase().includes("sale")
              ? "Price"
              : "Rent"}
          </label>

          <div
            className="
              h-12
              border border-gray-300
              rounded-xl
              bg-gray-50
              px-4
              flex items-center
              justify-between
              cursor-pointer
              text-sm
              text-gray-700
              hover:bg-white
              hover:border-sky-400
              transition
            "
            onClick={() => setShowPrice(!showPrice)}
          >
            <span>
              {filters.min_price || filters.max_price
                ? `${filters.min_price || 0} - ${filters.max_price || 0}`
                : "Any Price"}
            </span>

            <span className="text-gray-400 text-xs">
              ▼
            </span>
          </div>


          {showPrice && (
            <div
              className="
                absolute
                top-full
                left-0
                right-0
                bg-white
                border
                border-gray-200
                rounded-xl
                p-4
                mt-2
                shadow-2xl
                z-50
              "
            >
              <p className="text-xs font-semibold text-gray-600 mb-3">
                Price Range
              </p>

              <input
                placeholder="Minimum"
                className="
                  border border-gray-300
                  rounded-lg
                  p-2.5
                  w-full
                  mb-2
                  text-sm
                  outline-none
                  focus:border-sky-500
                  focus:ring-2
                  focus:ring-sky-100
                "
                value={filters.min_price || ""}
                onChange={(e) =>
                  setFilters({
                    ...filters,
                    min_price: e.target.value,
                  })
                }
              />

              <input
                placeholder="Maximum"
                className="
                  border border-gray-300
                  rounded-lg
                  p-2.5
                  w-full
                  text-sm
                  outline-none
                  focus:border-sky-500
                  focus:ring-2
                  focus:ring-sky-100
                "
                value={filters.max_price || ""}
                onChange={(e) =>
                  setFilters({
                    ...filters,
                    max_price: e.target.value,
                  })
                }
              />
            </div>
          )}
        </div>
      )}


      {/* SIZE FILTER */}
      {!hideAdvancedFilters && (
        <div className="relative w-full">

          <label className="block text-xs font-semibold text-gray-600 mb-1.5">
            Building Size
          </label>

          <div
            className="
              h-12
              border border-gray-300
              rounded-xl
              bg-gray-50
              px-4
              flex items-center
              justify-between
              cursor-pointer
              text-sm
              text-gray-700
              hover:bg-white
              hover:border-sky-400
              transition
            "
            onClick={() => setShowSize(!showSize)}
          >
            <span>
              {filters.building_min_size ||
              filters.building_max_size
                ? `${filters.building_min_size || 0} - ${
                    filters.building_max_size || 0
                  } sqft`
                : "Any Size"}
            </span>

            <span className="text-gray-400 text-xs">
              ▼
            </span>
          </div>


          {showSize && (
            <div
              className="
                absolute
                top-full
                left-0
                right-0
                bg-white
                border
                border-gray-200
                rounded-xl
                p-4
                mt-2
                shadow-2xl
                z-50
              "
            >
              <p className="text-xs font-semibold text-gray-600 mb-3">
                Building Size
              </p>

              <input
                placeholder="Min SF"
                className="
                  border border-gray-300
                  rounded-lg
                  p-2.5
                  w-full
                  mb-2
                  text-sm
                  outline-none
                  focus:border-sky-500
                  focus:ring-2
                  focus:ring-sky-100
                "
                value={filters.building_min_size || ""}
                onChange={(e) =>
                  setFilters({
                    ...filters,
                    building_min_size: e.target.value,
                  })
                }
              />

              <input
                placeholder="Max SF"
                className="
                  border border-gray-300
                  rounded-lg
                  p-2.5
                  w-full
                  text-sm
                  outline-none
                  focus:border-sky-500
                  focus:ring-2
                  focus:ring-sky-100
                "
                value={filters.building_max_size || ""}
                onChange={(e) =>
                  setFilters({
                    ...filters,
                    building_max_size: e.target.value,
                  })
                }
              />
            </div>
          )}
        </div>
      )}


      {/* FILTER MODAL */}
      {showModal && (
        <FilterModal
          filters={filters}
          setFilters={setFilters}
          onClose={() => setShowModal(false)}
          onSearch={onSearch}
        />
      )}


      {/* BUTTONS */}
      <div
        className="
          col-span-1
          sm:col-span-2
          xl:col-span-1
          flex
          flex-row
          gap-2
          w-full
          items-end
        "
      >

        {!hideAdvancedFilters && (
          <button
            type="button"
            onClick={() => setShowModal(true)}
            className="
              h-12
              px-4
              rounded-xl
              border border-gray-300
              bg-white
              text-gray-700
              text-sm
              font-semibold
              hover:bg-gray-50
              hover:border-gray-400
              transition
              whitespace-nowrap
            "
          >
            ⚙ Filters
          </button>
        )}


        {!hideAdvancedFilters && (
          <button
            type="button"
            onClick={() => {
              const resetFilters = {
                location: "",
                type: "",
                type_name: "",
                space_use: [],
                space_use_id: [],
                listing_type: "",
                min_price: "",
                max_price: "",
                land_size_min: "",
                land_size_max: "",
                building_size_min: "",
                building_size_max: "",
                year_built_min: "",
                year_built_max: "",
              };

              setFilters(resetFilters);
              setSpaceUses([]);
              setShowPrice(false);
              setShowSize(false);
            }}
            className="
              h-12
              px-4
              rounded-xl
              bg-gray-100
              text-gray-700
              text-sm
              font-semibold
              hover:bg-gray-200
              transition
              whitespace-nowrap
            "
          >
            Clear
          </button>
        )}


        <button
          type="button"
          onClick={() => {
            navigate("/properties", {
              state: { filters },
            });
          }}
          className="
            h-12
            px-5
            rounded-xl
            bg-sky-600
            hover:bg-sky-700
            text-white
            text-sm
            font-semibold
            shadow-md
            hover:shadow-lg
            transition
            whitespace-nowrap
          "
        >
          Search
        </button>

      </div>

    </div>
  </div>
);
};

export default SearchBar;