import React from "react";
import { useJsApiLoader } from "@react-google-maps/api";

const GOOGLE_MAPS_LIBRARIES = ["places"];

const GoogleMapsProvider = ({ children }) => {
  const { isLoaded, loadError } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: "AIzaSyD-5EHYR_BK19i4x7gASRqFx0qvVW0u28w",
    libraries: GOOGLE_MAPS_LIBRARIES,
  });

  if (loadError) {
    return (
      <div className="flex items-center justify-center min-h-[300px]">
        <p className="text-red-500">
          Google Maps could not be loaded.
        </p>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center min-h-[300px]">
        <p className="text-gray-500">
          Loading map...
        </p>
      </div>
    );
  }

  return children;
};

export default GoogleMapsProvider;