import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";

const MultiImageSlider = () => {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [current, setCurrent] = useState(0);

  const [visibleItems, setVisibleItems] = useState(2);

  const intervalRef = useRef(null);
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);

  /*
  |--------------------------------------------------------------------------
  | RESPONSIVE ITEMS
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    const updateVisibleItems = () => {
      const width = window.innerWidth;

      if (width < 640) {
        setVisibleItems(1);
      } else {
        setVisibleItems(2);
      }
    };

    updateVisibleItems();

    window.addEventListener(
      "resize",
      updateVisibleItems
    );

    return () => {
      window.removeEventListener(
        "resize",
        updateVisibleItems
      );
    };
  }, []);


  /*
  |--------------------------------------------------------------------------
  | FETCH NEWS
  |--------------------------------------------------------------------------
  */

  const fetchNews = async () => {
    try {
      setLoading(true);

      const res = await fetch(
        "https://lightblue-moose-690494.hostingersite.com/api/blogs"
      );

      if (!res.ok) {
        throw new Error("Failed to fetch news");
      }

      const data = await res.json();

      const filtered = (data?.data || []).filter(
        (item) => item?.type === "market_news"
      );

      setNews(filtered);
    } catch (error) {
      console.error(
        "Market News Error:",
        error
      );

      setNews([]);
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    fetchNews();
  }, []);


  /*
  |--------------------------------------------------------------------------
  | KEEP CURRENT INDEX VALID
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    const maxIndex = Math.max(
      news.length - visibleItems,
      0
    );

    setCurrent((prev) =>
      prev > maxIndex ? 0 : prev
    );
  }, [news.length, visibleItems]);


  /*
  |--------------------------------------------------------------------------
  | AUTO SLIDE
  |--------------------------------------------------------------------------
  */

  const stopAutoSlide = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };


  const startAutoSlide = () => {
    stopAutoSlide();

    if (
      news.length <= visibleItems
    ) {
      return;
    }

    intervalRef.current = setInterval(() => {
      setCurrent((prev) => {
        const maxIndex =
          news.length - visibleItems;

        return prev >= maxIndex
          ? 0
          : prev + 1;
      });
    }, 4000);
  };


  useEffect(() => {
    startAutoSlide();

    return () => {
      stopAutoSlide();
    };
  }, [news.length, visibleItems]);


  /*
  |--------------------------------------------------------------------------
  | NEXT
  |--------------------------------------------------------------------------
  */

  const nextSlide = () => {
    if (news.length <= visibleItems) {
      return;
    }

    const maxIndex =
      news.length - visibleItems;

    setCurrent((prev) =>
      prev >= maxIndex
        ? 0
        : prev + 1
    );

    startAutoSlide();
  };


  /*
  |--------------------------------------------------------------------------
  | PREVIOUS
  |--------------------------------------------------------------------------
  */

  const prevSlide = () => {
    if (news.length <= visibleItems) {
      return;
    }

    const maxIndex =
      news.length - visibleItems;

    setCurrent((prev) =>
      prev <= 0
        ? maxIndex
        : prev - 1
    );

    startAutoSlide();
  };


  /*
  |--------------------------------------------------------------------------
  | TOUCH
  |--------------------------------------------------------------------------
  */

  const handleTouchStart = (event) => {
    touchStartX.current =
      event.touches[0].clientX;

    touchEndX.current =
      event.touches[0].clientX;

    stopAutoSlide();
  };


  const handleTouchMove = (event) => {
    touchEndX.current =
      event.touches[0].clientX;
  };


  const handleTouchEnd = () => {
    const diff =
      touchStartX.current -
      touchEndX.current;

    if (Math.abs(diff) >= 50) {
      if (diff > 0) {
        nextSlide();
      } else {
        prevSlide();
      }
    } else {
      startAutoSlide();
    }
  };


  /*
  |--------------------------------------------------------------------------
  | LOADING
  |--------------------------------------------------------------------------
  */

  if (loading) {
    return (
      <section className="w-full bg-gray-50 py-12 sm:py-14">
        <div className="flex items-center justify-center">
          <div
            className="
              h-9
              w-9
              animate-spin
              rounded-full
              border-[3px]
              border-gray-200
              border-t-sky-500
            "
          />
        </div>
      </section>
    );
  }


  /*
  |--------------------------------------------------------------------------
  | EMPTY
  |--------------------------------------------------------------------------
  */

  if (!news.length) {
    return (
      <section className="w-full bg-gray-50 px-4 py-12 sm:px-6 sm:py-14">
        <div className="mx-auto max-w-[1300px] text-center">

          <p className="text-xs font-semibold uppercase tracking-[0.15em] text-sky-500">
            Property Updates
          </p>

          <h2 className="mt-2 text-2xl font-bold text-gray-900 sm:text-3xl">
            Explore Property News & Updates
          </h2>

          <p className="mt-2 text-sm text-gray-500">
            News and insights will appear here soon.
          </p>

        </div>
      </section>
    );
  }


  const canSlide =
    news.length > visibleItems;


  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <section
      className="
        w-full
        overflow-hidden
        bg-gray-50
        py-10
        sm:py-12
        md:py-14
      "
    >
      <div
        className="
          mx-auto
          w-full
          max-w-[1300px]
          px-4
          sm:px-6
          lg:px-8
        "
      >

        {/* =====================================================
            HEADER
        ====================================================== */}

        <div
          className="
            mb-6
            text-center
            sm:mb-8
          "
        >

          <p
            className="
              text-[10px]
              font-bold
              uppercase
              tracking-[0.18em]
              text-sky-500
              sm:text-xs
            "
          >
            Property Updates
          </p>

          <h2
            className="
              mt-2
              text-2xl
              font-bold
              leading-tight
              text-gray-900
              sm:text-3xl
              md:text-4xl
            "
          >
            Explore Property News & Updates
          </h2>

          <p
            className="
              mx-auto
              mt-2
              max-w-xl
              text-xs
              leading-5
              text-gray-500
              sm:text-sm
              sm:leading-6
            "
          >
            Latest insights, trends & premium property highlights.
          </p>

        </div>


        {/* =====================================================
            SLIDER
        ====================================================== */}

        <div
          className="
            group
            relative
            select-none
            overflow-hidden
          "
          onMouseEnter={stopAutoSlide}
          onMouseLeave={startAutoSlide}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >

          {/* TRACK */}

          <div
            className="
              flex
              transition-transform
              duration-500
              ease-out
            "
            style={{
              transform: `translateX(-${
                current *
                (100 / visibleItems)
              }%)`,
              willChange: "transform",
            }}
          >

            {news.map((item, index) => (
              <div
                key={
                  item?._id ||
                  item?.id ||
                  index
                }
                className="
                  min-w-full
                  px-1.5
                  sm:min-w-[50%]
                  sm:px-2
                "
              >

                <article
                  className="
                    group/card
                    relative
                    h-[220px]
                    overflow-hidden
                    rounded-[20px]
                    bg-gray-200
                    shadow-lg
                    sm:h-[280px]
                    sm:rounded-2xl
                    md:h-[320px]
                  "
                >

                  {/* IMAGE */}

                  <img
                    src={`https://lightblue-moose-690494.hostingersite.com/public${item?.image || ""}`}
                    alt={
                      item?.title ||
                      "Property news"
                    }
                    loading={
                      index <
                      visibleItems
                        ? "eager"
                        : "lazy"
                    }
                    className="
                      h-full
                      w-full
                      object-cover
                      transition-transform
                      duration-700
                      group-hover/card:scale-105
                    "
                  />


                  {/* GRADIENT */}

                  <div
                    className="
                      absolute
                      inset-0
                      bg-gradient-to-t
                      from-black/85
                      via-black/20
                      to-transparent
                    "
                  />


                  {/* CONTENT */}

                  <div
                    className="
                      absolute
                      inset-x-0
                      bottom-0
                      p-4
                      sm:p-5
                      md:p-6
                    "
                  >

                    <span
                      className="
                        inline-flex
                        rounded-full
                        border
                        border-white/20
                        bg-white/10
                        px-2.5
                        py-1
                        text-[9px]
                        font-semibold
                        uppercase
                        tracking-[0.15em]
                        text-white
                        backdrop-blur-md
                        sm:text-[10px]
                      "
                    >
                      Market News
                    </span>


                    <Link
                      to={`/blog/${item?.slug}`}
                      className="block"
                    >
                      <h4
                        className="
                          mt-2
                          line-clamp-2
                          text-sm
                          font-semibold
                          leading-5
                          text-white
                          transition-colors
                          hover:text-sky-200
                          sm:text-lg
                          sm:leading-6
                          md:text-xl
                        "
                      >
                        {item?.title ||
                          "Property Market Update"}
                      </h4>
                    </Link>

                  </div>

                </article>
              </div>
            ))}

          </div>


          {/* =================================================
              PREVIOUS
          ================================================== */}

          {canSlide && (
            <button
              type="button"
              onClick={prevSlide}
              aria-label="Previous property news"
              className="
                absolute
                left-2
                top-1/2
                z-20
                flex
                h-10
                w-10
                -translate-y-1/2
                items-center
                justify-center
                rounded-full
                border
                border-gray-200
                bg-white/95
                text-gray-700
                shadow-xl
                transition-all
                duration-300
                hover:scale-105
                hover:bg-sky-500
                hover:text-white
                sm:left-3
                sm:h-11
                sm:w-11
                lg:opacity-0
                lg:group-hover:opacity-100
              "
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15 19l-7-7 7-7"
                />
              </svg>
            </button>
          )}


          {/* =================================================
              NEXT
          ================================================== */}

          {canSlide && (
            <button
              type="button"
              onClick={nextSlide}
              aria-label="Next property news"
              className="
                absolute
                right-2
                top-1/2
                z-20
                flex
                h-10
                w-10
                -translate-y-1/2
                items-center
                justify-center
                rounded-full
                border
                border-gray-200
                bg-white/95
                text-gray-700
                shadow-xl
                transition-all
                duration-300
                hover:scale-105
                hover:bg-sky-500
                hover:text-white
                sm:right-3
                sm:h-11
                sm:w-11
                lg:opacity-0
                lg:group-hover:opacity-100
              "
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </button>
          )}

        </div>


        {/* =====================================================
            MOBILE SWIPE HINT
        ====================================================== */}

        {canSlide && (
          <div className="mt-4 flex justify-center sm:hidden">
            <div className="flex items-center gap-1.5 text-[10px] font-medium text-gray-400">
              <span>Swipe</span>
              <span>←</span>
              <span>→</span>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};

export default MultiImageSlider;
