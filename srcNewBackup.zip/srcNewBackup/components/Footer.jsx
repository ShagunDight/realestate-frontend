import React from "react";
import { NavLink } from "react-router-dom";
import {
  FaFacebookF,
  FaTwitter,
  FaInstagram,
  FaLinkedinIn,
} from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="hidden lg:block bg-sky-400 text-white">
      <div className="mx-auto max-w-[1300px] px-6 pt-14 pb-10 xl:px-0">

        {/* =====================================================
            MAIN FOOTER
        ====================================================== */}

        <div className="grid grid-cols-1 gap-12 lg:grid-cols-4">

          {/* =================================================
              BRAND
          ================================================== */}

          <div className="lg:col-span-1">

            <NavLink
              to="/"
              className="
                inline-block
                text-2xl
                font-extrabold
                tracking-tight
                text-white
              "
            >
              Estatein
            </NavLink>

            <p
              className="
                mt-4
                max-w-sm
                text-sm
                leading-6
                text-white/85
              "
            >
              Discover premium properties and make your real estate
              journey smooth, simple, and successful with Estatein.
            </p>

            {/* SOCIAL */}

            <div className="mt-6 flex items-center gap-3">

              {[
                {
                  Icon: FaFacebookF,
                  label: "Facebook",
                },
                {
                  Icon: FaTwitter,
                  label: "Twitter",
                },
                {
                  Icon: FaInstagram,
                  label: "Instagram",
                },
                {
                  Icon: FaLinkedinIn,
                  label: "LinkedIn",
                },
              ].map(
                ({ Icon, label }) => (
                  <button
                    key={label}
                    type="button"
                    aria-label={label}
                    className="
                      flex
                      h-10
                      w-10
                      items-center
                      justify-center
                      rounded-full
                      border
                      border-white/20
                      bg-white/15
                      text-white
                      backdrop-blur-sm
                      transition-all
                      duration-300
                      hover:-translate-y-1
                      hover:bg-white
                      hover:text-sky-500
                    "
                  >
                    <Icon size={14} />
                  </button>
                )
              )}

            </div>
          </div>


          {/* =================================================
              QUICK LINKS
          ================================================== */}

          <div>

            <h3
              className="
                text-sm
                font-bold
                uppercase
                tracking-wider
                text-white
              "
            >
              Quick Links
            </h3>

            <ul className="mt-5 space-y-3 text-sm">

              <li>
                <NavLink
                  to="/"
                  className="text-white/80 transition hover:text-white"
                >
                  Home
                </NavLink>
              </li>

              <li>
                <NavLink
                  to="/wishlist"
                  className="text-white/80 transition hover:text-white"
                >
                  Wishlist
                </NavLink>
              </li>

              <li>
                <NavLink
                  to="/properties"
                  className="text-white/80 transition hover:text-white"
                >
                  Properties
                </NavLink>
              </li>

              <li>
                <NavLink
                  to="/about"
                  className="text-white/80 transition hover:text-white"
                >
                  About
                </NavLink>
              </li>

              <li>
                <NavLink
                  to="/contact"
                  className="text-white/80 transition hover:text-white"
                >
                  Contact
                </NavLink>
              </li>

            </ul>
          </div>


          {/* =================================================
              SUPPORT
          ================================================== */}

          <div>

            <h3
              className="
                text-sm
                font-bold
                uppercase
                tracking-wider
                text-white
              "
            >
              Support
            </h3>

            <ul className="mt-5 space-y-3 text-sm">

              <li>
                <NavLink
                  to="/faq"
                  className="text-white/80 transition hover:text-white"
                >
                  Help Center
                </NavLink>
              </li>

              <li>
                <span className="cursor-pointer text-white/80 transition hover:text-white">
                  Terms of Service
                </span>
              </li>

              <li>
                <NavLink
                  to="/privacy-policy"
                  className="text-white/80 transition hover:text-white"
                >
                  Privacy Policy
                </NavLink>
              </li>

              <li>
                <NavLink
                  to="/faq"
                  className="text-white/80 transition hover:text-white"
                >
                  FAQs
                </NavLink>
              </li>

            </ul>
          </div>


          {/* =================================================
              SUBSCRIBE
          ================================================== */}

          <div>

            <h3
              className="
                text-sm
                font-bold
                uppercase
                tracking-wider
                text-white
              "
            >
              Subscribe
            </h3>

            <p
              className="
                mt-5
                max-w-xs
                text-sm
                leading-6
                text-white/80
              "
            >
              Get the latest property updates and offers directly
              in your inbox.
            </p>

            <div
              className="
                mt-4
                flex
                overflow-hidden
                rounded-xl
                border
                border-white/20
                bg-white/15
                backdrop-blur-md
              "
            >

              <input
                type="email"
                placeholder="Enter your email"
                className="
                  min-w-0
                  flex-1
                  bg-transparent
                  px-4
                  py-3
                  text-sm
                  text-white
                  outline-none
                  placeholder:text-white/65
                "
              />

              <button
                type="button"
                aria-label="Subscribe"
                className="
                  flex
                  w-12
                  shrink-0
                  items-center
                  justify-center
                  bg-white
                  text-lg
                  font-semibold
                  text-sky-500
                  transition
                  hover:bg-sky-50
                "
              >
                →
              </button>

            </div>

          </div>

        </div>


        {/* =====================================================
            DIVIDER
        ====================================================== */}

        <div className="my-10 h-px bg-white/20" />


        {/* =====================================================
            BOTTOM
        ====================================================== */}

        <div
          className="
            flex
            items-center
            justify-between
            gap-6
            text-xs
            text-white/75
          "
        >

          <p>
            © 2024 Estatein. All rights reserved.
          </p>

          <p>
            Premium Real Estate Solutions
          </p>

        </div>

      </div>
    </footer>
  );
};

export default Footer;
