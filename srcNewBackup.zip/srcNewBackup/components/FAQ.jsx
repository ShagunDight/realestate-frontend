import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const FAQ = () => {
  const navigate = useNavigate();

  const [faqs, setFaqs] = useState([]);
  const [active, setActive] = useState(null);
  const [loading, setLoading] = useState(true);

  /*
  |--------------------------------------------------------------------------
  | FETCH FAQS
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    const fetchFaqs = async () => {
      try {
        setLoading(true);

        const response = await fetch(
          "https://lightblue-moose-690494.hostingersite.com/api/faqs"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch FAQs");
        }

        const data = await response.json();

        const finalData = data?.data || data;

        setFaqs(
          Array.isArray(finalData) ? finalData : []
        );
      } catch (error) {
        console.error("FAQ Error:", error);
        setFaqs([]);
      } finally {
        setLoading(false);
      }
    };

    fetchFaqs();
  }, []);


  /*
  |--------------------------------------------------------------------------
  | TOGGLE
  |--------------------------------------------------------------------------
  */

  const toggleFaq = (index) => {
    setActive((prev) =>
      prev === index ? null : index
    );
  };

  /*
  |--------------------------------------------------------------------------
  | ANSWER TEXT
  |--------------------------------------------------------------------------
  */

  const getAnswerText = (answer) => {
    return String(answer || "").trim();
  };

  return (
    <section
      className="
        w-full
        bg-gradient-to-b
        from-white
        to-sky-50
        px-4
        py-10
        sm:px-6
        sm:py-12
        md:py-14
        lg:py-16
      "
    >
      <div className="mx-auto w-full max-w-6xl">

        {/* =====================================================
            HEADER
        ====================================================== */}

        <div
          className="
            mb-7
            flex
            flex-col
            gap-5
            sm:mb-9
            md:mb-10
            lg:flex-row
            lg:items-end
            lg:justify-between
          "
        >
          <div className="max-w-2xl">

            <div className="mb-3 flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-sky-300 sm:h-2 sm:w-2" />
              <span className="h-2.5 w-2.5 rounded-full bg-sky-500 sm:h-3 sm:w-3" />
              <span className="h-1.5 w-1.5 rounded-full bg-sky-300 sm:h-2 sm:w-2" />
            </div>

            <p
              className="
                text-[10px]
                font-bold
                uppercase
                tracking-[0.18em]
                text-sky-500
                sm:text-xs
              "
            >
              Help Center
            </p>

            <h2
              className="
                mt-2
                text-2xl
                font-bold
                leading-tight
                text-gray-900
                sm:text-3xl
                md:text-4xl
              "
            >
              Frequently Asked Questions
            </h2>

            <p
              className="
                mt-2
                max-w-xl
                text-xs
                leading-5
                text-gray-500
                sm:text-sm
                sm:leading-6
              "
            >
              Everything you need to know about properties,
              listings, and services.
            </p>

          </div>

          <button
            type="button"
            onClick={() => navigate("/faq")}
            className="
              inline-flex
              min-h-[42px]
              w-full
              items-center
              justify-center
              rounded-xl
              border
              border-gray-200
              bg-white
              px-5
              py-2
              text-xs
              font-semibold
              text-gray-700
              shadow-sm
              transition-all
              hover:border-sky-500
              hover:bg-sky-500
              hover:text-white
              active:scale-[0.98]
              sm:w-fit
              sm:text-sm
            "
          >
            View All
            <span className="ml-2">→</span>
          </button>
        </div>


        {/* =====================================================
            LOADING
        ====================================================== */}

        {loading && (
          <div className="flex min-h-[240px] items-center justify-center">
            <div
              className="
                h-8
                w-8
                animate-spin
                rounded-full
                border-[3px]
                border-gray-200
                border-t-sky-500
              "
            />
          </div>
        )}


        {/* =====================================================
            FAQS
        ====================================================== */}

        {!loading && faqs.length > 0 && (
          <div
            className="
              grid
              grid-cols-1
              gap-4
              sm:grid-cols-2
              sm:gap-5
              lg:grid-cols-3
              lg:gap-6
            "
          >
            {faqs.slice(0, 3).map((item, index) => {
              const answer = getAnswerText(item?.answer);

              const isActive = active === index;

              const shouldShowMore =
                answer.length > 110;

              const displayAnswer =
                isActive || !shouldShowMore
                  ? answer
                  : `${answer.slice(0, 100)}...`;

              return (
                <article
                  key={
                    item?._id ||
                    item?.id ||
                    index
                  }
                  className={`
                    group
                    flex
                    h-full
                    flex-col
                    rounded-2xl
                    border
                    bg-white
                    p-5
                    shadow-sm
                    transition-all
                    duration-300
                    sm:rounded-[22px]
                    sm:p-6
                    ${
                      isActive
                        ? "border-sky-200 shadow-md"
                        : "border-gray-200 hover:-translate-y-1 hover:shadow-xl"
                    }
                  `}
                >

                  {/* QUESTION */}

                  <div className="flex items-start justify-between gap-3">

                    <h3
                      className="
                        text-sm
                        font-semibold
                        leading-5
                        text-gray-800
                        sm:text-base
                        sm:leading-6
                      "
                    >
                      {item?.question || "No Question"}
                    </h3>

                    <button
                      type="button"
                      onClick={() =>
                        shouldShowMore &&
                        toggleFaq(index)
                      }
                      className={`
                        flex
                        h-8
                        w-8
                        shrink-0
                        items-center
                        justify-center
                        rounded-full
                        text-xs
                        font-bold
                        transition-all
                        ${
                          shouldShowMore
                            ? "cursor-pointer bg-sky-50 text-sky-500 hover:bg-sky-500 hover:text-white"
                            : "cursor-default bg-gray-50 text-gray-400"
                        }
                      `}
                    >
                      {isActive ? "−" : "+"}
                    </button>

                  </div>


                  {/* ANSWER */}

                  <p
                    className="
                      mt-3
                      text-xs
                      leading-5
                      text-gray-500
                      sm:text-sm
                      sm:leading-6
                    "
                  >
                    {displayAnswer}
                  </p>


                  {/* MORE / LESS */}

                  {shouldShowMore && (
                    <button
                      type="button"
                      onClick={() =>
                        toggleFaq(index)
                      }
                      className="
                        mt-3
                        self-start
                        text-xs
                        font-semibold
                        text-sky-500
                        transition-colors
                        hover:text-sky-600
                        hover:underline
                        sm:text-sm
                      "
                    >
                      {isActive
                        ? "Show Less"
                        : "Read More"}
                    </button>
                  )}

                </article>
              );
            })}
          </div>
        )}


        {/* =====================================================
            EMPTY
        ====================================================== */}

        {!loading && faqs.length === 0 && (
          <div
            className="
              rounded-2xl
              border
              border-gray-100
              bg-white
              px-5
              py-12
              text-center
              shadow-sm
            "
          >
            <div className="text-4xl">?</div>

            <h3 className="mt-3 text-base font-semibold text-gray-900">
              No FAQs Found
            </h3>

            <p className="mt-1.5 text-xs text-gray-500 sm:text-sm">
              Frequently asked questions are currently unavailable.
            </p>
          </div>
        )}

      </div>
    </section>
  );
};

export default FAQ;
