import React from "react";
import {
  HiHome,
  HiLightningBolt,
  HiCog,
  HiTrendingUp,
} from "react-icons/hi";

const Features = () => {
  const data = [
    {
      icon: <HiHome />,
      title: "Find Your Dream Home",
    },
    {
      icon: <HiLightningBolt />,
      title: "Unlock Property Value",
    },
    {
      icon: <HiCog />,
      title: "Effortless Property Management",
    },
    {
      icon: <HiTrendingUp />,
      title: "Smart Investment, Informed Decision",
    },
  ];

  return (
    <section className="w-full bg-sky-50 py-8 sm:py-10 md:py-12 lg:py-14">
      <div className="mx-auto w-full max-w-[1300px] px-4 sm:px-6 lg:px-8">

        {/* HEADER */}
        <div className="mb-6 text-center sm:mb-8 md:mb-10">
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-sky-500 sm:text-xs">
            Why Choose Us
          </p>

          <h2 className="mt-2 text-xl font-bold leading-tight text-gray-900 sm:text-2xl md:text-3xl">
            Everything You Need
          </h2>

          <p className="mx-auto mt-2 max-w-xl text-xs leading-5 text-gray-600 sm:text-sm sm:leading-6">
            Simple tools and smart solutions to help you find, manage,
            and invest in property with confidence.
          </p>
        </div>

        {/* FEATURES GRID */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4 lg:gap-6">
          {data.map((item, index) => (
            <div
              key={index}
              className="
                group
                relative
                flex
                min-h-[165px]
                flex-col
                items-center
                justify-center
                rounded-2xl
                border
                border-gray-200
                bg-white
                px-5
                py-6
                text-center
                shadow-sm
                transition-all
                duration-300
                hover:-translate-y-1
                hover:shadow-xl
                active:scale-[0.99]
                sm:min-h-[175px]
                sm:px-6
                sm:py-7
                md:min-h-[185px]
                md:rounded-[22px]
              "
            >
              {/* TOP RIGHT ARROW */}
              <div
                className="
                  absolute
                  right-3
                  top-3
                  flex
                  h-8
                  w-8
                  items-center
                  justify-center
                  rounded-full
                  bg-sky-100
                  text-xs
                  font-semibold
                  text-sky-500
                  transition-all
                  duration-300
                  group-hover:bg-sky-500
                  group-hover:text-white
                  sm:right-4
                  sm:top-4
                "
              >
                ↗
              </div>

              {/* ICON */}
              <div
                className="
                  mb-4
                  flex
                  h-12
                  w-12
                  items-center
                  justify-center
                  rounded-full
                  bg-sky-100
                  text-xl
                  text-sky-500
                  transition-all
                  duration-300
                  group-hover:scale-105
                  group-hover:bg-sky-500
                  group-hover:text-white
                  sm:h-14
                  sm:w-14
                  sm:text-2xl
                "
              >
                {item.icon}
              </div>

              {/* TITLE */}
              <h3
                className="
                  max-w-[220px]
                  text-sm
                  font-semibold
                  leading-5
                  text-gray-800
                  sm:text-sm
                  md:text-[15px]
                  md:leading-6
                "
              >
                {item.title}
              </h3>

              {/* BOTTOM ACCENT */}
              <div
                className="
                  mt-4
                  h-1
                  w-8
                  rounded-full
                  bg-sky-100
                  transition-all
                  duration-300
                  group-hover:w-12
                  group-hover:bg-sky-500
                "
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
