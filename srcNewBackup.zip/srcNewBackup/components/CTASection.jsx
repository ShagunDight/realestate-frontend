import React from "react";
import { useNavigate } from "react-router-dom";

const CTASection = () => {
  const navigate = useNavigate();

  return (
    <section
      className="
        w-full
        bg-white
        px-4
        py-6
        sm:px-6
        sm:py-8
        md:py-10
      "
    >
      <div className="mx-auto w-full max-w-7xl">
        <div
          className="
            relative
            min-h-[390px]
            overflow-hidden
            rounded-[24px]
            shadow-xl
            sm:min-h-[420px]
            sm:rounded-[28px]
            md:min-h-[450px]
            lg:rounded-[32px]
          "
        >
          {/* =====================================================
              BACKGROUND IMAGE
          ====================================================== */}

          <img
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c"
            alt="Modern real estate property"
            loading="lazy"
            className="
              absolute
              inset-0
              h-full
              w-full
              object-cover
              scale-105
            "
          />

          {/* =====================================================
              DARK OVERLAY
          ====================================================== */}

          <div
            className="
              absolute
              inset-0
              bg-gradient-to-b
              from-sky-950/95
              via-sky-900/90
              to-sky-700/75
              sm:bg-gradient-to-r
              sm:from-sky-950/95
              sm:via-sky-900/85
              sm:to-sky-700/70
            "
          />

          {/* =====================================================
              SOFT GLOW
          ====================================================== */}

          <div
            className="
              pointer-events-none
              absolute
              -left-20
              -top-20
              h-48
              w-48
              rounded-full
              bg-sky-400/20
              blur-[90px]
              sm:-left-24
              sm:-top-24
              sm:h-64
              sm:w-64
            "
          />

          <div
            className="
              pointer-events-none
              absolute
              -bottom-16
              -right-16
              h-52
              w-52
              rounded-full
              bg-sky-300/20
              blur-[90px]
              sm:-bottom-20
              sm:-right-20
              sm:h-64
              sm:w-64
            "
          />

          {/* =====================================================
              CONTENT
          ====================================================== */}

          <div
            className="
              relative
              z-10
              flex
              h-full
              min-h-[390px]
              flex-col
              items-center
              justify-center
              gap-8
              px-5
              py-10
              text-white
              sm:min-h-[420px]
              sm:px-8
              sm:py-12
              md:min-h-[450px]
              md:px-12
              lg:flex-row
              lg:items-center
              lg:justify-between
              lg:gap-12
              lg:px-16
            "
          >
            {/* =================================================
                LEFT CONTENT
            ================================================== */}

            <div
              className="
                w-full
                max-w-2xl
                text-center
                lg:text-left
              "
            >
              {/* Small Label */}

              <span
                className="
                  inline-flex
                  items-center
                  rounded-full
                  border
                  border-white/20
                  bg-white/10
                  px-3
                  py-1.5
                  text-[10px]
                  font-semibold
                  uppercase
                  tracking-[0.16em]
                  text-sky-100
                  backdrop-blur-sm
                  sm:px-4
                  sm:py-2
                  sm:text-xs
                "
              >
                Your Property Journey
              </span>

              {/* Heading */}

              <h2
                className="
                  mt-4
                  text-[30px]
                  font-bold
                  leading-[1.1]
                  tracking-tight
                  sm:text-4xl
                  md:text-5xl
                  lg:mt-5
                  lg:text-5xl
                  xl:text-[52px]
                "
              >
                Start Your Real Estate Journey Today
              </h2>

              {/* Description */}

              <p
                className="
                  mt-4
                  max-w-xl
                  text-sm
                  leading-6
                  text-sky-100
                  sm:mt-5
                  sm:text-base
                  sm:leading-7
                "
              >
                Discover premium properties tailored to your lifestyle.
                Whether you're buying your dream home or investing smartly,
                your journey starts with a single step.
              </p>

              {/* Highlight */}

              <div
                className="
                  mt-5
                  flex
                  items-center
                  justify-center
                  gap-2
                  lg:justify-start
                  sm:mt-6
                "
              >
                <span className="h-1.5 w-1.5 rounded-full bg-white/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-white" />
                <span className="h-1.5 w-1.5 rounded-full bg-white/70" />
              </div>
            </div>

            {/* =================================================
                RIGHT CTA
            ================================================== */}

            <div
              className="
                flex
                w-full
                shrink-0
                flex-col
                items-center
                justify-center
                gap-3
                sm:gap-4
                lg:w-auto
                lg:items-end
              "
            >
              <button
                type="button"
                onClick={() =>
                  navigate("/properties")
                }
                className="
                  inline-flex
                  min-h-[50px]
                  w-full
                  max-w-[260px]
                  items-center
                  justify-center
                  rounded-xl
                  bg-white
                  px-6
                  py-3
                  text-sm
                  font-semibold
                  text-sky-600
                  shadow-lg
                  transition-all
                  duration-300
                  hover:scale-[1.03]
                  hover:bg-sky-50
                  active:scale-[0.98]
                  sm:min-h-[54px]
                  sm:max-w-[280px]
                  sm:px-8
                  sm:text-base
                "
              >
                Explore Properties
                <span className="ml-2 text-base">
                  →
                </span>
              </button>

              <p
                className="
                  text-center
                  text-[10px]
                  text-sky-100
                  sm:text-xs
                  lg:text-right
                "
              >
                Trusted by 10,000+ investors & buyers
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;