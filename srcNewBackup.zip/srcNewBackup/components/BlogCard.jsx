import React from "react";
import { Link } from "react-router-dom";
import { FaArrowRight } from "react-icons/fa";

const API_BASE =
  "https://lightblue-moose-690494.hostingersite.com";

const FALLBACK_IMAGE =
  "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg";

const BlogCard = ({ blog }) => {
  /*
  |--------------------------------------------------------------------------
  | SAFE IMAGE
  |--------------------------------------------------------------------------
  */

  const image = blog?.image
    ? `${API_BASE}/public${blog.image}`
    : FALLBACK_IMAGE;

  /*
  |--------------------------------------------------------------------------
  | CLEAN CONTENT
  |--------------------------------------------------------------------------
  */

  const cleanContent = blog?.content
    ? blog.content
        .replace(/<[^>]+>/g, "")
        .replace(/\s+/g, " ")
        .trim()
    : "";

  const excerpt =
    cleanContent.length > 110
      ? `${cleanContent.slice(0, 110)}...`
      : cleanContent;

  const title =
    blog?.title
      ?.replace(/[\r\n]+/g, " ")
      .replace(/\s+/g, " ")
      .trim() || "Property Insights";

  return (
    <article
      className="
        group
        flex
        h-full
        min-w-0
        flex-col
        overflow-hidden
        rounded-[22px]
        border
        border-gray-100
        bg-white
        shadow-sm
        transition-all
        duration-300
        hover:-translate-y-1
        hover:shadow-xl
      "
    >
      {/* ==================================================
          IMAGE
      =================================================== */}

      <Link
        to={`/blog/${blog?.slug}`}
        className="
          block
          overflow-hidden
        "
      >
        <div
          className="
            relative
            aspect-[16/10]
            w-full
            bg-gray-100
          "
        >
          <img
            src={image}
            alt={title}
            loading="lazy"
            className="
              block
              h-full
              w-full
              object-cover
              transition-transform
              duration-500
              group-hover:scale-105
            "
          />

          {/* OVERLAY */}

          <div
            className="
              pointer-events-none
              absolute
              inset-0
              bg-gradient-to-t
              from-black/20
              via-transparent
              to-transparent
              opacity-70
            "
          />

          {/* BLOG BADGE */}

          <span
            className="
              absolute
              left-3
              top-3
              rounded-full
              bg-white/90
              px-3
              py-1.5
              text-[10px]
              font-semibold
              text-sky-600
              shadow-sm
              backdrop-blur
              sm:left-4
              sm:top-4
              sm:text-xs
            "
          >
            Property Insights
          </span>
        </div>
      </Link>

      {/* ==================================================
          CONTENT
      =================================================== */}

      <div
        className="
          flex
          flex-1
          flex-col
          p-4
          sm:p-5
        "
      >
        {/* TITLE */}

        <Link
          to={`/blog/${blog?.slug}`}
          className="block"
        >
          <h2
            className="
              line-clamp-2
              break-words
              text-base
              font-bold
              leading-6
              text-gray-900
              transition-colors
              group-hover:text-sky-600
              sm:text-lg
            "
          >
            {title}
          </h2>
        </Link>

        {/* EXCERPT */}

        {excerpt && (
          <p
            className="
              mt-2
              line-clamp-3
              break-words
              text-xs
              leading-6
              text-gray-500
              sm:text-sm
            "
          >
            {excerpt}
          </p>
        )}

        {/* FOOTER */}

        <div
          className="
            mt-auto
            pt-4
          "
        >
          <Link
            to={`/blog/${blog?.slug}`}
            className="
              inline-flex
              items-center
              gap-2
              text-xs
              font-semibold
              text-sky-500
              transition-colors
              hover:text-sky-600
              sm:text-sm
            "
          >
            Read More

            <FaArrowRight
              className="
                text-[9px]
                transition-transform
                duration-300
                group-hover:translate-x-1
              "
            />
          </Link>
        </div>
      </div>
    </article>
  );
};

export default BlogCard;