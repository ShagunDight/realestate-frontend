import React from "react";
import { FaStar } from "react-icons/fa";

const testimonials = [
  {
    name: "Wade Warren",
    location: "USA, California",
    text: "Our experience with Estatein was outstanding. Their team's dedication and professionalism made finding our dream home a breeze.",
    image:
      "https://randomuser.me/api/portraits/men/32.jpg",
  },
  {
    name: "Emelie Thomson",
    location: "USA, Florida",
    text: "Estatein provided us with top-notch service. They helped us sell our property quickly and at a great price.",
    image:
      "https://randomuser.me/api/portraits/women/44.jpg",
  },
  {
    name: "John Mans",
    location: "USA, Nevada",
    text: "The Estatein team guided us through the entire buying process. Their knowledge and commitment were impressive.",
    image:
      "https://randomuser.me/api/portraits/men/65.jpg",
  },
];

const Testimonials = () => {
  return (
    <section
      className="
        w-full
        bg-white
        px-4
        py-10
        sm:px-6
        sm:py-12
        md:py-14
        lg:py-16
      "
    >
      <div className="mx-auto w-full max-w-[1300px]">
        {/* =====================================================
            HEADER
        ====================================================== */}

        <div
          className="
            mb-7
            flex
            flex-col
            gap-4
            sm:mb-9
            md:mb-10
            lg:flex-row
            lg:items-end
            lg:justify-between
          "
        >
          <div className="max-w-2xl">
            {/* Decorative dots */}

            <div className="mb-3 flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-sky-300 sm:h-2 sm:w-2" />
              <span className="h-2.5 w-2.5 rounded-full bg-sky-500 sm:h-3 sm:w-3" />
              <span className="h-1.5 w-1.5 rounded-full bg-sky-300 sm:h-2 sm:w-2" />
            </div>

            <p
              className="
                text-[10px]
                font-bold
                uppercase
                tracking-[0.18em]
                text-sky-500
                sm:text-xs
              "
            >
              Client Stories
            </p>

            <h2
              className="
                mt-2
                text-2xl
                font-bold
                leading-tight
                text-gray-900
                sm:text-3xl
                md:text-4xl
              "
            >
              What Our Clients Say
            </h2>

            <p
              className="
                mt-2
                max-w-xl
                text-xs
                leading-5
                text-gray-500
                sm:text-sm
                sm:leading-6
              "
            >
              Read the success stories and heartfelt testimonials
              from our valued clients.
            </p>
          </div>
        </div>

        {/* =====================================================
            TESTIMONIAL CARDS
        ====================================================== */}

        <div
          className="
            grid
            grid-cols-1
            gap-4
            sm:grid-cols-2
            sm:gap-5
            lg:grid-cols-3
            lg:gap-6
          "
        >
          {testimonials.map((item, index) => (
            <article
              key={index}
              className="
                group
                flex
                h-full
                flex-col
                rounded-2xl
                border
                border-gray-200
                bg-white
                p-5
                shadow-sm
                transition-all
                duration-300
                hover:-translate-y-1
                hover:shadow-xl
                active:scale-[0.995]
                sm:rounded-[22px]
                sm:p-6
              "
            >
              {/* STARS */}

              <div
                className="
                  flex
                  items-center
                  gap-1
                "
              >
                {[...Array(5)].map((_, starIndex) => (
                  <FaStar
                    key={starIndex}
                    className="
                      text-sm
                      text-sky-400
                      sm:text-base
                    "
                  />
                ))}
              </div>

              {/* TITLE */}

              <h3
                className="
                  mt-4
                  text-base
                  font-semibold
                  leading-6
                  text-gray-900
                  sm:text-lg
                "
              >
                Exceptional Service!
              </h3>

              {/* TEXT */}

              <p
                className="
                  mt-2
                  flex-1
                  text-xs
                  leading-5
                  text-gray-500
                  sm:text-sm
                  sm:leading-6
                "
              >
                {item.text}
              </p>

              {/* USER */}

              <div
                className="
                  mt-6
                  flex
                  items-center
                  gap-3
                  border-t
                  border-gray-100
                  pt-4
                  sm:mt-7
                  sm:pt-5
                "
              >
                <img
                  src={item.image}
                  alt={item.name}
                  loading="lazy"
                  className="
                    h-10
                    w-10
                    shrink-0
                    rounded-full
                    object-cover
                    ring-2
                    ring-sky-50
                    sm:h-11
                    sm:w-11
                  "
                />

                <div className="min-w-0">
                  <p
                    className="
                      truncate
                      text-sm
                      font-semibold
                      text-gray-800
                    "
                  >
                    {item.name}
                  </p>

                  <p
                    className="
                      mt-0.5
                      truncate
                      text-[11px]
                      text-gray-500
                      sm:text-xs
                    "
                  >
                    {item.location}
                  </p>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* =====================================================
            FOOTER / PAGINATION UI
        ====================================================== */}

        <div
          className="
            mt-7
            flex
            flex-col
            items-center
            justify-between
            gap-4
            border-t
            border-gray-100
            pt-5
            text-gray-500
            sm:mt-9
            sm:flex-row
            sm:pt-6
          "
        >
          <p className="text-xs sm:text-sm">
            01 of {String(testimonials.length).padStart(2, "0")}
          </p>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled
              aria-label="Previous testimonial"
              className="
                flex
                h-10
                w-10
                items-center
                justify-center
                rounded-full
                border
                border-gray-200
                bg-white
                text-sm
                text-gray-600
                shadow-sm
                opacity-40
                sm:h-11
                sm:w-11
              "
            >
              ←
            </button>

            <button
              type="button"
              aria-label="Next testimonial"
              className="
                flex
                h-10
                w-10
                items-center
                justify-center
                rounded-full
                border
                border-gray-200
                bg-white
                text-sm
                text-gray-600
                shadow-sm
                transition
                hover:border-sky-500
                hover:bg-sky-500
                hover:text-white
                active:scale-95
                sm:h-11
                sm:w-11
              "
            >
              →
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
