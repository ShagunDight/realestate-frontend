import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const FeaturedProperties = () => {
  const navigate = useNavigate();

  const [properties, setProperties] = useState([]);
  const [expanded, setExpanded] = useState(null);

  const [page, setPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [loading, setLoading] = useState(false);

  /*
  |--------------------------------------------------------------------------
  | STRIP HTML
  |--------------------------------------------------------------------------
  */

  const stripHtml = (html) => {
    const doc = new DOMParser().parseFromString(
      html || "",
      "text/html"
    );

    return doc.body.textContent || "";
  };


  /*
  |--------------------------------------------------------------------------
  | FETCH DATA
  |--------------------------------------------------------------------------
  */

  const fetchData = async (pageNo = 1) => {
    setLoading(true);

    try {
      const res = await fetch(
        `https://lightblue-moose-690494.hostingersite.com/api/featuredProperty?page=${pageNo}`
      );

      if (!res.ok) {
        throw new Error("Failed to fetch featured properties");
      }

      const data = await res.json();

      setProperties(data?.data || []);
      setLastPage(data?.last_page || 1);
      setPage(data?.current_page || pageNo);

      // Reset expanded card when page changes
      setExpanded(null);

    } catch (err) {
      console.error(
        "Featured Properties Error:",
        err
      );

      setProperties([]);
      setLastPage(1);

    } finally {
      setLoading(false);
    }
  };


  /*
  |--------------------------------------------------------------------------
  | INITIAL LOAD
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    fetchData(1);
  }, []);


  /*
  |--------------------------------------------------------------------------
  | PAGINATION
  |--------------------------------------------------------------------------
  */

  const changePage = (newPage) => {
    if (
      newPage < 1 ||
      newPage > lastPage ||
      loading
    ) {
      return;
    }

    fetchData(newPage);
  };


  /*
  |--------------------------------------------------------------------------
  | STATUS COLOR
  |--------------------------------------------------------------------------
  */

  const getStatusClasses = (status) => {
    switch (status?.toLowerCase()) {
      case "active":
        return "bg-green-500/90 text-white";

      case "pending":
        return "bg-yellow-500/90 text-white";

      case "sold":
        return "bg-red-500/90 text-white";

      case "rented":
        return "bg-blue-500/90 text-white";

      default:
        return "bg-gray-700/90 text-white";
    }
  };


  /*
  |--------------------------------------------------------------------------
  | PROPERTY PRICE
  |--------------------------------------------------------------------------
  */

  const getPropertyPrice = (item) => {
    const propertyType =
      item?.property_type?.name?.toLowerCase() || "";

    if (propertyType.includes("lease")) {
      return item?.monthly_rent;
    }

    return item?.sale_price;
  };


  /*
  |--------------------------------------------------------------------------
  | IMAGE URL
  |--------------------------------------------------------------------------
  */

  const getPropertyImage = (item) => {
    const imageValue =
      item?.image?.[0]?.path ||
      item?.image?.[0];

    if (!imageValue) {
      return "https://thumbs.dreamstime.com/b/dummy-neighbor-chat-23372551.jpg";
    }

    return `https://lightblue-moose-690494.hostingersite.com/public/${imageValue}`;
  };


  /*
  |--------------------------------------------------------------------------
  | PRICE FORMAT
  |--------------------------------------------------------------------------
  */

  const formatPrice = (price) => {
    if (
      price === null ||
      price === undefined ||
      price === ""
    ) {
      return "N/A";
    }

    const numericPrice = Number(price);

    if (Number.isNaN(numericPrice)) {
      return price;
    }

    return numericPrice.toLocaleString("en-IN");
  };


  return (
    <>
      {properties.length > 0 && (
        <section
          className="
          w-full
          bg-white
          px-4
          py-10
          sm:px-6
          sm:py-12
          lg:py-14
        "
        >
          <div className="mx-auto w-full max-w-7xl">

            {/* =====================================================
              HEADER
          ====================================================== */}

            <div className="mb-7 sm:mb-9 lg:mb-10">
              <div className="max-w-2xl">

                <p
                  className="
                  text-[10px]
                  font-bold
                  uppercase
                  tracking-[0.18em]
                  text-sky-500
                  sm:text-xs
                "
                >
                  Featured Collection
                </p>

                <h2
                  className="
                  mt-2
                  text-2xl
                  font-bold
                  leading-tight
                  text-gray-900
                  sm:text-3xl
                  md:text-4xl
                "
                >
                  Featured Properties
                </h2>

                <p
                  className="
                  mt-2
                  max-w-xl
                  text-xs
                  leading-5
                  text-gray-500
                  sm:text-sm
                  sm:leading-6
                "
                >
                  Explore handpicked premium properties for
                  investment and business opportunities.
                </p>

              </div>
            </div>


            {/* =====================================================
              LOADING
          ====================================================== */}

            {loading && (
              <div
                className="
                flex
                min-h-[300px]
                items-center
                justify-center
              "
              >
                <div
                  className="
                  h-9
                  w-9
                  animate-spin
                  rounded-full
                  border-[3px]
                  border-gray-200
                  border-t-sky-500
                "
                />
              </div>
            )}


            {/* =====================================================
              EMPTY
          ====================================================== */}

            {!loading &&
              properties.length === 0 && (
                <div
                  className="
                  rounded-2xl
                  border
                  border-gray-100
                  bg-gray-50
                  px-5
                  py-12
                  text-center
                "
                >
                  <div className="text-4xl">
                    🏠
                  </div>

                  <h3
                    className="
                    mt-3
                    text-base
                    font-semibold
                    text-gray-900
                  "
                  >
                    No Featured Properties
                  </h3>

                  <p
                    className="
                    mx-auto
                    mt-1.5
                    max-w-md
                    text-xs
                    leading-5
                    text-gray-500
                  "
                  >
                    There are currently no featured properties
                    available.
                  </p>
                </div>
              )}


            {/* =====================================================
              PROPERTY GRID
          ====================================================== */}

            {!loading &&
              properties.length > 0 && (
                <div
                  className="
                  grid
                  grid-cols-1
                  gap-5
                  sm:grid-cols-2
                  sm:gap-6
                  lg:grid-cols-3
                  xl:grid-cols-4
                "
                >
                  {properties.map((item) => {
                    const propertyId =
                      item?._id || item?.id;

                    const text = stripHtml(
                      item?.description || ""
                    );

                    const isLong = text.length > 80;

                    const isExpanded =
                      expanded === propertyId;

                    const price =
                      getPropertyPrice(item);

                    return (
                      <article
                        key={propertyId}
                        className="
                        group
                        flex
                        h-full
                        flex-col
                        overflow-hidden
                        rounded-2xl
                        border
                        border-gray-200
                        bg-white
                        shadow-sm
                        transition-all
                        duration-300
                        hover:-translate-y-1
                        hover:shadow-2xl
                        active:scale-[0.995]
                        sm:rounded-[22px]
                      "
                      >

                        {/* =================================================
                          IMAGE
                      ================================================== */}

                        <div
                          className="
                          relative
                          aspect-[16/10]
                          w-full
                          overflow-hidden
                          bg-gray-100
                          sm:aspect-[16/10]
                        "
                        >
                          <img
                            src={getPropertyImage(item)}
                            alt={
                              item?.title ||
                              "Featured property"
                            }
                            loading="lazy"
                            className="
                            h-full
                            w-full
                            object-cover
                            transition-transform
                            duration-500
                            group-hover:scale-105
                          "
                          />


                          {/* IMAGE OVERLAY */}

                          <div
                            className="
                            pointer-events-none
                            absolute
                            inset-x-0
                            bottom-0
                            h-20
                            bg-gradient-to-t
                            from-black/30
                            to-transparent
                          "
                          />


                          {/* STATUS */}

                          <span
                            className={`
                            absolute
                            right-3
                            top-3
                            rounded-full
                            px-3
                            py-1
                            text-[10px]
                            font-semibold
                            capitalize
                            shadow-lg
                            backdrop-blur-sm
                            sm:text-xs
                            ${getStatusClasses(item?.status)}
                          `}
                          >
                            {item?.status || "Available"}
                          </span>
                        </div>


                        {/* =================================================
                          CONTENT
                      ================================================== */}

                        <div
                          className="
                          flex
                          flex-1
                          flex-col
                          p-4
                          sm:p-5
                        "
                        >

                          {/* TITLE */}

                          <h3
                            className="
                            line-clamp-2
                            min-h-[40px]
                            text-sm
                            font-bold
                            leading-5
                            text-gray-900
                            sm:text-base
                          "
                          >
                            {item?.title ||
                              "Untitled Property"}
                          </h3>


                          {/* LOCATION */}

                          <p
                            className="
                            mt-2
                            line-clamp-1
                            text-xs
                            text-gray-500
                            sm:text-sm
                          "
                          >
                            📍{" "}
                            {item?.location ||
                              "Location not available"}
                          </p>


                          {/* DESCRIPTION */}

                          <div className="mt-3">
                            <p
                              className="
                              text-xs
                              leading-5
                              text-gray-500
                              sm:text-sm
                              sm:leading-6
                            "
                            >
                              {isExpanded
                                ? text
                                : `${text.slice(
                                  0,
                                  80
                                )}${isLong
                                  ? "..."
                                  : ""
                                }`}
                            </p>

                            {isLong && (
                              <button
                                type="button"
                                onClick={() =>
                                  setExpanded(
                                    isExpanded
                                      ? null
                                      : propertyId
                                  )
                                }
                                className="
                                mt-1.5
                                text-xs
                                font-semibold
                                text-sky-500
                                transition
                                hover:text-sky-600
                                hover:underline
                              "
                              >
                                {isExpanded
                                  ? "Show Less"
                                  : "Read More"}
                              </button>
                            )}
                          </div>


                          {/* =================================================
                            FOOTER
                        ================================================== */}

                          <div
                            className="
                            mt-auto
                            flex
                            items-end
                            justify-between
                            gap-3
                            border-t
                            border-gray-100
                            pt-4
                          "
                          >

                            {/* PRICE */}

                            <div className="min-w-0">

                              <p
                                className="
                                text-[10px]
                                font-medium
                                uppercase
                                tracking-wide
                                text-gray-400
                                sm:text-xs
                              "
                              >
                                Price
                              </p>

                              <p
                                className="
                                mt-0.5
                                truncate
                                text-sm
                                font-bold
                                text-gray-900
                                sm:text-base
                              "
                              >
                                ₹{" "}
                                {formatPrice(price)}
                              </p>

                            </div>


                            {/* VIEW */}

                            <button
                              type="button"
                              onClick={() =>
                                navigate(
                                  `/property/${propertyId}`
                                )
                              }
                              className="
                              shrink-0
                              rounded-xl
                              bg-sky-500
                              px-4
                              py-2.5
                              text-xs
                              font-semibold
                              text-white
                              shadow-sm
                              transition
                              hover:bg-sky-600
                              active:scale-95
                              sm:px-5
                            "
                            >
                              View Property
                            </button>

                          </div>

                        </div>
                      </article>
                    );
                  })}
                </div>
              )}


            {/* =====================================================
              PAGINATION
          ====================================================== */}

            {!loading &&
              properties.length > 0 &&
              lastPage > 1 && (
                <div
                  className="
                  mt-8
                  flex
                  flex-col
                  items-center
                  justify-between
                  gap-4
                  border-t
                  border-gray-100
                  pt-6
                  sm:flex-row
                  sm:pt-7
                "
                >

                  {/* PAGE INFO */}

                  <p
                    className="
                    text-xs
                    text-gray-500
                    sm:text-sm
                  "
                  >
                    Page{" "}
                    <span className="font-semibold text-gray-800">
                      {page}
                    </span>{" "}
                    of{" "}
                    <span className="font-semibold text-gray-800">
                      {lastPage}
                    </span>
                  </p>


                  {/* BUTTONS */}

                  <div className="flex items-center gap-2">

                    <button
                      type="button"
                      onClick={() =>
                        changePage(page - 1)
                      }
                      disabled={
                        page === 1 || loading
                      }
                      aria-label="Previous page"
                      className="
                      flex
                      h-10
                      w-10
                      items-center
                      justify-center
                      rounded-full
                      border
                      border-gray-200
                      bg-white
                      text-sm
                      text-gray-700
                      shadow-sm
                      transition
                      hover:border-sky-500
                      hover:bg-sky-500
                      hover:text-white
                      disabled:cursor-not-allowed
                      disabled:opacity-40
                      sm:h-11
                      sm:w-11
                    "
                    >
                      ←
                    </button>


                    <button
                      type="button"
                      onClick={() =>
                        changePage(page + 1)
                      }
                      disabled={
                        page === lastPage ||
                        loading
                      }
                      aria-label="Next page"
                      className="
                      flex
                      h-10
                      w-10
                      items-center
                      justify-center
                      rounded-full
                      border
                      border-gray-200
                      bg-white
                      text-sm
                      text-gray-700
                      shadow-sm
                      transition
                      hover:border-sky-500
                      hover:bg-sky-500
                      hover:text-white
                      disabled:cursor-not-allowed
                      disabled:opacity-40
                      sm:h-11
                      sm:w-11
                    "
                    >
                      →
                    </button>

                  </div>

                </div>
              )}

          </div>
        </section>
      )}  
    </>
  );
};

export default FeaturedProperties;
